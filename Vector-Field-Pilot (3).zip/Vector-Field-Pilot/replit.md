# Vector Field Pilot

An educational browser simulator for exploring vector fields, differential equations, mission-based learning, and bounded parameter experiments.

## Run & Operate

- The `Vector Field Pilot` artifact workflow runs the web preview.
- `pnpm --filter @workspace/vector-field-pilot run test` — run the math, subsystem, experiment, and persistence tests.
- `pnpm --filter @workspace/vector-field-pilot run typecheck` — typecheck the artifact.
- `PORT=5173 BASE_PATH=/ pnpm --filter @workspace/vector-field-pilot run build` — build the static app outside the managed workflow.
- The simulator stores progress in the current browser's `localStorage`; it does not require an account, database, or API server.

## Stack

- pnpm workspace, Node.js 24, Vite
- Browser app: HTML, CSS, and JavaScript ES modules
- Numerical methods: safe expression parser and ODE solver modules

## Where things live

- `artifacts/vector-field-pilot/index.html` — active app entry point
- `artifacts/vector-field-pilot/styles.css` — flight-deck styling and responsive layout
- `artifacts/vector-field-pilot/src/math/` — expression parsing, vector fields, and numerical methods
- `artifacts/vector-field-pilot/src/game/` — simulation, missions, experiments, and local progress
- `artifacts/vector-field-pilot/src/ui/` — canvas rendering and interface behavior
- `artifacts/vector-field-pilot/tests/` — math, subsystem, experiment, and storage tests

## Architecture decisions

- User-authored equations are parsed into a restricted syntax tree; they are never evaluated as JavaScript.
- The simulator owns state and numerical integration; the canvas renders its snapshots.
- Progress and research notes remain local to the browser and are not synchronized to a server.

## Product

The flight deck combines an editable two-equation model with a live vector-field map. The app also includes a progressive mission board, parameter experiment lab, research log, and livery hangar.

## Gotchas

- The app's active entry is `index.html`, which loads `src/main.js`; the React starter entry is not used by this simulator.
- Browser storage can be unavailable or full. Note saves must report failures and preserve the user's draft.
- This is a simplified 2D educational model, not a real flight simulator or training tool.

## Pointers

- See `artifacts/vector-field-pilot/README.md` for run instructions and supported expression syntax.
- See `artifacts/vector-field-pilot/DEVELOPER_HANDBOOK.md` for numerical and simulation design notes.
