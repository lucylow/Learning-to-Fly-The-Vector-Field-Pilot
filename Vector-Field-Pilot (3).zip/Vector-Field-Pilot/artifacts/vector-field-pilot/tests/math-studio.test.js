import { ExpressionParser } from "../src/math/ExpressionParser.js";
import { EquilibriumSolver } from "../src/math/EquilibriumSolver.js";
import { integrate3D, rk4Step3D, classifyLinearSystem } from "../src/math/ODESolver.js";
import { eigenDecomposition2 } from "../src/math/Matrix.js";
import { VectorField3D } from "../src/math/VectorField3D.js";

function assert(value, message) {
  if (!value) throw new Error(`Math Studio test failed: ${message}`);
}

function close(actual, expected, tolerance = 1e-5) {
  assert(Math.abs(actual - expected) <= tolerance, `${actual} should be close to ${expected}`);
}

function complexMultiply(left, right) {
  return {
    real: left.real * right.real - left.imag * right.imag,
    imag: left.real * right.imag + left.imag * right.real
  };
}
function complexAdd(left, right) {
  return { real: left.real + right.real, imag: left.imag + right.imag };
}
function complexClose(actual, expected, tolerance = 1e-5) {
  close(actual.real, expected.real, tolerance);
  close(actual.imag, expected.imag, tolerance);
}

const zExpression = ExpressionParser.compile("z - 2*x + sin(t)");
close(zExpression.evaluate({ x: 1, y: 0, z: 3, t: 0 }), 1);
assert(ExpressionParser.compile("x + y + z").evaluate({ x: 1, y: 2, z: 3 }) === 6,
  "safe parser accepts the z state");
let arbitraryCodeRejected = false;
try { ExpressionParser.compile("globalThis.alert(1)"); }
catch { arbitraryCodeRejected = true; }
assert(arbitraryCodeRejected, "safe parser still rejects arbitrary code");

const stableSystem = (state) => ({ x: -state.x, y: -2 * state.y });
const stableSolve = new EquilibriumSolver(stableSystem).analyze({ x: .4, y: -.25 });
assert(stableSolve.converged, "damped Newton converges to a stable equilibrium");
close(stableSolve.point.x, 0);
close(stableSolve.point.y, 0);
assert(stableSolve.classification.type === "Stable node", "negative real eigenvalues form a stable node");
assert(stableSolve.eigen.values.length === 2, "analysis returns two eigenvalues");
assert(stableSolve.eigen.eigenvectors.length === 2, "analysis returns two eigenvectors");
assert(stableSolve.linearization.x.includes("u"), "analysis provides a local linearization");
for (const [index, eigenvalue] of stableSolve.eigen.values.entries()) {
  const vector = stableSolve.eigen.eigenvectors[index];
  const product = [
    complexAdd(
      complexMultiply({ real: -1, imag: 0 }, { real: vector.real[0], imag: vector.imag[0] }),
      complexMultiply({ real: 0, imag: 0 }, { real: vector.real[1], imag: vector.imag[1] })
    ),
    complexAdd(
      complexMultiply({ real: 0, imag: 0 }, { real: vector.real[0], imag: vector.imag[0] }),
      complexMultiply({ real: -2, imag: 0 }, { real: vector.real[1], imag: vector.imag[1] })
    )
  ];
  complexClose(product[0], complexMultiply(eigenvalue, { real: vector.real[0], imag: vector.imag[0] }));
  complexClose(product[1], complexMultiply(eigenvalue, { real: vector.real[1], imag: vector.imag[1] }));
}

const roots = new EquilibriumSolver((state) => ({ x: state.x, y: state.y }))
  .scan({ xMin: -2, xMax: 2, yMin: -2, yMax: 2 }, { rows: 5, columns: 5 });
assert(roots.length === 1, "multi-start scan deduplicates the origin equilibrium");
assert(roots[0].residual <= 1e-7, "scan accepts only low-residual roots");
const invalidSolve = new EquilibriumSolver(() => { throw new Error("singular state"); })
  .solve({ x: 0, y: 0 });
assert(!invalidSolve.converged && invalidSolve.failure.includes("singular state"),
  "undefined model evaluations are returned as explicit analysis failures");
let invalidBoundsRejected = false;
try {
  new EquilibriumSolver(stableSystem).scan({ xMin: 2, xMax: -2, yMin: -2, yMax: 2 });
} catch { invalidBoundsRejected = true; }
assert(invalidBoundsRejected, "reversed equilibrium bounds are rejected");

const center = classifyLinearSystem({ a: 0, b: -1, c: 1, d: 0 });
assert(center.type === "Center (linear)", "pure rotation is classified as a linear center");
assert(center.stability === "neutral in the linear model", "center is not described as asymptotically stable");
const saddle = classifyLinearSystem({ a: 1, b: 0, c: 0, d: -1 });
assert(saddle.type === "Saddle" && saddle.stability === "unstable", "saddle reports an unstable direction");

const complexEigen = eigenDecomposition2([[0, -1], [1, 0]]);
assert(!complexEigen.hasRealEigenvalues, "rotation has complex eigenvalues");
close(complexEigen.values[0].real, 0);
close(Math.abs(complexEigen.values[0].imag), 1);
assert(complexEigen.eigenvectors[0].imag.some((value) => Math.abs(value) > .1),
  "complex eigenvectors retain their imaginary components");
for (const [index, eigenvalue] of complexEigen.values.entries()) {
  const vector = complexEigen.eigenvectors[index];
  const product = [
    complexMultiply({ real: 0, imag: 0 }, { real: vector.real[0], imag: vector.imag[0] }),
    complexMultiply({ real: 1, imag: 0 }, { real: vector.real[0], imag: vector.imag[0] })
  ];
  product[0] = complexAdd(product[0], complexMultiply({ real: -1, imag: 0 }, { real: vector.real[1], imag: vector.imag[1] }));
  product[1] = complexAdd(product[1], complexMultiply({ real: 0, imag: 0 }, { real: vector.real[1], imag: vector.imag[1] }));
  complexClose(product[0], complexMultiply(eigenvalue, { real: vector.real[0], imag: vector.imag[0] }));
  complexClose(product[1], complexMultiply(eigenvalue, { real: vector.real[1], imag: vector.imag[1] }));
}
const repeatedEigen = eigenDecomposition2([[-2, 0], [0, -2]]);
assert(repeatedEigen.values.every((value) => value.real === -2), "repeated eigenvalues are supported");

const constantRates = () => ({ x: 1, y: -2, z: .5 });
const step = rk4Step3D(constantRates, { x: 0, y: 0, z: 0, t: 0 }, .2);
close(step.x, .2);
close(step.y, -.4);
close(step.z, .1);
const integrated = integrate3D(constantRates, { x: 0, y: 0, z: 0 }, { duration: 1, stepSize: .05 });
assert(integrated.completed && integrated.termination === "duration", "bounded integration reports a completed trajectory");
close(integrated.points.at(-1).x, 1);
close(integrated.points.at(-1).z, .5);

const invalidTrajectory = integrate3D(
  (state) => state.t > .15 ? { x: Infinity, y: 0, z: 0 } : { x: 1, y: 0, z: 0 },
  { x: 0, y: 0, z: 0 },
  { duration: .5, stepSize: .1 }
);
assert(!invalidTrajectory.completed && invalidTrajectory.termination === "invalid",
  "undefined rates stop with an explicit invalid termination");
const escapingTrajectory = integrate3D(
  () => ({ x: 10, y: 0, z: 0 }),
  { x: 0, y: 0, z: 0 },
  { duration: 1, stepSize: .1, escapeRadius: 2 }
);
assert(escapingTrajectory.termination === "escape", "diverging states are reported as escaped");
let badStartRejected = false;
try { integrate3D(constantRates, { x: NaN, y: 0, z: 0 }); }
catch { badStartRejected = true; }
assert(badStartRejected, "non-finite initial conditions are rejected");
let oversizedRunRejected = false;
try { integrate3D(constantRates, { x: 0, y: 0, z: 0 }, { maxSteps: 100001 }); }
catch { oversizedRunRejected = true; }
assert(oversizedRunRejected, "integration work is capped");

const boundedField = new VectorField3D(
  (state) => ({ x: state.x, y: state.y, z: state.z }),
  { xMin: -1, xMax: 1, yMin: -1, yMax: 1, zMin: -1, zMax: 1 }
);
const plane = boundedField.samplePlane(3, 3, { z: .5, time: 2 });
assert(plane.vectors.length === 9 && plane.invalidCount === 0, "plane sampling returns a finite grid");
close(plane.vectors[0].z, .5);
const volume = boundedField.sampleVolume(3, 2);
assert(volume.vectors.length === 18, "volume sampling covers x, y and z layers");
let excessiveVolumeRejected = false;
try { boundedField.sampleVolume(48, 48); }
catch { excessiveVolumeRejected = true; }
assert(excessiveVolumeRejected, "excessive volume sampling is rejected");
const singularField = new VectorField3D(
  (state) => ({ x: 1 / state.x, y: 0, z: 0 }),
  { xMin: -1, xMax: 1, yMin: -1, yMax: 1, zMin: -1, zMax: 1 }
);
const singularSamples = singularField.samplePlane(3, 3);
assert(singularSamples.invalidCount > 0 && singularSamples.vectors.length > 0,
  "singular samples are counted while finite neighbors remain drawable");
const traces = boundedField.trace([{ x: 0, y: 0, z: 0 }], { duration: .2, stepSize: .05 });
assert(traces.length === 1 && traces[0].completed, "field trace returns bounded integration metadata");

console.log("All Math Studio regression tests passed.");
