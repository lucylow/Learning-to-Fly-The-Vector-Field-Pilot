# Extended acceptance test catalogue

## Control theory
1. Verify proportional control output has the same sign as the error.
2. Verify derivative damping opposes positive velocity.
3. Verify PID integral state is clamped to its configured limit.
4. Verify reset clears integral and derivative history.
5. Verify output saturation respects positive and negative bounds.
6. Compare underdamped, critically damped and overdamped parameter sets.
7. Verify a step response contains finite position, velocity and acceleration values.
8. Run a gain sweep and inspect final error and overshoot.

## Weather
1. Two instances with the same seed produce the same disturbance sequence.
2. Changing the seed changes the generated sequence.
3. Calm mode produces only the configured base current.
4. Crosswind mode rotates the wind direction by ninety degrees.
5. Periodic mode varies with time.
6. Weather snapshot and restore reproduce the same state.
7. Turbulence remains bounded over a long run.
8. Weather composition adds environmental velocity to the selected ODE derivative.

## Replay
1. Replay recording rejects non-finite values.
2. Replay recording rejects decreasing timestamps.
3. Seeking clamps before and after the replay range.
4. Seeking between two frames interpolates position and rate values.
5. Step backward and forward never leave the valid cursor range.
6. Playback stops at the final frame.
7. JSON export and import preserve metadata and frames.
8. Comparison produces a separation value for each sample time.

## Mission content
1. Every mission has a unique integer ID.
2. Every mission includes a name, division, topic and learning explanation.
3. Initial and target states contain finite coordinates.
4. Equations are strings and can be parsed by the expression parser.
5. Mission dependencies refer only to existing mission IDs.
6. The first mission has no prerequisite.
7. Mission grouping preserves division names.
8. Warnings are distinct from blocking validation errors.

## Classroom reports
1. Assignment title is required.
2. Assignment must include at least one mission.
3. Time limit is clamped to a reasonable range.
4. Export includes settings and mission IDs.
5. Student report includes the selected equations and outcome.
6. Anonymization removes direct account and contact fields.
7. Report summary calculates success rate and average score.
8. Reflections reject blank content.

## Accessibility
1. All interactive controls can receive keyboard focus.
2. High-contrast mode is visibly distinct.
3. Larger text does not clip mission cards.
4. Reduced-motion mode reduces animation.
5. Screen-reader descriptions do not rely on colour names alone.
6. Telemetry announcements can be disabled.
7. Keyboard shortcuts do not steal keystrokes from text inputs.
8. Modal dialogs keep keyboard focus inside the dialog.

## Trajectory analysis
1. Velocity estimates use the elapsed time between samples.
2. Acceleration estimates are finite for regular time steps.
3. Curvature is zero for a straight line.
4. Trajectory summary reports bounding coordinates.
5. Oscillation detection reports direction changes.
6. Trajectory comparison returns maximum and average separation.
7. A damped oscillation is classified as decaying when peaks shrink.
8. A short trajectory returns a clear insufficient-data classification.
