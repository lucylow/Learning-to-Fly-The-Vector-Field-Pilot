import assert from "node:assert/strict";
import { ProgressStore } from "../src/game/ProgressStore.js";

function createStorage({ failWrites = false } = {}) {
  return {
    value: null,
    getItem() {
      return this.value;
    },
    setItem(_key, value) {
      if (failWrites) throw new Error("quota exceeded");
      this.value = value;
    }
  };
}

const workingStorage = createStorage();
const workingStore = new ProgressStore(workingStorage);
assert.equal(workingStore.addNote("  Saved observation  "), true);
assert.equal(workingStore.getNotes()[0].content, "Saved observation");
assert.equal(JSON.parse(workingStorage.value).notes.length, 1);

const fullStorage = createStorage({ failWrites: true });
const fullStore = new ProgressStore(fullStorage);
let storageErrors = 0;
fullStore.addEventListener("storage-error", () => {
  storageErrors += 1;
});

assert.equal(fullStore.addNote("Keep this draft"), false);
assert.equal(fullStore.getNotes().length, 0, "a failed note must not remain as unsaved store state");
assert.equal(storageErrors, 1, "a failed write emits a storage error");

const unavailableStore = new ProgressStore(null);
assert.equal(unavailableStore.addNote("Keep this draft too"), false);
assert.equal(unavailableStore.getNotes().length, 0);

console.log("All progress store tests passed.");
