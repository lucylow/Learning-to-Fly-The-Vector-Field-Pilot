import { PIDController, secondOrderParameters } from "../src/math/ControlTheory.js";
import { WeatherSystem } from "../src/game/WeatherSystem.js";
import { FlightReplay } from "../src/game/FlightReplay.js";
import { validateMissionSet } from "../src/game/MissionValidator.js";
import { StateSpaceModel, secondOrderToStateSpace } from "../src/math/StateSpace.js";
import { summarizeTrajectory, detectOscillations } from "../src/math/TrajectoryAnalysis.js";
import { MISSIONS } from "../src/data/missions.js";
import { LESSONS, searchLessons } from "../src/data/LessonLibrary.js";
import { SIMULATION_PRESETS } from "../src/game/SimulationPresets.js";

function assert(value, message) {
  if (!value) throw new Error(`Expanded test failed: ${message}`);
}

const pid = new PIDController({ kp: 2, ki: .1, kd: .2 });
assert(pid.update(1, 0, .1) > 0, "PID should respond to positive error");
assert(pid.snapshot().integral > 0, "PID should accumulate error");

const oscillator = secondOrderParameters(4, .4, 1);
assert(oscillator.regime === "underdamped", "low damping should be underdamped");

const weatherA = new WeatherSystem({ seed: 77, turbulence: .2, mode: "gusty" });
const weatherB = new WeatherSystem({ seed: 77, turbulence: .2, mode: "gusty" });
weatherA.update(.1);
weatherB.update(.1);
assert(weatherA.sample({ x: 0, y: 0 }).x === weatherB.sample({ x: 0, y: 0 }).x, "seeded weather should be repeatable");

const replay = new FlightReplay();
replay.begin({ mission: "test" });
replay.record({ t: 0, x: 0, y: 0 });
replay.record({ t: 1, x: 1, y: 2 });
assert(replay.seek(.5).x === .5, "replay should interpolate between samples");
assert(FlightReplay.from(replay.export()).frames.length === 2, "replay should round-trip");

assert(validateMissionSet(MISSIONS).valid, "mission data should validate");
assert(searchLessons("damping").length > 0, "lesson search should find damping");
assert(LESSONS.length >= 10, "lesson library should contain curriculum content");
assert(SIMULATION_PRESETS.length >= 8, "preset library should contain models");

const model = new StateSpaceModel({ matrixA: [[0, 1], [-1, -.2]], labels: ["q", "v"] });
const series = model.simulate([1, 0], { duration: 1, stepSize: .01 });
assert(series.length > 50, "state-space model should generate a trajectory");

const secondOrder = secondOrderToStateSpace({ stiffness: 2, damping: .5 });
assert(secondOrder.derivative([1, 0]).length === 2, "second-order conversion should return two rates");

const summary = summarizeTrajectory([{ t: 0, x: 0, y: 0 }, { t: 1, x: 1, y: 0 }], { x: 1, y: 0 });
assert(summary.finalError === 0, "trajectory summary should calculate target error");
const oscillations = detectOscillations([{ t: 0, x: 0 }, { t: 1, x: 1 }, { t: 2, x: 0 }, { t: 3, x: -1 }, { t: 4, x: 0 }]);
assert(oscillations.count >= 1, "oscillation detector should find turning points");

console.log("All expanded subsystem tests passed.");
