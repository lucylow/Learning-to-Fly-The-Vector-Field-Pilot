/**
 * Model fixtures used by developers when checking field plots and solver changes.
 */
export const MODEL_FIXTURES = [
  { id: "constant-east", x: "1", y: "0", state: { x: 0, y: 0, t: 0 }, expected: { x: 1, y: 0 } },
  { id: "constant-diagonal", x: "1", y: "1", state: { x: 2, y: -3, t: 0 }, expected: { x: 1, y: 1 } },
  { id: "linear-decay", x: "-x", y: "-y", state: { x: 2, y: 4, t: 0 }, expected: { x: -2, y: -4 } },
  { id: "linear-growth", x: "x", y: "y", state: { x: 2, y: 4, t: 0 }, expected: { x: 2, y: 4 } },
  { id: "coupled-rotation", x: "y", y: "-x", state: { x: 0, y: 2, t: 0 }, expected: { x: 2, y: 0 } },
  { id: "damped-oscillator", x: "y", y: "-4*x-0.5*y", state: { x: 1, y: 0, t: 0 }, expected: { x: 0, y: -4 } },
  { id: "periodic-input", x: "1", y: "sin(t)", state: { x: 0, y: 0, t: 0 }, expected: { x: 1, y: 0 } },
  { id: "quadratic", x: "x*(1-x)", y: "0", state: { x: .5, y: 0, t: 0 }, expected: { x: .25, y: 0 } }
];

export function fixtureById(id) {
  return MODEL_FIXTURES.find((fixture) => fixture.id === id) ?? null;
}

export function verifyFixture(fixture, systemFactory, tolerance = 1e-8) {
  const system = systemFactory(fixture.x, fixture.y);
  const actual = system(fixture.state);
  return {
    id: fixture.id,
    passed: Math.abs(actual.x - fixture.expected.x) <= tolerance &&
      Math.abs(actual.y - fixture.expected.y) <= tolerance,
    actual,
    expected: fixture.expected
  };
}

export function verifyAllFixtures(systemFactory) {
  return MODEL_FIXTURES.map((fixture) => verifyFixture(fixture, systemFactory));
}
