import { ExpressionParser, validateExpression } from "../src/math/ExpressionParser.js";
import { rk4Step, integrate, classifyLinearSystem } from "../src/math/ODESolver.js";

function assert(condition, message) {
  if (!condition) throw new Error(`Test failed: ${message}`);
}
function close(actual, expected, tolerance = 1e-3) {
  assert(Math.abs(actual - expected) <= tolerance, `${actual} should be close to ${expected}`);
}

const expression = ExpressionParser.compile("-2*x + y + sin(t)");
close(expression.evaluate({ x: 2, y: 1, t: 0 }), -3);
assert(validateExpression("x + unknown").valid === false, "unknown variables are rejected");
assert(validateExpression("window.alert(1)").valid === false, "arbitrary code is rejected");

const decay = (state) => ({ x: -state.x, y: 0 });
const end = integrate(decay, { x: 1, y: 0 }, { duration: 1, stepSize: .01 }).at(-1);
close(end.x, Math.exp(-1), .002);

const oscillator = (state) => ({ x: state.y, y: -state.x });
const next = rk4Step(oscillator, { x: 1, y: 0, t: 0 }, .1);
close(Math.hypot(next.x, next.y), 1, .00001);

const stable = classifyLinearSystem({ a: -1, b: 0, c: 0, d: -2 });
assert(stable.type === "Stable node", "negative eigenvalues classify as stable node");
const saddle = classifyLinearSystem({ a: 1, b: 0, c: 0, d: -1 });
assert(saddle.type === "Saddle", "opposite signs classify as saddle");

console.log("All mathematical tests passed.");
