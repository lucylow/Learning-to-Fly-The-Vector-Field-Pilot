import assert from "node:assert/strict";
import { getDemoSweepExamples, getExperimentModels, runParameterSweep } from "../src/game/ExperimentLab.js";
import { ProgressStore } from "../src/game/ProgressStore.js";

const models = getExperimentModels();
assert.equal(models.length, 3, "the lab exposes its three teaching models");
assert.ok(models.every((model) => model.id && model.equations.x && model.equations.y));
const demoExamples = getDemoSweepExamples();
assert.equal(demoExamples.length, 3, "the lab includes a small set of guided examples");
assert.ok(demoExamples.every((example) => example.id.startsWith("demo-")));

const oscillator = runParameterSweep({
  modelId: "damped-oscillator",
  min: 0.2,
  max: 1.2,
  samples: 5,
  initial: { x: 2, y: 0 },
  duration: 8
});
assert.equal(oscillator.series.length, 5, "a sweep returns the requested number of cases");
assert.equal(oscillator.series[0].parameterValue, 0.2);
assert.equal(oscillator.series.at(-1).parameterValue, 1.2);
assert.ok(oscillator.series.every((item) => item.points.length > 1));
assert.ok(oscillator.series.every((item) => Number.isFinite(item.metrics.finalRadius)));
assert.ok(oscillator.series.every((item) => item.points.length <= 180));

const rotating = runParameterSweep({
  modelId: "rotating-flow",
  min: 0.5,
  max: 2,
  samples: 4,
  initial: { x: 3, y: 0 },
  duration: 10
});
for (const item of rotating.series) {
  assert.ok(Math.abs(item.metrics.finalRadius - 3) < 0.002, "rotation preserves radius");
}

assert.throws(
  () => runParameterSweep({ modelId: "missing", min: 0, max: 1, initial: { x: 1, y: 1 } }),
  /supported experiment model/
);
assert.throws(
  () => runParameterSweep({ modelId: "damped-oscillator", min: 2, max: 1, initial: { x: 1, y: 1 } }),
  /valid parameter range/
);
assert.throws(
  () => runParameterSweep({ modelId: "damped-oscillator", min: 1, max: 1, initial: { x: 1, y: 1 } }),
  /minimum lower than the maximum/
);
assert.throws(
  () => runParameterSweep({ modelId: "damped-oscillator", min: 0, max: 1, samples: 2, initial: { x: 1, y: 1 } }),
  /between 3 and 9/
);

const memory = {
  value: null,
  getItem() { return this.value; },
  setItem(_key, value) { this.value = value; }
};
const store = new ProgressStore(memory);
assert.deepEqual(store.getSweeps(), [], "demo examples do not populate saved browser history");
assert.equal(memory.value, null, "demo examples do not write to local storage");
assert.equal(store.addSweep({
  modelTitle: "Damped oscillator",
  parameter: "Damping",
  min: 0.1,
  max: 1.2,
  samples: 5,
  duration: 8,
  results: []
}), true, "sweep history saves to browser storage");
assert.equal(new ProgressStore(memory).getSweeps()[0].modelTitle, "Damped oscillator");

console.log("All experiment lab tests passed.");
