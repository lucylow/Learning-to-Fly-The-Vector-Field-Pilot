# QA test plan

## Mathematical parser
- `1` evaluates to one.
- `-x` respects unary negation.
- `-2*x+y` respects multiplication precedence.
- `x^2` evaluates a power.
- `sin(pi/2)` evaluates to one.
- `sqrt(abs(x))` supports nested calls.
- `unknown` is rejected.
- `alert(1)` is rejected.
- `x/0` reports a division-by-zero condition at evaluation time.
- Empty input is rejected.

## Solver
- Euler integration of x′=1 increases x linearly.
- RK4 integration of x′=−x approximates exp(−t).
- RK4 integration of x′=y, y′=−x approximately preserves radius for a short interval.
- A non-finite derivative raises a controlled error.
- Trajectory integration stops when the configured duration is reached.

## Simulator
- Start changes the state to running.
- Pause stops further integration.
- Reset restores the initial state and clears history.
- Time scale changes simulated time advancement.
- Out-of-range states stop with an error event.
- Completion emits a result with metrics and the final state.

## Mission progression
- Mission one is initially unlocked.
- A later mission remains locked until the previous mission is completed.
- A successful result is persisted.
- A failed attempt is recorded without unlocking the next mission.
- Replaying a completed mission does not remove its completion record.

## Interface
- Flight deck renders at desktop and mobile sizes.
- Invalid equations show an error and do not replace the active model.
- Apply model redraws the vector field.
- Pause and restart controls reflect simulation state.
- Research note is saved and restored after reload.
- Export produces valid JSON.
- Livery selection persists locally.
- Keyboard focus remains visible.
