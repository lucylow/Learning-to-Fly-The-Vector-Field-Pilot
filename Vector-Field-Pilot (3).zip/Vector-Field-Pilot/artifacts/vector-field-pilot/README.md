# Learning to Fly: The Vector Field Pilot

A browser-based educational flight simulator based on the supplied project brief.

## Run in Replit

The web preview runs the static ES-module application through the artifact's managed Vite workflow.

```bash
pnpm --filter @workspace/vector-field-pilot run dev
pnpm --filter @workspace/vector-field-pilot run test
```

## Run locally

This is a static ES-module web application. Use a local web server rather than opening `index.html` directly.

```bash
python -m http.server 8000
```

Open `http://localhost:8000`.

Open `http://localhost:8000`.

## Included

- 2D canvas flight map with vector field arrows, runway, aircraft and trajectory.
- Safe expression parser. It does not use `eval()` or `Function()`.
- Euler, midpoint, RK4 and adaptive numerical integration utilities.
- Live two-equation editor for `dx/dt` and `dy/dt`.
- Math Studio with 2D/3D vector-field sampling, direction and magnitude views, bounded RK4 trajectories, pan/zoom/rotation, and side-by-side model comparison.
- Numerical 2D equilibrium search with finite-difference Jacobians, real and complex 2x2 eigenpairs, linearization, and local stability explanations.
- Fifteen progressive missions.
- Flight simulator with pause, restart, time scale and landing envelope.
- Local progress storage, research notes, experiment history and JSON export.
- Mission board, hangar livery selector, responsive layout and help dialog.
- Experiment lab with bounded parameter sweeps for damped oscillators, stable foci and rotating flows.
- Overlaid state-space trajectories, run summaries and browser-local sweep history.
- Basic and expanded mathematical regression tests.
- Optional reusable subsystems: PID feedback, weather disturbances, replay archive, state-space models, phase portrait analysis, scoring, achievements, classroom report helpers, accessibility preferences, keyboard shortcuts, audio cues, and trajectory diagnostics.

## Supported expression syntax

Variables: `x`, `y`, `z`, `t`

Constants: `pi`, `e`

Operators: `+`, `-`, `*`, `/`, `^` (also `**`)

Functions: `sin`, `cos`, `tan`, `asin`, `acos`, `atan`, `exp`, `log`, `sqrt`, `abs`, `floor`, `ceil`, `min`, `max`.

Example:

```text
dx/dt = -0.8*x + y
dy/dt = -x - 0.6*y + 0.2*sin(t)
```

## Important model limitations

This is a simplified educational dynamical-system game. The on-screen aircraft is a visual marker for the state `(x, y)`. It is not a real aircraft flight model, flight-training tool, aerodynamic solver, or navigation instrument. Wind display is illustrative and separate from the equation system in this prototype.

Math Studio can plot three-component vector fields, but its equilibrium search and eigenanalysis are deliberately limited to the x-y subsystem with `z = 0`. The Jacobian is estimated with finite differences and the search uses multi-start damped Newton iterations, so roots can be missed near singularities, flat regions, or outside the displayed domain. Stability labels describe the local linearized 2D model only. Equations containing `t` are evaluated at the selected snapshot; a time-varying system does not generally have a fixed equilibrium in the autonomous sense. 3D plots and trajectories use bounded numerical sampling and RK4 integration; they do not certify full 3D stability.

## Persistence and privacy

Progress, experiment history and saved sweep summaries are stored in the browser's `localStorage` on the current device. No server, account, analytics, or cloud synchronization is included. Clearing browser storage removes local progress. The research log can be exported as JSON.

## Project structure

```text
vector-field-pilot/
├── index.html
├── styles.css
├── package.json
├── README.md
├── src/
│   ├── main.js
│   ├── math/
│   │   ├── ExpressionParser.js
│   │   ├── ODESolver.js
│   │   └── VectorField.js
│   ├── game/
│   │   ├── FlightSimulator.js
│   │   ├── ExperimentLab.js
│   │   ├── MissionManager.js
│   │   └── ProgressStore.js
│   ├── ui/
│   │   ├── AppController.js
│   │   └── FlightCanvas.js
│   └── data/
│       └── missions.js
└── tests/
    └── math.test.js
```

## Development notes

The project deliberately separates mathematics, simulation, mission data, persistence and interface rendering. Keep that boundary when adding features. Add tests for new expression operators, numerical methods and mission completion conditions before expanding the campaign.

## Optional subsystem modules

Several advanced modules are included as reusable building blocks and are not all wired into the initial flight-deck interface yet. They provide a clean foundation for extending the prototype without coupling new features into the main controller. See `DEVELOPER_HANDBOOK.md` and `tests/EXTENDED_QA.md`.
