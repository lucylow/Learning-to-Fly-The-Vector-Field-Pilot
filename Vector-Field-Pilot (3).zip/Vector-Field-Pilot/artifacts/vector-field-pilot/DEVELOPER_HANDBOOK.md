# Developer handbook — implementation notes

This handbook accompanies the runnable prototype. It records the intended engineering boundaries and the next checks for a production implementation.

## Architecture and boundaries

The application separates the mathematical model from the canvas renderer. The parser turns user-authored expressions into a small abstract syntax tree. The solver evaluates that tree at a sequence of states. The simulator owns time, pause state, trajectory history and landing checks. The interface reads snapshots and displays them; it does not alter the numerical integration.

Keep mission definitions declarative. A mission should describe its learning topic, starting state, target, default equations, duration, landing tolerance and teaching note. MissionManager decides what is unlocked and records outcomes. This makes it possible to add content without changing the rendering engine.

ProgressStore is the only module that knows the browser persistence key. UI code should use its methods rather than writing directly to localStorage. This reduces coupling and gives a future backend a clear replacement point.

## Mathematical expression safety

Never replace the expression parser with eval or Function. Those mechanisms would execute arbitrary JavaScript typed into an equation field. The parser accepts only the grammar documented in ExpressionParser.js and rejects unknown identifiers, unsupported function names and malformed parentheses.

An expression can be syntactically valid but numerically invalid at a particular state. Division by zero and non-finite values are caught during evaluation. The simulator stops and reports the issue rather than continuing with corrupted coordinates.

Expression parsing and numerical integration should be tested independently. Parser tests should cover operator precedence, unary signs, powers, nested function calls, constants, whitespace and invalid tokens. Solver tests should compare known solutions against numerical results.

## Numerical integration

Euler's method is pedagogically useful because its update rule is easy to visualize. Midpoint and fourth-order Runge–Kutta improve accuracy for smooth problems. The adaptive helper estimates error by comparing one full step with two half steps.

The displayed trajectory is an approximation. Accuracy depends on the step size, model smoothness and solver choice. If a mission introduces rapid changes, reduce the step size or use the adaptive routine in a future settings panel.

Do not confuse a numerical blow-up with a proof of mathematical instability. Numerical methods can become inaccurate when a step size is too large. A production release should expose solver settings in a diagnostic panel and explain this distinction.

## Vector field rendering

The field sampler evaluates the derivative function on a rectangular grid. Each arrow encodes the direction of instantaneous change. Magnitude mode changes arrow length to communicate relative rate size; direction mode normalizes arrow lengths for readability.

The canvas uses a world-coordinate rectangle that is mapped to device pixels. The mapping is centralized in VectorField.js so future zoom and pan controls can be added without rewriting the drawing routines.

Canvas dimensions are updated through ResizeObserver and device pixel ratio scaling. Rendering should remain independent of simulation timing: the simulator produces state snapshots, and the renderer draws the latest snapshot.

## Mission design

Early missions should teach one concept at a time. Constant-rate missions establish that a derivative is a rate. Stable and unstable missions demonstrate the effect of coefficient signs. Coupled systems demonstrate that state variables can influence one another.

Second-order examples are represented as two first-order equations: q′ = v and v′ = −kq − cv. This is a useful bridge between introductory ODE notation and a state-space implementation.

Advanced missions should combine earlier ideas, but the briefing should identify the learning goal. The player should be able to replay a mission, compare experiments and use hints without losing progress.

## Landing evaluation

The prototype defines a small circular target region and checks the instantaneous derivative magnitude before declaring a landing. A more complete release should distinguish position tolerance, ground speed, approach direction, lateral error and stability over a short time interval.

Mission success should not depend on matching one exact equation. Multiple systems can satisfy the same target condition. Score based on observable outcomes such as landing distance, elapsed time, boundedness and path length.

Failed attempts should still be recorded. A failure record can be a useful experiment when it includes the equations, initial state, trajectory, solver and environmental parameters.

## Accessibility and responsive design

Keyboard focus is visible on interactive controls. Buttons have readable labels and the canvas has an accessible description. Reduced-motion preferences are respected by limiting transitions in CSS.

Do not communicate success or danger through colour alone. Pair colour with text labels and symbols. Keep the equation inputs keyboard-editable, and do not require drag-and-drop for core gameplay.

The layout collapses from a two-column flight deck to a single column on narrower screens. Test at desktop, tablet and phone widths, including landscape orientation.

## Privacy and deployment

This prototype stores data only in localStorage. It does not collect names, emails or student identifiers. A classroom version with accounts, teacher dashboards or multiplayer would need a backend, access controls, a privacy review and a retention policy.

To deploy, publish the project directory to a static host that serves ES modules with correct MIME types. HTTPS is recommended. Verify that all paths are relative and that the app works from a subdirectory if the hosting provider uses project pages.

Before public release, test on current Chrome, Firefox, Safari and Edge. Verify canvas resizing, local storage restrictions, keyboard operation, error handling, export behavior and mission unlock progression.

## Suggested next milestones

1. Add a mission editor and schema validation for mission JSON.
2. Add an explicit wind disturbance toggle that composes with the selected ODE system.
3. Add a replay timeline and side-by-side trajectory comparison.
4. Add a landing envelope with speed and heading checks.
5. Add teacher mode, assignment export and anonymized class reports.
6. Add automated browser tests and accessibility audits.
7. Add a backend only if accounts, synchronization or multiplayer become required.
