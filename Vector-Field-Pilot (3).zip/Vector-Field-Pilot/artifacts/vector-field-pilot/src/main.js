import { AppController } from "./ui/AppController.js";

function boot() {
  const app = new AppController();
  window.vectorFieldPilot = app;
  window.addEventListener("beforeunload", () => app.destroy(), { once: true });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", boot, { once: true });
} else {
  boot();
}
