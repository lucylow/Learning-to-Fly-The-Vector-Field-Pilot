import { integrate3D } from "./ODESolver.js";

/**
 * Sampling and bounded trajectory helpers for a user-authored 3D vector field.
 * Invalid samples are counted and omitted so a singularity cannot poison the
 * rest of the grid.
 */
export class VectorField3D {
  constructor(system, bounds = { xMin: -6, xMax: 6, yMin: -6, yMax: 6, zMin: -6, zMax: 6 }) {
    if (typeof system !== "function") throw new TypeError("A vector-field function is required.");
    if (!bounds || ![bounds.xMin, bounds.xMax, bounds.yMin, bounds.yMax, bounds.zMin, bounds.zMax].every(Number.isFinite) ||
        !(bounds.xMin < bounds.xMax) || !(bounds.yMin < bounds.yMax) || !(bounds.zMin < bounds.zMax)) {
      throw new RangeError("Vector-field bounds must be finite and increasing on all axes.");
    }
    this.system = system;
    this.bounds = bounds;
  }

  samplePlane(columns = 15, rows = 11, options = {}) {
    const { xMin, xMax, yMin, yMax } = this.bounds;
    const vectors = [];
    let invalidCount = 0;
    const z = Number(options.z ?? 0);
    const time = Number(options.time ?? 0);
    validateGridSize(columns, rows);
    if (![z, time].every(Number.isFinite)) throw new RangeError("Slice coordinate and time must be finite.");
    for (let row = 0; row < rows; row += 1) {
      const y = yMax - row / Math.max(1, rows - 1) * (yMax - yMin);
      for (let column = 0; column < columns; column += 1) {
        const x = xMin + column / Math.max(1, columns - 1) * (xMax - xMin);
        const vector = this.readVector({ x, y, z, t: time });
        if (vector) vectors.push(vector);
        else invalidCount += 1;
      }
    }
    return { vectors, invalidCount };
  }

  sampleVolume(side = 6, depth = 4, options = {}) {
    validateGridSize(side, side);
    if (!Number.isInteger(depth) || depth < 2 || depth > 48) {
      throw new RangeError("Volume depth must be an integer between 2 and 48.");
    }
    if (side * side * depth > 30000) {
      throw new RangeError("Volume sampling is limited to 30,000 points per pass.");
    }
    const { xMin, xMax, yMin, yMax, zMin, zMax } = this.bounds;
    const vectors = [];
    let invalidCount = 0;
    const time = Number(options.time ?? 0);
    if (!Number.isFinite(time)) throw new RangeError("Sample time must be finite.");
    for (let layer = 0; layer < depth; layer += 1) {
      const z = zMin + layer / Math.max(1, depth - 1) * (zMax - zMin);
      for (let row = 0; row < side; row += 1) {
        const y = yMax - row / Math.max(1, side - 1) * (yMax - yMin);
        for (let column = 0; column < side; column += 1) {
          const x = xMin + column / Math.max(1, side - 1) * (xMax - xMin);
          const vector = this.readVector({ x, y, z, t: time });
          if (vector) vectors.push(vector);
          else invalidCount += 1;
        }
      }
    }
    return { vectors, invalidCount };
  }

  trace(seeds, options = {}) {
    if (!Array.isArray(seeds) || seeds.length > 100) {
      throw new TypeError("Trajectory seeds must be an array of no more than 100 points.");
    }
    return seeds.map((seed) => integrate3D(this.system, seed, options));
  }

  readVector(point) {
    try {
      const value = this.system(point);
      if (![value?.x, value?.y, value?.z].every(Number.isFinite)) return null;
      const magnitude = Math.hypot(value.x, value.y, value.z);
      if (!Number.isFinite(magnitude)) return null;
      return { ...point, dx: value.x, dy: value.y, dz: value.z, magnitude };
    } catch {
      return null;
    }
  }
}

function validateGridSize(...values) {
  if (!values.every((value) => Number.isInteger(value) && value >= 2 && value <= 48)) {
    throw new RangeError("Grid dimensions must be integers between 2 and 48.");
  }
}
