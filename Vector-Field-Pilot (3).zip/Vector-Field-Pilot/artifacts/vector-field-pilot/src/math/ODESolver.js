/**
 * Numerical integration utilities for 2D autonomous and time-dependent systems.
 * The simulation state is { x, y, t }. Each derivative returns { x, y }.
 */
export function derivative(system, state) {
  const result = system(state);
  if (!Number.isFinite(result.x) || !Number.isFinite(result.y)) {
    throw new RangeError("The differential equation produced a non-finite rate.");
  }
  return result;
}

export function eulerStep(system, state, h) {
  const k1 = derivative(system, state);
  return {
    x: state.x + h * k1.x,
    y: state.y + h * k1.y,
    t: state.t + h
  };
}

export function midpointStep(system, state, h) {
  const k1 = derivative(system, state);
  const midpoint = {
    x: state.x + h * k1.x / 2,
    y: state.y + h * k1.y / 2,
    t: state.t + h / 2
  };
  const k2 = derivative(system, midpoint);
  return {
    x: state.x + h * k2.x,
    y: state.y + h * k2.y,
    t: state.t + h
  };
}

export function rk4Step(system, state, h) {
  const k1 = derivative(system, state);
  const k2 = derivative(system, {
    x: state.x + h * k1.x / 2,
    y: state.y + h * k1.y / 2,
    t: state.t + h / 2
  });
  const k3 = derivative(system, {
    x: state.x + h * k2.x / 2,
    y: state.y + h * k2.y / 2,
    t: state.t + h / 2
  });
  const k4 = derivative(system, {
    x: state.x + h * k3.x,
    y: state.y + h * k3.y,
    t: state.t + h
  });
  return {
    x: state.x + h * (k1.x + 2*k2.x + 2*k3.x + k4.x) / 6,
    y: state.y + h * (k1.y + 2*k2.y + 2*k3.y + k4.y) / 6,
    t: state.t + h
  };
}

function derivative3D(system, state) {
  const result = system(state);
  if (![result.x, result.y, result.z].every(Number.isFinite)) {
    throw new RangeError("The three-dimensional system produced a non-finite rate.");
  }
  return result;
}

export function rk4Step3D(system, state, h) {
  if (!Number.isFinite(h)) throw new RangeError("Step size must be finite.");
  const k1 = derivative3D(system, state);
  const k2 = derivative3D(system, {
    x: state.x + h * k1.x / 2, y: state.y + h * k1.y / 2,
    z: state.z + h * k1.z / 2, t: state.t + h / 2
  });
  const k3 = derivative3D(system, {
    x: state.x + h * k2.x / 2, y: state.y + h * k2.y / 2,
    z: state.z + h * k2.z / 2, t: state.t + h / 2
  });
  const k4 = derivative3D(system, {
    x: state.x + h * k3.x, y: state.y + h * k3.y,
    z: state.z + h * k3.z, t: state.t + h
  });
  const next = {
    x: state.x + h * (k1.x + 2 * k2.x + 2 * k3.x + k4.x) / 6,
    y: state.y + h * (k1.y + 2 * k2.y + 2 * k3.y + k4.y) / 6,
    z: state.z + h * (k1.z + 2 * k2.z + 2 * k3.z + k4.z) / 6,
    t: state.t + h
  };
  if (![next.x, next.y, next.z, next.t].every(Number.isFinite)) {
    throw new RangeError("The integration step produced a non-finite state.");
  }
  return next;
}

/**
 * Bounded RK4 integration for three-dimensional educational vector fields.
 * A partial trajectory includes an explicit termination reason; it is never
 * silently presented as a complete run.
 */
export function integrate3D(system, initial, options = {}) {
  const {
    duration = 12, stepSize = .025, maxSteps = 20000,
    escapeRadius = 1e4, stop = null
  } = options;
  if (!(Number.isFinite(duration) && duration >= 0) ||
      !(Number.isFinite(stepSize) && stepSize > 0) ||
      !(Number.isInteger(maxSteps) && maxSteps > 0 && maxSteps <= 100000) ||
      !(Number.isFinite(escapeRadius) && escapeRadius > 0)) {
    throw new RangeError("Use a non-negative duration, positive step size and limits.");
  }
  const state = {
    x: Number(initial.x), y: Number(initial.y), z: Number(initial.z ?? 0),
    t: Number(initial.t ?? 0)
  };
  if (![state.x, state.y, state.z, state.t].every(Number.isFinite)) {
    throw new TypeError("Initial x, y, z and time values must be finite.");
  }
  const points = [{ ...state }];
  let steps = 0;
  while (state.t - points[0].t < duration && steps < maxSteps) {
    const h = Math.min(stepSize, duration - (state.t - points[0].t));
    try {
      const next = rk4Step3D(system, state, h);
      if (Math.max(Math.abs(next.x), Math.abs(next.y), Math.abs(next.z)) > escapeRadius) {
        return { points, completed: false, termination: "escape", message: "Trajectory exceeded the plotting limit." };
      }
      Object.assign(state, next);
    } catch (error) {
      return {
        points, completed: false, termination: "invalid",
        message: error?.message ?? "The system became undefined during integration."
      };
    }
    points.push({ ...state });
    steps += 1;
    if (stop?.(state, points.at(-2))) {
      return { points, completed: false, termination: "stopped", message: "Trajectory stopped at the requested condition." };
    }
  }
  if (steps >= maxSteps && state.t - points[0].t < duration) {
    return { points, completed: false, termination: "step-limit", message: "Trajectory reached the integration step limit." };
  }
  return { points, completed: true, termination: "duration", message: "" };
}

export function integrate(system, initial, options = {}) {
  const {
    duration = 20,
    stepSize = 0.025,
    method = "rk4",
    maxSteps = 20000,
    stop = null
  } = options;
  if (!(stepSize > 0) || !(duration >= 0)) throw new RangeError("Duration and step size must be non-negative.");
  const step = method === "euler" ? eulerStep : method === "midpoint" ? midpointStep : rk4Step;
  const state = { x: initial.x, y: initial.y, t: initial.t ?? 0 };
  const points = [{ ...state }];
  const count = Math.min(Math.ceil(duration / stepSize), maxSteps);
  for (let index = 0; index < count; index += 1) {
    const next = step(system, state, Math.min(stepSize, duration - state.t));
    if (![next.x, next.y, next.t].every(Number.isFinite)) break;
    if (Math.abs(next.x) > 1e5 || Math.abs(next.y) > 1e5) break;
    Object.assign(state, next);
    points.push({ ...state });
    if (stop?.(state, points[points.length - 2])) break;
  }
  return points;
}

export function estimateAdaptive(system, initial, options = {}) {
  const {
    duration = 20,
    initialStep = 0.05,
    tolerance = 1e-5,
    minStep = 1e-5,
    maxStep = 0.2,
    maxSteps = 50000
  } = options;
  let h = initialStep;
  let state = { ...initial, t: initial.t ?? 0 };
  const points = [{ ...state }];
  let steps = 0;
  while (state.t < duration && steps < maxSteps) {
    h = Math.min(h, duration - state.t);
    const full = rk4Step(system, state, h);
    const half = rk4Step(system, rk4Step(system, state, h / 2), h / 2);
    const error = Math.hypot(full.x - half.x, full.y - half.y) / 15;
    if (!Number.isFinite(error)) throw new RangeError("Adaptive solver encountered a non-finite error estimate.");
    if (error <= tolerance || h <= minStep * 1.001) {
      state = { ...half, t: state.t + h };
      points.push({ ...state });
    }
    const factor = error === 0 ? 2 : Math.min(2, Math.max(.25, .9 * Math.pow(tolerance / error, .2)));
    h = Math.min(maxStep, Math.max(minStep, h * factor));
    steps += 1;
    if (Math.abs(state.x) > 1e5 || Math.abs(state.y) > 1e5) break;
  }
  return points;
}

export function trajectoryMetrics(points, target = { x: 8, y: 0 }) {
  if (!points.length) return { distance: Infinity, pathLength: 0, maxDeviation: 0, final: null };
  let pathLength = 0;
  let maxDeviation = 0;
  for (let i = 1; i < points.length; i += 1) {
    const a = points[i - 1], b = points[i];
    pathLength += Math.hypot(b.x - a.x, b.y - a.y);
    maxDeviation = Math.max(maxDeviation, Math.hypot(b.x - target.x, b.y - target.y));
  }
  const final = points[points.length - 1];
  return {
    distance: Math.hypot(final.x - target.x, final.y - target.y),
    pathLength,
    maxDeviation,
    final: { ...final }
  };
}

export function numericalJacobian(system, point, epsilon = 1e-5) {
  const fx1 = system({ ...point, x: point.x + epsilon });
  const fx0 = system({ ...point, x: point.x - epsilon });
  const fy1 = system({ ...point, y: point.y + epsilon });
  const fy0 = system({ ...point, y: point.y - epsilon });
  return {
    a: (fx1.x - fx0.x) / (2 * epsilon),
    b: (fy1.x - fy0.x) / (2 * epsilon),
    c: (fx1.y - fx0.y) / (2 * epsilon),
    d: (fy1.y - fy0.y) / (2 * epsilon)
  };
}

export function classifyLinearSystem(matrix) {
  const { a, b, c, d } = matrix;
  const trace = a + d;
  const determinant = a * d - b * c;
  const discriminant = trace * trace - 4 * determinant;
  if (determinant < 0) return { type: "Saddle", stable: false, stability: "unstable", trace, determinant, discriminant };
  if (determinant > 0 && trace < 0 && discriminant >= 0) return { type: "Stable node", stable: true, stability: "asymptotically stable", trace, determinant, discriminant };
  if (determinant > 0 && trace > 0 && discriminant >= 0) return { type: "Unstable node", stable: false, stability: "unstable", trace, determinant, discriminant };
  if (determinant > 0 && Math.abs(trace) < 1e-8 && discriminant < 0) return { type: "Center (linear)", stable: false, stability: "neutral in the linear model", trace, determinant, discriminant };
  if (determinant > 0 && trace < 0 && discriminant < 0) return { type: "Stable spiral", stable: true, stability: "asymptotically stable", trace, determinant, discriminant };
  if (determinant > 0 && trace > 0 && discriminant < 0) return { type: "Unstable spiral", stable: false, stability: "unstable", trace, determinant, discriminant };
  return { type: "Degenerate / inconclusive", stable: false, stability: "inconclusive", trace, determinant, discriminant };
}
