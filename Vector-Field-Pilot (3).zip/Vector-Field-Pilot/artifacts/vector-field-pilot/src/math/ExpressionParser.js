/**
 * Safe expression parser for the classroom equation editor.
 * It intentionally avoids eval() and Function().
 *
 * Grammar:
 * expression := term (("+" | "-") term)*
 * term       := unary (("*" | "/") unary)*
 * unary      := ("+" | "-") unary | power
 * power      := primary ("^" unary)?
 * primary    := NUMBER | VARIABLE | FUNCTION "(" expression ")" | "(" expression ")"
 */
const FUNCTIONS = Object.freeze({
  sin: Math.sin, cos: Math.cos, tan: Math.tan,
  asin: Math.asin, acos: Math.acos, atan: Math.atan,
  exp: Math.exp, log: Math.log, sqrt: Math.sqrt,
  abs: Math.abs, floor: Math.floor, ceil: Math.ceil,
  min: Math.min, max: Math.max
});

const CONSTANTS = Object.freeze({ pi: Math.PI, e: Math.E });
const TOKEN_PATTERN = /\s*(?:(\d+(?:\.\d*)?|\.\d+)(?:([eE][+-]?\d+))?|([a-zA-Z_][a-zA-Z_0-9]*)|(\*\*|[+\-*/^(),]))/y;

export class ExpressionError extends Error {
  constructor(message, position = -1) {
    super(message);
    this.name = "ExpressionError";
    this.position = position;
  }
}

export class ExpressionParser {
  constructor(source) {
    this.source = String(source ?? "").trim();
    this.tokens = [];
    this.cursor = 0;
    this.ast = null;
    this.tokenize();
  }

  tokenize() {
    let position = 0;
    while (position < this.source.length) {
      TOKEN_PATTERN.lastIndex = position;
      const match = TOKEN_PATTERN.exec(this.source);
      if (!match) {
        if (/^\s*$/.test(this.source.slice(position))) break;
        throw new ExpressionError(`Unexpected character "${this.source[position]}"`, position);
      }
      const [raw, number, exponent, identifier, operator] = match;
      const start = TOKEN_PATTERN.lastIndex - raw.length;
      position = TOKEN_PATTERN.lastIndex;
      if (number !== undefined) {
        this.tokens.push({ type: "number", value: Number(number + (exponent || "")), position: start });
      } else if (identifier !== undefined) {
        this.tokens.push({ type: "identifier", value: identifier.toLowerCase(), position: start });
      } else {
        this.tokens.push({ type: "operator", value: operator === "**" ? "^" : operator, position: start });
      }
    }
    this.tokens.push({ type: "eof", value: "", position: this.source.length });
    if (this.tokens.length === 1) throw new ExpressionError("Enter an equation before applying the model.");
  }

  peek() { return this.tokens[this.cursor]; }
  consume(value = null) {
    const token = this.peek();
    if (value !== null && token.value !== value) {
      throw new ExpressionError(`Expected "${value}" but found "${token.value || "end of expression"}".`, token.position);
    }
    this.cursor += 1;
    return token;
  }
  match(value) {
    if (this.peek().value === value) { this.cursor += 1; return true; }
    return false;
  }

  parse() {
    this.ast = this.parseExpression();
    if (this.peek().type !== "eof") {
      throw new ExpressionError(`Unexpected token "${this.peek().value}".`, this.peek().position);
    }
    return this.ast;
  }

  parseExpression() {
    let node = this.parseTerm();
    while (this.peek().value === "+" || this.peek().value === "-") {
      const operator = this.consume().value;
      node = { type: "binary", operator, left: node, right: this.parseTerm() };
    }
    return node;
  }

  parseTerm() {
    let node = this.parseUnary();
    while (this.peek().value === "*" || this.peek().value === "/") {
      const operator = this.consume().value;
      node = { type: "binary", operator, left: node, right: this.parseUnary() };
    }
    return node;
  }

  parseUnary() {
    if (this.match("+")) return { type: "unary", operator: "+", argument: this.parseUnary() };
    if (this.match("-")) return { type: "unary", operator: "-", argument: this.parseUnary() };
    return this.parsePower();
  }

  parsePower() {
    let node = this.parsePrimary();
    if (this.match("^")) node = { type: "binary", operator: "^", left: node, right: this.parseUnary() };
    return node;
  }

  parsePrimary() {
    const token = this.peek();
    if (token.type === "number") {
      this.consume();
      if (!Number.isFinite(token.value)) throw new ExpressionError("Number is outside the supported range.", token.position);
      return { type: "number", value: token.value };
    }
    if (token.type === "identifier") {
      this.consume();
      if (this.match("(")) {
        if (!Object.hasOwn(FUNCTIONS, token.value)) {
          throw new ExpressionError(`Function "${token.value}" is not supported.`, token.position);
        }
        const args = [this.parseExpression()];
        while (this.match(",")) args.push(this.parseExpression());
        this.consume(")");
        const expected = ["min", "max"].includes(token.value) ? null : 1;
        if (expected !== null && args.length !== expected) {
          throw new ExpressionError(`${token.value} expects one argument.`, token.position);
        }
        if (expected === null && args.length < 2) {
          throw new ExpressionError(`${token.value} expects at least two arguments.`, token.position);
        }
        return { type: "call", name: token.value, args };
      }
      if (Object.hasOwn(CONSTANTS, token.value)) return { type: "number", value: CONSTANTS[token.value] };
      if (!["x", "y", "z", "t"].includes(token.value)) {
        throw new ExpressionError(`Unknown variable "${token.value}". Use x, y, z, t, pi, or e.`, token.position);
      }
      return { type: "variable", name: token.value };
    }
    if (this.match("(")) {
      const node = this.parseExpression();
      this.consume(")");
      return node;
    }
    throw new ExpressionError(`Expected a number, variable, or parenthesized expression.`, token.position);
  }

  evaluate(scope = {}) {
    const tree = this.ast || this.parse();
    return evaluateNode(tree, {
      x: Number(scope.x ?? 0),
      y: Number(scope.y ?? 0),
      z: Number(scope.z ?? 0),
      t: Number(scope.t ?? 0)
    });
  }

  static compile(source) {
    const parser = new ExpressionParser(source);
    const ast = parser.parse();
    return Object.freeze({
      source: parser.source,
      ast,
      evaluate: (scope) => evaluateNode(ast, scope)
    });
  }
}

export function evaluateNode(node, scope) {
  switch (node.type) {
    case "number": return node.value;
    case "variable": return Number(scope[node.name] ?? 0);
    case "unary": {
      const value = evaluateNode(node.argument, scope);
      return node.operator === "-" ? -value : value;
    }
    case "binary": {
      const left = evaluateNode(node.left, scope);
      const right = evaluateNode(node.right, scope);
      switch (node.operator) {
        case "+": return left + right;
        case "-": return left - right;
        case "*": return left * right;
        case "/":
          if (Math.abs(right) < 1e-12) throw new ExpressionError("Division by zero in the current state.");
          return left / right;
        case "^": return Math.pow(left, right);
        default: throw new ExpressionError(`Unknown operator ${node.operator}.`);
      }
    }
    case "call": {
      const args = node.args.map((arg) => evaluateNode(arg, scope));
      return FUNCTIONS[node.name](...args);
    }
    default: throw new ExpressionError("The expression tree contains an unknown node.");
  }
}

export function validateExpression(source) {
  try {
    const compiled = ExpressionParser.compile(source);
    const sample = compiled.evaluate({ x: 0.37, y: -0.21, t: 0.4 });
    if (!Number.isFinite(sample)) return { valid: false, message: "This expression does not produce a finite result for a test state." };
    return { valid: true, compiled, sample };
  } catch (error) {
    return { valid: false, message: error.message, position: error.position ?? -1 };
  }
}
