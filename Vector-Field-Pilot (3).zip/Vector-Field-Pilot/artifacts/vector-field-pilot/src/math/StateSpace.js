/**
 * State-space utilities for representing higher-order ODEs as first-order systems.
 */
export class StateVector {
  constructor(values = []) {
    this.values = values.map(Number);
    if (!this.values.every(Number.isFinite)) throw new TypeError("State values must be finite.");
  }

  get length() { return this.values.length; }
  at(index) { return this.values[index]; }
  toArray() { return [...this.values]; }
  map(callback) { return new StateVector(this.values.map(callback)); }
  add(other) { return this.combine(other, (a, b) => a + b); }
  subtract(other) { return this.combine(other, (a, b) => a - b); }
  scale(value) { return new StateVector(this.values.map((item) => item * value)); }
  dot(other) {
    this.assertSameSize(other);
    return this.values.reduce((sum, item, index) => sum + item * other.values[index], 0);
  }
  norm() { return Math.sqrt(this.dot(this)); }
  combine(other, operation) {
    this.assertSameSize(other);
    return new StateVector(this.values.map((item, index) => operation(item, other.values[index])));
  }
  assertSameSize(other) {
    if (!(other instanceof StateVector) || other.length !== this.length) throw new TypeError("State vectors must have equal dimensions.");
  }
}

export class StateSpaceModel {
  constructor({ matrixA, matrixB = null, input = null, labels = [] } = {}) {
    this.A = matrixA.map((row) => row.map(Number));
    this.B = matrixB?.map((row) => row.map(Number)) ?? null;
    this.input = input;
    this.labels = labels.length ? [...labels] : this.A.map((_, index) => `x${index + 1}`);
    this.validate();
  }

  validate() {
    const size = this.A.length;
    if (!size || this.A.some((row) => row.length !== size)) throw new TypeError("A must be a non-empty square matrix.");
    if (this.A.flat().some((value) => !Number.isFinite(value))) throw new TypeError("A contains a non-finite value.");
    if (this.B && this.B.length !== size) throw new TypeError("B must have one row per state.");
  }

  derivative(state, time = 0, control = null) {
    const vector = state instanceof StateVector ? state : new StateVector(state);
    if (vector.length !== this.A.length) throw new TypeError("State dimension does not match the model.");
    const result = this.A.map((row) => row.reduce((sum, coefficient, index) => sum + coefficient * vector.at(index), 0));
    const u = control ?? this.input?.(vector.toArray(), time) ?? [];
    if (this.B && u.length) {
      this.B.forEach((row, index) => {
        result[index] += row.reduce((sum, coefficient, inputIndex) => sum + coefficient * (u[inputIndex] ?? 0), 0);
      });
    }
    return new StateVector(result);
  }

  simulate(initial, options = {}) {
    const dt = options.stepSize ?? .01;
    const duration = options.duration ?? 10;
    const count = Math.ceil(duration / dt);
    let state = new StateVector(initial);
    const history = [{ t: 0, state: state.toArray() }];
    for (let index = 0; index < count; index += 1) {
      const k1 = this.derivative(state, index * dt);
      const k2 = this.derivative(state.add(k1.scale(dt / 2)), index * dt + dt / 2);
      const k3 = this.derivative(state.add(k2.scale(dt / 2)), index * dt + dt / 2);
      const k4 = this.derivative(state.add(k3.scale(dt)), index * dt + dt);
      const increment = k1.add(k2.scale(2)).add(k3.scale(2)).add(k4).scale(dt / 6);
      state = state.add(increment);
      if (state.values.some((value) => !Number.isFinite(value) || Math.abs(value) > 1e8)) break;
      history.push({ t: (index + 1) * dt, state: state.toArray() });
    }
    return history;
  }

  toJSON() {
    return { matrixA: this.A, matrixB: this.B, labels: this.labels };
  }
}

export function secondOrderToStateSpace({ mass = 1, damping = 0, stiffness = 1, forcing = 0 } = {}) {
  const m = Math.max(1e-9, Number(mass));
  return new StateSpaceModel({
    matrixA: [[0, 1], [-stiffness / m, -damping / m]],
    matrixB: [[0], [1 / m]],
    input: () => [forcing],
    labels: ["displacement", "velocity"]
  });
}

export function matrixMultiply(matrix, vector) {
  return matrix.map((row) => row.reduce((sum, value, index) => sum + value * vector[index], 0));
}

export function matrixTranspose(matrix) {
  return matrix[0].map((_, column) => matrix.map((row) => row[column]));
}

export function matrixTrace(matrix) {
  return matrix.reduce((sum, row, index) => sum + (row[index] ?? 0), 0);
}

export function matrixDeterminant2(matrix) {
  if (matrix.length !== 2 || matrix.some((row) => row.length !== 2)) throw new TypeError("Expected a 2x2 matrix.");
  return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
}
