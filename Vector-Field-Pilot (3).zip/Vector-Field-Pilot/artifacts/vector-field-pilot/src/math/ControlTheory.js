/**
 * Control-theory helpers for educational feedback experiments.
 * These functions are model-agnostic and return data for the UI to visualize.
 */
export function proportional(error, gain = 1) {
  return gain * error;
}

export function derivativeDamping(rate, gain = 0) {
  return -gain * rate;
}

export function proportionalDerivative(error, rate, kp = 1, kd = 0) {
  return proportional(error, kp) + derivativeDamping(rate, kd);
}

export function proportionalIntegralDerivative(error, integral, rate, gains = {}) {
  const kp = Number(gains.kp ?? 1);
  const ki = Number(gains.ki ?? 0);
  const kd = Number(gains.kd ?? 0);
  return kp * error + ki * integral - kd * rate;
}

export class PIDController {
  constructor({ kp = 1, ki = 0, kd = 0, integralLimit = 100, outputLimit = 100 } = {}) {
    this.kp = kp;
    this.ki = ki;
    this.kd = kd;
    this.integralLimit = Math.abs(integralLimit);
    this.outputLimit = Math.abs(outputLimit);
    this.integral = 0;
    this.previousError = null;
    this.lastOutput = 0;
  }

  reset() {
    this.integral = 0;
    this.previousError = null;
    this.lastOutput = 0;
  }

  update(target, measured, deltaTime) {
    const dt = Math.max(1e-6, Number(deltaTime) || 0);
    const error = target - measured;
    this.integral = clamp(this.integral + error * dt, -this.integralLimit, this.integralLimit);
    const derivative = this.previousError === null ? 0 : (error - this.previousError) / dt;
    const raw = this.kp * error + this.ki * this.integral + this.kd * derivative;
    this.previousError = error;
    this.lastOutput = clamp(raw, -this.outputLimit, this.outputLimit);
    return this.lastOutput;
  }

  tune(values = {}) {
    for (const key of ["kp", "ki", "kd"]) {
      if (Number.isFinite(values[key])) this[key] = values[key];
    }
    return this.snapshot();
  }

  snapshot() {
    return {
      kp: this.kp,
      ki: this.ki,
      kd: this.kd,
      integral: this.integral,
      previousError: this.previousError,
      output: this.lastOutput
    };
  }
}

export class FeedbackLoop {
  constructor({ target = 0, controller = new PIDController(), plant, sampleRate = .02 } = {}) {
    if (typeof plant !== "function") throw new TypeError("FeedbackLoop requires a plant function.");
    this.target = target;
    this.controller = controller;
    this.plant = plant;
    this.sampleRate = sampleRate;
    this.time = 0;
    this.state = 0;
    this.history = [];
  }

  reset(initialState = 0) {
    this.time = 0;
    this.state = initialState;
    this.history = [];
    this.controller.reset();
  }

  step(inputDisturbance = 0) {
    const control = this.controller.update(this.target, this.state, this.sampleRate);
    const derivative = this.plant(this.state, control + inputDisturbance, this.time);
    if (!Number.isFinite(derivative)) throw new RangeError("Plant returned an invalid derivative.");
    this.state += derivative * this.sampleRate;
    this.time += this.sampleRate;
    const sample = { time: this.time, state: this.state, control, disturbance: inputDisturbance, error: this.target - this.state };
    this.history.push(sample);
    return { ...sample };
  }

  run(duration, disturbance = () => 0) {
    const steps = Math.ceil(duration / this.sampleRate);
    for (let index = 0; index < steps; index += 1) this.step(disturbance(this.time));
    return this.history.map((item) => ({ ...item }));
  }
}

export function secondOrderParameters(stiffness, damping, mass = 1) {
  const m = Math.max(1e-9, Math.abs(mass));
  const k = Number(stiffness);
  const c = Number(damping);
  const naturalFrequency = Math.sqrt(Math.max(0, k / m));
  const dampingRatio = naturalFrequency === 0 ? Infinity : c / (2 * Math.sqrt(m * k));
  let regime = "non-restoring";
  if (k > 0 && dampingRatio < 1) regime = "underdamped";
  if (k > 0 && Math.abs(dampingRatio - 1) < 1e-6) regime = "critically damped";
  if (k > 0 && dampingRatio > 1) regime = "overdamped";
  return { mass: m, stiffness: k, damping: c, naturalFrequency, dampingRatio, regime };
}

export function stepResponse({ stiffness = 1, damping = .4, mass = 1, duration = 12, step = .02 } = {}) {
  const model = secondOrderParameters(stiffness, damping, mass);
  let position = 0;
  let velocity = 0;
  let time = 0;
  const output = [];
  const count = Math.ceil(duration / step);
  for (let index = 0; index <= count; index += 1) {
    const acceleration = (1 - stiffness * position - damping * velocity) / model.mass;
    velocity += acceleration * step;
    position += velocity * step;
    time += step;
    output.push({ time, position, velocity, acceleration });
  }
  return output;
}

export function gainSweep(gains, plantFactory, options = {}) {
  return gains.map((gain) => {
    const loop = new FeedbackLoop({
      target: options.target ?? 1,
      controller: new PIDController({ kp: gain, kd: options.kd ?? 0, ki: options.ki ?? 0 }),
      plant: plantFactory(gain),
      sampleRate: options.sampleRate ?? .02
    });
    loop.reset(options.initial ?? 0);
    const history = loop.run(options.duration ?? 8);
    const final = history.at(-1) ?? { state: options.initial ?? 0, error: 0 };
    const overshoot = Math.max(0, ...history.map((point) => point.state - loop.target));
    return { gain, finalState: final.state, finalError: final.error, overshoot, history };
  });
}

export function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, value));
}
