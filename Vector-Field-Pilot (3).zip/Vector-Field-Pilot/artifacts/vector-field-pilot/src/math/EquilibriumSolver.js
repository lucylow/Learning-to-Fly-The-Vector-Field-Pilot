import { finiteDifference, newton } from "./RootFinding.js";
import { numericalJacobian, classifyLinearSystem } from "./ODESolver.js";
import { eigenDecomposition2 } from "./Matrix.js";

/**
 * Approximate equilibrium finder for a two-dimensional vector field.
 * Uses damped Newton iterations on the pair (f(x,y), g(x,y)).
 */
export class EquilibriumSolver {
  constructor(system) { this.system = system; }

  residual(point) {
    const value = this.system(point);
    if (![value?.x, value?.y].every(Number.isFinite)) {
      throw new RangeError("The vector field is not finite at this state.");
    }
    return Math.hypot(value.x, value.y);
  }

  solve(seed, options = {}) {
    const tolerance = options.tolerance ?? 1e-8;
    const maxIterations = options.maxIterations ?? 50;
    const damping = options.damping ?? .8;
    const fixedTime = Number(options.time ?? seed.t ?? 0);
    const fixedZ = Number(options.z ?? seed.z ?? 0);
    const maxStep = options.maxStep ?? 10;
    if (!(Number.isFinite(tolerance) && tolerance > 0) ||
        !Number.isInteger(maxIterations) || maxIterations < 1 || maxIterations > 1000 ||
        !(Number.isFinite(damping) && damping > 0 && damping <= 1) ||
        !(Number.isFinite(maxStep) && maxStep > 0) ||
        !(Number.isFinite(options.jacobianStep ?? 1e-5) && (options.jacobianStep ?? 1e-5) > 0) ||
        ![Number(seed.x), Number(seed.y), fixedTime, fixedZ].every(Number.isFinite)) {
      throw new RangeError("Equilibrium search needs finite starting values and valid iteration settings.");
    }
    let point = { x: Number(seed.x), y: Number(seed.y), z: fixedZ, t: fixedTime };
    let converged = false;
    let iteration = 0;
    let reason = "iteration-limit";
    let failure = null;
    let residual = Infinity;
    try {
      residual = this.residual(point);
      if (residual <= tolerance) {
        converged = true;
        reason = "converged";
      }
      for (; !converged && iteration < maxIterations; iteration += 1) {
        const jacobian = numericalJacobian(this.system, point, options.jacobianStep ?? 1e-5);
        const determinant = jacobian.a * jacobian.d - jacobian.b * jacobian.c;
        if (!Number.isFinite(determinant) || Math.abs(determinant) < 1e-12) {
          reason = "singular-jacobian";
          break;
        }
        const value = this.system(point);
        if (![value?.x, value?.y].every(Number.isFinite)) throw new RangeError("The vector field is not finite at this state.");
        const dx = (jacobian.d * value.x - jacobian.b * value.y) / determinant;
        const dy = (-jacobian.c * value.x + jacobian.a * value.y) / determinant;
        if (![dx, dy].every(Number.isFinite)) {
          reason = "non-finite-step";
          break;
        }
        const rawSize = Math.hypot(dx, dy);
        const stepScale = rawSize > maxStep ? maxStep / rawSize : 1;
        let amount = damping * stepScale;
        let accepted = null;
        while (amount >= .0125) {
          const candidate = { ...point, x: point.x - amount * dx, y: point.y - amount * dy };
          if (![candidate.x, candidate.y].every(Number.isFinite)) {
            amount /= 2;
            continue;
          }
          let candidateResidual;
          try {
            candidateResidual = this.residual(candidate);
          } catch {
            amount /= 2;
            continue;
          }
          if (candidateResidual < residual || candidateResidual <= tolerance) {
            accepted = { point: candidate, residual: candidateResidual };
            break;
          }
          amount /= 2;
        }
        if (!accepted) {
          reason = "no-descent";
          break;
        }
        point = accepted.point;
        residual = accepted.residual;
        if (residual <= tolerance) {
          converged = true;
          reason = "converged";
          iteration += 1;
          break;
        }
      }
      if (!converged && reason === "iteration-limit" && iteration >= maxIterations) {
        reason = "iteration-limit";
      }
    } catch (error) {
      failure = error?.message ?? "The vector field could not be evaluated.";
      reason = "invalid-evaluation";
    }
    try {
      residual = this.residual(point);
    } catch (error) {
      failure ??= error?.message ?? "The vector field could not be evaluated.";
      reason = "invalid-evaluation";
    }
    let matrix = null;
    let classification = null;
    let eigen = null;
    try {
      matrix = numericalJacobian(this.system, point, options.jacobianStep ?? 1e-5);
      classification = classifyLinearSystem(matrix);
      eigen = eigenDecomposition2([[matrix.a, matrix.b], [matrix.c, matrix.d]]);
    } catch (error) {
      failure ??= error?.message ?? "The local linear model could not be calculated.";
    }
    return {
      point,
      residual,
      iterations: iteration,
      converged: converged || residual <= tolerance,
      jacobian: matrix,
      classification,
      eigen,
      reason,
      failure
    };
  }

  scan(bounds, options = {}) {
    if (![bounds?.xMin, bounds?.xMax, bounds?.yMin, bounds?.yMax].every(Number.isFinite) ||
        !(bounds.xMin < bounds.xMax) || !(bounds.yMin < bounds.yMax)) {
      throw new RangeError("Equilibrium search bounds must be finite and increasing.");
    }
    const seeds = [];
    const rows = options.rows ?? 12;
    const columns = options.columns ?? 12;
    if (![rows, columns].every((value) => Number.isInteger(value) && value >= 2 && value <= 100)) {
      throw new RangeError("Equilibrium search grid dimensions must be between 2 and 100.");
    }
    for (let row = 0; row < rows; row += 1) {
      for (let column = 0; column < columns; column += 1) {
        seeds.push({
          x: bounds.xMin + (bounds.xMax - bounds.xMin) * column / Math.max(1, columns - 1),
          y: bounds.yMin + (bounds.yMax - bounds.yMin) * row / Math.max(1, rows - 1)
        });
      }
    }
    const candidates = seeds.map((seed) => this.solve(seed, options)).filter((item) =>
      item.converged &&
      item.point.x >= bounds.xMin - (options.boundTolerance ?? .1) &&
      item.point.x <= bounds.xMax + (options.boundTolerance ?? .1) &&
      item.point.y >= bounds.yMin - (options.boundTolerance ?? .1) &&
      item.point.y <= bounds.yMax + (options.boundTolerance ?? .1)
    );
    return deduplicateEquilibria(candidates, options.mergeDistance ?? .1);
  }

  analyze(point, options = {}) {
    const result = this.solve(point, options);
    if (!result.converged || !result.jacobian || !result.classification) {
      return {
        ...result,
        trace: null,
        determinant: null,
        description: result.failure ?? "No equilibrium converged from this starting point."
      };
    }
    const trace = result.jacobian.a + result.jacobian.d;
    const determinant = result.jacobian.a * result.jacobian.d - result.jacobian.b * result.jacobian.c;
    return {
      ...result,
      trace,
      determinant,
      description: describeClassification(result.classification.type),
      linearization: {
        x: `u′ ≈ ${formatTerm(result.jacobian.a, "u")} ${formatSignedTerm(result.jacobian.b, "v")}`,
        y: `v′ ≈ ${formatTerm(result.jacobian.c, "u")} ${formatSignedTerm(result.jacobian.d, "v")}`
      }
    };
  }
}

function formatTerm(value, variable) { return `${Number(value).toFixed(4)}${variable}`; }
function formatSignedTerm(value, variable) {
  return `${value < 0 ? " − " : " + "}${Math.abs(Number(value)).toFixed(4)}${variable}`;
}

export function deduplicateEquilibria(items, distance = .1) {
  const output = [];
  for (const item of items) {
    if (!output.some((other) => Math.hypot(item.point.x - other.point.x, item.point.y - other.point.y) < distance)) output.push(item);
  }
  return output;
}

export function describeClassification(type) {
  const descriptions = {
    "Stable node": "Nearby trajectories approach the equilibrium without rotating in the linearized picture.",
    "Unstable node": "Nearby trajectories move away from the equilibrium in the linearized picture.",
    "Saddle": "The equilibrium attracts along one direction and repels along another.",
    "Stable spiral": "Nearby trajectories rotate while approaching the equilibrium.",
    "Unstable spiral": "Nearby trajectories rotate while moving away from the equilibrium.",
    "Center (linear)": "The linearized system has closed orbits around the equilibrium."
  };
  return descriptions[type] ?? "The local linear classification is inconclusive.";
}

export function scalarEquilibrium(fn, initial, options = {}) {
  const derivative = (x) => finiteDifference(fn, x);
  return newton(fn, derivative, initial, options);
}
