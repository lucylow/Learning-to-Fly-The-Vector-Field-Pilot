/**
 * Post-flight trajectory analysis and educational descriptions.
 */
export function computeVelocity(points) {
  return points.slice(1).map((point, index) => {
    const previous = points[index];
    const dt = Math.max(1e-9, point.t - previous.t);
    return { t: point.t, vx: (point.x - previous.x) / dt, vy: (point.y - previous.y) / dt };
  });
}

export function computeAcceleration(points) {
  const velocity = computeVelocity(points);
  return velocity.slice(1).map((point, index) => {
    const previous = velocity[index];
    const dt = Math.max(1e-9, point.t - previous.t);
    return { t: point.t, ax: (point.vx - previous.vx) / dt, ay: (point.vy - previous.vy) / dt };
  });
}

export function computeCurvature(points) {
  const output = [];
  for (let index = 1; index < points.length - 1; index += 1) {
    const a = points[index - 1], b = points[index], c = points[index + 1];
    const ab = Math.hypot(b.x - a.x, b.y - a.y);
    const bc = Math.hypot(c.x - b.x, c.y - b.y);
    const ac = Math.hypot(c.x - a.x, c.y - a.y);
    const area2 = Math.abs((b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x));
    const curvature = ab * bc * ac < 1e-12 ? 0 : 2 * area2 / (ab * bc * ac);
    output.push({ t: b.t, curvature });
  }
  return output;
}

export function summarizeTrajectory(points, target = { x: 0, y: 0 }) {
  if (!points.length) return { count: 0, duration: 0, length: 0, finalError: Infinity, bounds: null };
  let length = 0;
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  let maximumSpeed = 0;
  for (let index = 0; index < points.length; index += 1) {
    const point = points[index];
    minX = Math.min(minX, point.x); maxX = Math.max(maxX, point.x);
    minY = Math.min(minY, point.y); maxY = Math.max(maxY, point.y);
    if (index > 0) {
      const previous = points[index - 1];
      const dt = Math.max(1e-9, point.t - previous.t);
      const dx = point.x - previous.x, dy = point.y - previous.y;
      length += Math.hypot(dx, dy);
      maximumSpeed = Math.max(maximumSpeed, Math.hypot(dx, dy) / dt);
    }
  }
  const final = points.at(-1);
  return {
    count: points.length,
    duration: final.t - points[0].t,
    length,
    finalError: Math.hypot(final.x - target.x, final.y - target.y),
    maximumSpeed,
    bounds: { minX, maxX, minY, maxY }
  };
}

export function detectOscillations(points, axis = "x") {
  const turns = [];
  for (let index = 1; index < points.length - 1; index += 1) {
    const before = points[index][axis] - points[index - 1][axis];
    const after = points[index + 1][axis] - points[index][axis];
    if (before === 0 || after === 0) continue;
    if (Math.sign(before) !== Math.sign(after)) turns.push({ index, t: points[index].t, value: points[index][axis] });
  }
  const amplitudes = turns.map((turn) => Math.abs(turn.value));
  const trend = amplitudes.length < 2 ? "insufficient-data" :
    amplitudes.at(-1) < amplitudes[0] * .8 ? "decaying" :
    amplitudes.at(-1) > amplitudes[0] * 1.2 ? "growing" : "roughly-constant";
  return { turns, count: turns.length, amplitudes, trend };
}

export function classifyTrajectory(points) {
  if (points.length < 4) return { label: "Short trajectory", explanation: "More simulation data is needed." };
  const summary = summarizeTrajectory(points);
  const oscillations = detectOscillations(points);
  if (summary.finalError < .15) return { label: "Near-equilibrium arrival", explanation: "The final state is close to the origin." };
  if (oscillations.count >= 3 && oscillations.trend === "decaying") return { label: "Damped oscillation", explanation: "The path changes direction repeatedly while its turning amplitudes decrease." };
  if (oscillations.count >= 3 && oscillations.trend === "growing") return { label: "Growing oscillation", explanation: "Repeated turns have increasing amplitude in the sampled trajectory." };
  if (summary.maximumSpeed > 10) return { label: "Rapid divergence", explanation: "The trajectory reaches a high rate of change." };
  return { label: "General trajectory", explanation: "Inspect the vector field and state rates to interpret this path." };
}

export function compareTrajectories(first, second) {
  const count = Math.min(first.length, second.length);
  const samples = [];
  let maximumSeparation = 0;
  let totalSeparation = 0;
  for (let index = 0; index < count; index += 1) {
    const separation = Math.hypot(first[index].x - second[index].x, first[index].y - second[index].y);
    maximumSeparation = Math.max(maximumSeparation, separation);
    totalSeparation += separation;
    samples.push({ index, separation });
  }
  return {
    samples,
    maximumSeparation,
    averageSeparation: count ? totalSeparation / count : 0
  };
}
