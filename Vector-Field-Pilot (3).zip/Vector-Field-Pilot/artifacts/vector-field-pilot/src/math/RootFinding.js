/**
 * One-dimensional root-finding methods used by equilibrium and lesson tools.
 */
export function bisection(fn, left, right, options = {}) {
  const tolerance = options.tolerance ?? 1e-8;
  const maxIterations = options.maxIterations ?? 100;
  let a = left, b = right, fa = fn(a), fb = fn(b);
  if (!Number.isFinite(fa) || !Number.isFinite(fb)) throw new RangeError("Function must be finite at bracket endpoints.");
  if (fa === 0) return result(a, 0, 0, true);
  if (fb === 0) return result(b, 0, 0, true);
  if (Math.sign(fa) === Math.sign(fb)) throw new RangeError("Bisection requires a sign-changing bracket.");
  let midpoint = (a + b) / 2;
  let fm = fn(midpoint);
  for (let iteration = 1; iteration <= maxIterations; iteration += 1) {
    midpoint = (a + b) / 2;
    fm = fn(midpoint);
    if (Math.abs(fm) <= tolerance || Math.abs(b - a) / 2 <= tolerance) return result(midpoint, fm, iteration, true);
    if (Math.sign(fm) === Math.sign(fa)) { a = midpoint; fa = fm; }
    else { b = midpoint; fb = fm; }
  }
  return result(midpoint, fm, maxIterations, false);
}

export function newton(fn, derivative, initial, options = {}) {
  const tolerance = options.tolerance ?? 1e-8;
  const maxIterations = options.maxIterations ?? 50;
  let x = initial;
  for (let iteration = 1; iteration <= maxIterations; iteration += 1) {
    const value = fn(x);
    const slope = derivative(x);
    if (!Number.isFinite(value) || !Number.isFinite(slope)) throw new RangeError("Newton iteration encountered a non-finite value.");
    if (Math.abs(value) <= tolerance) return result(x, value, iteration - 1, true);
    if (Math.abs(slope) < 1e-12) return result(x, value, iteration, false);
    const next = x - value / slope;
    if (!Number.isFinite(next)) return result(x, value, iteration, false);
    if (Math.abs(next - x) <= tolerance) return result(next, fn(next), iteration, true);
    x = next;
  }
  return result(x, fn(x), maxIterations, false);
}

export function secant(fn, first, second, options = {}) {
  const tolerance = options.tolerance ?? 1e-8;
  const maxIterations = options.maxIterations ?? 60;
  let x0 = first, x1 = second;
  let f0 = fn(x0), f1 = fn(x1);
  for (let iteration = 1; iteration <= maxIterations; iteration += 1) {
    const denominator = f1 - f0;
    if (Math.abs(denominator) < 1e-14) return result(x1, f1, iteration, false);
    const x2 = x1 - f1 * (x1 - x0) / denominator;
    if (!Number.isFinite(x2)) return result(x1, f1, iteration, false);
    const f2 = fn(x2);
    if (Math.abs(f2) <= tolerance || Math.abs(x2 - x1) <= tolerance) return result(x2, f2, iteration, true);
    x0 = x1; f0 = f1; x1 = x2; f1 = f2;
  }
  return result(x1, f1, maxIterations, false);
}

export function finiteDifference(fn, x, step = 1e-5) {
  return (fn(x + step) - fn(x - step)) / (2 * step);
}

export function scanForBrackets(fn, minimum, maximum, samples = 100) {
  const brackets = [];
  let previousX = minimum;
  let previousY = fn(previousX);
  for (let index = 1; index <= samples; index += 1) {
    const currentX = minimum + (maximum - minimum) * index / samples;
    const currentY = fn(currentX);
    if (Number.isFinite(previousY) && Number.isFinite(currentY) && Math.sign(previousY) !== Math.sign(currentY)) {
      brackets.push([previousX, currentX]);
    }
    previousX = currentX;
    previousY = currentY;
  }
  return brackets;
}

export function findRoots(fn, minimum, maximum, options = {}) {
  const brackets = scanForBrackets(fn, minimum, maximum, options.samples ?? 300);
  return brackets.map(([left, right]) => bisection(fn, left, right, options)).filter((item) => item.converged);
}

function result(root, residual, iterations, converged) {
  return { root, residual, iterations, converged };
}
