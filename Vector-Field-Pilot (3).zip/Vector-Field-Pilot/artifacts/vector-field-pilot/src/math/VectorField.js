import { rk4Step } from "./ODESolver.js";

export class VectorField {
  constructor(system, bounds = { xMin: -10, xMax: 10, yMin: -6, yMax: 6 }) {
    this.system = system;
    this.bounds = bounds;
  }

  sample(columns = 19, rows = 13, time = 0) {
    const { xMin, xMax, yMin, yMax } = this.bounds;
    const vectors = [];
    for (let row = 0; row < rows; row += 1) {
      const y = yMax - (row / Math.max(1, rows - 1)) * (yMax - yMin);
      for (let column = 0; column < columns; column += 1) {
        const x = xMin + (column / Math.max(1, columns - 1)) * (xMax - xMin);
        try {
          const value = this.system({ x, y, t: time });
          const magnitude = Math.hypot(value.x, value.y);
          if (Number.isFinite(magnitude)) vectors.push({ x, y, dx: value.x, dy: value.y, magnitude });
        } catch { /* Invalid local values are omitted from the visualization. */ }
      }
    }
    return vectors;
  }

  streamlines(seeds, options = {}) {
    const { stepSize = .06, duration = 8 } = options;
    return seeds.map((seed) => {
      const points = [{ ...seed, t: 0 }];
      let state = { ...seed, t: 0 };
      const count = Math.ceil(duration / stepSize);
      for (let i = 0; i < count; i += 1) {
        try {
          state = rk4Step(this.system, state, stepSize);
          if (!Number.isFinite(state.x + state.y) || Math.abs(state.x) > 30 || Math.abs(state.y) > 20) break;
          points.push({ ...state });
        } catch { break; }
      }
      return points;
    });
  }

  findEquilibria(grid = 20, threshold = .12) {
    const samples = this.sample(grid, grid);
    const candidates = samples.filter((item) => item.magnitude < threshold);
    const unique = [];
    for (const candidate of candidates) {
      if (!unique.some((item) => Math.hypot(item.x - candidate.x, item.y - candidate.y) < .5)) {
        unique.push({ x: candidate.x, y: candidate.y, residual: candidate.magnitude });
      }
    }
    return unique;
  }
}

export function worldToCanvas(point, bounds, width, height) {
  const x = (point.x - bounds.xMin) / (bounds.xMax - bounds.xMin) * width;
  const y = height - (point.y - bounds.yMin) / (bounds.yMax - bounds.yMin) * height;
  return { x, y };
}

export function canvasToWorld(point, bounds, width, height) {
  return {
    x: bounds.xMin + point.x / width * (bounds.xMax - bounds.xMin),
    y: bounds.yMin + (height - point.y) / height * (bounds.yMax - bounds.yMin)
  };
}
