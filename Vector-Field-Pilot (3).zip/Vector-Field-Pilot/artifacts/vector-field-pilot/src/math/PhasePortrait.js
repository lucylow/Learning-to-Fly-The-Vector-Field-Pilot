import { VectorField } from "./VectorField.js";
import { numericalJacobian, classifyLinearSystem } from "./ODESolver.js";

/**
 * Phase portrait analysis for two-dimensional autonomous systems.
 * Time-dependent systems are sampled at a selected snapshot time.
 */
export class PhasePortrait {
  constructor(system, bounds) {
    this.system = system;
    this.field = new VectorField(system, bounds);
    this.bounds = bounds ?? this.field.bounds;
  }

  sample(time = 0, resolution = { columns: 25, rows: 17 }) {
    const vectors = this.field.sample(resolution.columns, resolution.rows, time);
    const maximum = Math.max(1e-12, ...vectors.map((item) => item.magnitude));
    return vectors.map((item) => ({
      ...item,
      normalizedX: item.dx / Math.max(item.magnitude, 1e-12),
      normalizedY: item.dy / Math.max(item.magnitude, 1e-12),
      relativeMagnitude: item.magnitude / maximum
    }));
  }

  trace(seed, options = {}) {
    const forward = this.field.streamlines([seed], options)[0] ?? [];
    const reverseSystem = (state) => {
      const value = this.system(state);
      return { x: -value.x, y: -value.y };
    };
    const reverseField = new VectorField(reverseSystem, this.bounds);
    const backward = reverseField.streamlines([seed], options)[0] ?? [];
    return [...backward.slice(1).reverse(), ...forward];
  }

  classifyAt(point, epsilon = 1e-5) {
    const jacobian = numericalJacobian(this.system, point, epsilon);
    const classification = classifyLinearSystem(jacobian);
    return { point: { ...point }, jacobian, classification };
  }

  nullclines(bounds = this.bounds, samples = 200) {
    const xNullcline = [];
    const yNullcline = [];
    const { xMin, xMax, yMin, yMax } = bounds;
    for (let index = 0; index <= samples; index += 1) {
      const x = xMin + (xMax - xMin) * index / samples;
      const y = yMin + (yMax - yMin) * index / samples;
      for (let j = 0; j <= samples; j += 1) {
        const yy = yMin + (yMax - yMin) * j / samples;
        const xx = xMin + (xMax - xMin) * j / samples;
        try {
          const horizontal = this.system({ x, y: yy, t: 0 });
          const vertical = this.system({ x: xx, y, t: 0 });
          if (Math.abs(horizontal.x) < .025) xNullcline.push({ x, y: yy });
          if (Math.abs(vertical.y) < .025) yNullcline.push({ x: xx, y });
        } catch { /* Ignore singular samples. */ }
      }
    }
    return { xNullcline: deduplicate(xNullcline, .08), yNullcline: deduplicate(yNullcline, .08) };
  }

  equilibriumCandidates(options = {}) {
    return this.field.findEquilibria(options.grid ?? 35, options.threshold ?? .08)
      .map((point) => this.classifyAt(point));
  }

  describeEquilibrium(item) {
    const type = item.classification.type.toLowerCase();
    if (type.includes("saddle")) return "Nearby motion approaches along one direction and moves away along another.";
    if (type.includes("stable")) return "Nearby trajectories tend to approach the equilibrium in the linearized model.";
    if (type.includes("unstable")) return "Nearby trajectories tend to move away from the equilibrium in the linearized model.";
    if (type.includes("center")) return "The linearized model has closed orbits around this equilibrium; nonlinear effects may change the result.";
    return "The local classification is inconclusive or degenerate.";
  }
}

function deduplicate(points, distance) {
  const output = [];
  for (const point of points) {
    if (!output.some((item) => Math.hypot(item.x - point.x, item.y - point.y) < distance)) output.push(point);
  }
  return output;
}
