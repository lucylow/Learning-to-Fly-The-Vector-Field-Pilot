/**
 * Small dense-matrix utilities for two-dimensional and classroom state-space work.
 * Matrices are represented as arrays of rows.
 */
export function shape(matrix) {
  return { rows: matrix.length, columns: matrix[0]?.length ?? 0 };
}

export function validateMatrix(matrix) {
  if (!Array.isArray(matrix) || !matrix.length || !Array.isArray(matrix[0])) return false;
  const columns = matrix[0].length;
  return columns > 0 && matrix.every((row) => Array.isArray(row) && row.length === columns && row.every(Number.isFinite));
}

export function zeros(rows, columns = rows) {
  return Array.from({ length: rows }, () => Array(columns).fill(0));
}

export function identity(size) {
  const result = zeros(size);
  for (let index = 0; index < size; index += 1) result[index][index] = 1;
  return result;
}

export function addMatrices(a, b) {
  assertSameShape(a, b);
  return a.map((row, i) => row.map((value, j) => value + b[i][j]));
}

export function subtractMatrices(a, b) {
  assertSameShape(a, b);
  return a.map((row, i) => row.map((value, j) => value - b[i][j]));
}

export function scaleMatrix(matrix, scalar) {
  return matrix.map((row) => row.map((value) => value * scalar));
}

export function multiplyMatrices(a, b) {
  if (!validateMatrix(a) || !validateMatrix(b) || a[0].length !== b.length) {
    throw new TypeError("Matrix dimensions are not compatible for multiplication.");
  }
  const output = zeros(a.length, b[0].length);
  for (let i = 0; i < a.length; i += 1) {
    for (let k = 0; k < b.length; k += 1) {
      for (let j = 0; j < b[0].length; j += 1) output[i][j] += a[i][k] * b[k][j];
    }
  }
  return output;
}

export function multiplyMatrixVector(matrix, vector) {
  if (!validateMatrix(matrix) || matrix[0].length !== vector.length) throw new TypeError("Matrix and vector dimensions do not match.");
  return matrix.map((row) => row.reduce((sum, value, index) => sum + value * vector[index], 0));
}

export function transpose(matrix) {
  if (!validateMatrix(matrix)) throw new TypeError("Expected a rectangular numeric matrix.");
  return matrix[0].map((_, column) => matrix.map((row) => row[column]));
}

export function trace(matrix) {
  if (!validateMatrix(matrix) || matrix.length !== matrix[0].length) throw new TypeError("Trace requires a square matrix.");
  return matrix.reduce((sum, row, index) => sum + row[index], 0);
}

export function determinant2(matrix) {
  if (shape(matrix).rows !== 2 || shape(matrix).columns !== 2) throw new TypeError("Expected a 2x2 matrix.");
  return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
}

export function inverse2(matrix) {
  const determinant = determinant2(matrix);
  if (Math.abs(determinant) < 1e-12) throw new RangeError("Matrix is singular.");
  return [
    [matrix[1][1] / determinant, -matrix[0][1] / determinant],
    [-matrix[1][0] / determinant, matrix[0][0] / determinant]
  ];
}

export function solve2(matrix, vector) {
  return multiplyMatrixVector(inverse2(matrix), vector);
}

export function matrixNormInfinity(matrix) {
  return Math.max(0, ...matrix.map((row) => row.reduce((sum, value) => sum + Math.abs(value), 0)));
}

export function formatMatrix(matrix, digits = 3) {
  return matrix.map((row) => `[ ${row.map((value) => Number(value).toFixed(digits)).join("  ")} ]`).join("\n");
}

export function assertSameShape(a, b) {
  const first = shape(a), second = shape(b);
  if (first.rows !== second.rows || first.columns !== second.columns) throw new TypeError("Matrix shapes must match.");
}

export function jacobiEigenvaluesSymmetric2(matrix) {
  if (shape(matrix).rows !== 2 || shape(matrix).columns !== 2) throw new TypeError("Expected a 2x2 matrix.");
  const a = matrix[0][0], b = (matrix[0][1] + matrix[1][0]) / 2, d = matrix[1][1];
  const center = (a + d) / 2;
  const radius = Math.sqrt(((a - d) / 2) ** 2 + b ** 2);
  return [center - radius, center + radius];
}

/**
 * Return the eigenvalues and normalized eigenvectors of a real 2x2 matrix.
 * Complex values are stored as { real, imag }; eigenvectors use the same
 * representation for each component so a real matrix's spiral directions
 * remain explicit instead of being reduced to a misleading real vector.
 */
export function eigenDecomposition2(matrix, tolerance = 1e-10) {
  if (!validateMatrix(matrix) || matrix.length !== 2 || matrix[0].length !== 2) {
    throw new TypeError("Eigen decomposition requires a finite 2x2 matrix.");
  }
  const [[a, b], [c, d]] = matrix;
  const traceValue = a + d;
  const determinantValue = a * d - b * c;
  const discriminant = traceValue * traceValue - 4 * determinantValue;
  if (![traceValue, determinantValue, discriminant].every(Number.isFinite)) {
    throw new RangeError("Matrix values are too large for a finite eigen decomposition.");
  }

  if (discriminant >= -tolerance) {
    const root = Math.sqrt(Math.max(0, discriminant));
    const values = [
      { real: (traceValue - root) / 2, imag: 0 },
      { real: (traceValue + root) / 2, imag: 0 }
    ];
    const eigenvectors = values.map((value, index) => ({
      real: realEigenvector(a, b, c, d, value.real, index, tolerance),
      imag: [0, 0]
    }));
    return { values, eigenvectors, discriminant, hasRealEigenvalues: true };
  }

  const imaginaryPart = Math.sqrt(-discriminant) / 2;
  const values = [
    { real: traceValue / 2, imag: -imaginaryPart },
    { real: traceValue / 2, imag: imaginaryPart }
  ];
  const eigenvectors = values.map((value) => complexEigenvector(a, b, c, d, value, tolerance));
  return { values, eigenvectors, discriminant, hasRealEigenvalues: false };
}

function realEigenvector(a, b, c, d, lambda, index, tolerance) {
  const first = [b, lambda - a];
  const second = [lambda - d, c];
  let vector = Math.hypot(...first) >= Math.hypot(...second) ? first : second;
  let magnitude = Math.hypot(...vector);
  if (magnitude <= tolerance) {
    // Any direction is an eigenvector of a scalar matrix; return a stable basis.
    vector = index === 0 ? [1, 0] : [0, 1];
    magnitude = 1;
  }
  vector = vector.map((value) => value / magnitude);
  if (vector[0] < -tolerance || (Math.abs(vector[0]) <= tolerance && vector[1] < 0)) {
    vector = vector.map((value) => -value);
  }
  return vector;
}

function complexEigenvector(a, b, c, d, lambda, tolerance) {
  // Either row of (A - λI)v=0 can yield a stable vector, depending on the matrix.
  const first = { real: [b, lambda.real - a], imag: [0, lambda.imag] };
  const second = { real: [lambda.real - d, c], imag: [lambda.imag, 0] };
  const magnitude = (vector) => Math.sqrt(
    vector.real.reduce((sum, value) => sum + value * value, 0) +
    vector.imag.reduce((sum, value) => sum + value * value, 0)
  );
  let { real, imag } = magnitude(first) >= magnitude(second) ? first : second;
  let norm = magnitude({ real, imag });
  if (norm <= tolerance) {
    real = [1, 0];
    imag = [0, 0];
    norm = 1;
  }
  return { real: real.map((value) => value / norm), imag: imag.map((value) => value / norm) };
}

export function matrixEquals(a, b, tolerance = 1e-9) {
  try { assertSameShape(a, b); }
  catch { return false; }
  return a.every((row, i) => row.every((value, j) => Math.abs(value - b[i][j]) <= tolerance));
}
