/**
 * Centralized user settings model with safe defaults and validation.
 */
export const DEFAULT_SETTINGS = Object.freeze({
  timeScale: 1,
  solver: "rk4",
  stepSize: .025,
  fieldMode: "direction",
  showGrid: true,
  showTrajectory: true,
  showWind: false,
  audioEnabled: true,
  audioVolume: .12,
  textScale: 1,
  colorTheme: "midnight"
});

export class SettingsController extends EventTarget {
  constructor(storage = globalThis.localStorage) {
    super();
    this.storage = storage;
    this.values = this.read();
  }

  read() {
    try {
      const saved = JSON.parse(this.storage?.getItem("vfp-settings") ?? "{}");
      return { ...DEFAULT_SETTINGS, ...saved };
    } catch {
      return { ...DEFAULT_SETTINGS };
    }
  }

  get(key) { return this.values[key]; }
  all() { return { ...this.values }; }

  set(key, value) {
    if (!Object.hasOwn(DEFAULT_SETTINGS, key)) throw new TypeError(`Unknown setting "${key}".`);
    const normalized = normalizeSetting(key, value);
    this.values[key] = normalized;
    this.write();
    this.dispatchEvent(new CustomEvent("change", { detail: { key, value: normalized, settings: this.all() } }));
    return normalized;
  }

  update(values) {
    const changed = [];
    for (const [key, value] of Object.entries(values)) {
      if (!Object.hasOwn(DEFAULT_SETTINGS, key)) continue;
      this.values[key] = normalizeSetting(key, value);
      changed.push(key);
    }
    this.write();
    this.dispatchEvent(new CustomEvent("change", { detail: { keys: changed, settings: this.all() } }));
    return this.all();
  }

  reset() {
    this.values = { ...DEFAULT_SETTINGS };
    this.write();
    this.dispatchEvent(new CustomEvent("reset", { detail: this.all() }));
  }

  write() {
    try { this.storage?.setItem("vfp-settings", JSON.stringify(this.values)); }
    catch (error) { this.dispatchEvent(new CustomEvent("error", { detail: error })); }
  }
}

function normalizeSetting(key, value) {
  if (["showGrid", "showTrajectory", "showWind", "audioEnabled"].includes(key)) return Boolean(value);
  if (key === "solver") return ["euler", "midpoint", "rk4", "adaptive"].includes(value) ? value : "rk4";
  if (key === "fieldMode") return ["direction", "magnitude", "wind"].includes(value) ? value : "direction";
  if (key === "colorTheme") return ["midnight", "high-contrast", "warm"].includes(value) ? value : "midnight";
  if (key === "timeScale") return clamp(Number(value), .25, 2.5);
  if (key === "stepSize") return clamp(Number(value), .001, .2);
  if (key === "audioVolume") return clamp(Number(value), 0, 1);
  if (key === "textScale") return clamp(Number(value), .8, 1.5);
  return value;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, Number.isFinite(value) ? value : min));
}
