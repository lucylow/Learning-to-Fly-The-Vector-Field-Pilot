/**
 * Pointer interaction manager for canvas pan, zoom and coordinate inspection.
 * This module is independent of the flight deck's default fixed viewport.
 */
export class CanvasInteractions extends EventTarget {
  constructor(canvas, bounds) {
    super();
    this.canvas = canvas;
    this.bounds = { ...bounds };
    this.dragging = false;
    this.lastPointer = null;
    this.zoomFactor = 1.15;
    this.minSpan = .5;
    this.maxSpan = 100;
    this.onPointerDown = this.onPointerDown.bind(this);
    this.onPointerMove = this.onPointerMove.bind(this);
    this.onPointerUp = this.onPointerUp.bind(this);
    this.onWheel = this.onWheel.bind(this);
    canvas.addEventListener("pointerdown", this.onPointerDown);
    canvas.addEventListener("pointermove", this.onPointerMove);
    canvas.addEventListener("pointerup", this.onPointerUp);
    canvas.addEventListener("pointercancel", this.onPointerUp);
    canvas.addEventListener("wheel", this.onWheel, { passive: false });
  }

  pointerToWorld(event) {
    const rect = this.canvas.getBoundingClientRect();
    const px = event.clientX - rect.left;
    const py = event.clientY - rect.top;
    return {
      x: this.bounds.xMin + px / rect.width * (this.bounds.xMax - this.bounds.xMin),
      y: this.bounds.yMax - py / rect.height * (this.bounds.yMax - this.bounds.yMin)
    };
  }

  onPointerDown(event) {
    if (event.button !== 0) return;
    this.dragging = true;
    this.lastPointer = { x: event.clientX, y: event.clientY };
    this.canvas.setPointerCapture(event.pointerId);
    this.dispatchEvent(new CustomEvent("inspect", { detail: this.pointerToWorld(event) }));
  }

  onPointerMove(event) {
    if (!this.dragging || !this.lastPointer) {
      this.dispatchEvent(new CustomEvent("hover", { detail: this.pointerToWorld(event) }));
      return;
    }
    const rect = this.canvas.getBoundingClientRect();
    const dx = (event.clientX - this.lastPointer.x) / rect.width * (this.bounds.xMax - this.bounds.xMin);
    const dy = (event.clientY - this.lastPointer.y) / rect.height * (this.bounds.yMax - this.bounds.yMin);
    this.pan(-dx, dy);
    this.lastPointer = { x: event.clientX, y: event.clientY };
    this.dispatchEvent(new CustomEvent("change", { detail: this.snapshot() }));
  }

  onPointerUp() {
    this.dragging = false;
    this.lastPointer = null;
  }

  onWheel(event) {
    event.preventDefault();
    const anchor = this.pointerToWorld(event);
    const factor = event.deltaY < 0 ? 1 / this.zoomFactor : this.zoomFactor;
    this.zoom(factor, anchor);
    this.dispatchEvent(new CustomEvent("change", { detail: this.snapshot() }));
  }

  pan(dx, dy) {
    this.bounds.xMin += dx; this.bounds.xMax += dx;
    this.bounds.yMin += dy; this.bounds.yMax += dy;
    return this.snapshot();
  }

  zoom(factor, anchor = { x: 0, y: 0 }) {
    const xSpan = clampSpan((this.bounds.xMax - this.bounds.xMin) * factor, this.minSpan, this.maxSpan);
    const ySpan = clampSpan((this.bounds.yMax - this.bounds.yMin) * factor, this.minSpan, this.maxSpan);
    const xRatio = (anchor.x - this.bounds.xMin) / (this.bounds.xMax - this.bounds.xMin);
    const yRatio = (anchor.y - this.bounds.yMin) / (this.bounds.yMax - this.bounds.yMin);
    this.bounds.xMin = anchor.x - xRatio * xSpan;
    this.bounds.xMax = this.bounds.xMin + xSpan;
    this.bounds.yMin = anchor.y - yRatio * ySpan;
    this.bounds.yMax = this.bounds.yMin + ySpan;
    return this.snapshot();
  }

  fit(bounds) {
    this.bounds = { ...bounds };
    this.dispatchEvent(new CustomEvent("change", { detail: this.snapshot() }));
  }

  snapshot() { return { ...this.bounds }; }

  destroy() {
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    this.canvas.removeEventListener("pointermove", this.onPointerMove);
    this.canvas.removeEventListener("pointerup", this.onPointerUp);
    this.canvas.removeEventListener("pointercancel", this.onPointerUp);
    this.canvas.removeEventListener("wheel", this.onWheel);
  }
}

function clampSpan(value, minimum, maximum) {
  return Math.max(minimum, Math.min(maximum, value));
}
