/**
 * Theme and visual density controller.
 */
const THEMES = {
  midnight: { background: "#07121d", panel: "#0d1d2a", accent: "#53d9e8", text: "#e9f2f7" },
  warm: { background: "#19130f", panel: "#282019", accent: "#f2b766", text: "#fff0dc" },
  violet: { background: "#110f20", panel: "#1c1930", accent: "#b39aff", text: "#f1edff" },
  contrast: { background: "#000000", panel: "#101010", accent: "#ffff00", text: "#ffffff" }
};

export class ThemeManager extends EventTarget {
  constructor(root = document.documentElement) {
    super();
    this.root = root;
    this.theme = "midnight";
    this.scale = 1;
    this.density = "comfortable";
    this.apply();
  }

  setTheme(name) {
    if (!Object.hasOwn(THEMES, name)) throw new TypeError(`Unknown theme "${name}".`);
    this.theme = name;
    this.apply();
    this.dispatchEvent(new CustomEvent("change", { detail: this.snapshot() }));
  }

  setScale(value) {
    this.scale = Math.max(.8, Math.min(1.5, Number(value) || 1));
    this.apply();
    this.dispatchEvent(new CustomEvent("change", { detail: this.snapshot() }));
  }

  setDensity(value) {
    this.density = ["comfortable", "compact", "spacious"].includes(value) ? value : "comfortable";
    this.apply();
    this.dispatchEvent(new CustomEvent("change", { detail: this.snapshot() }));
  }

  apply() {
    const palette = THEMES[this.theme];
    this.root.style.setProperty("--theme-background", palette.background);
    this.root.style.setProperty("--theme-panel", palette.panel);
    this.root.style.setProperty("--theme-accent", palette.accent);
    this.root.style.setProperty("--theme-text", palette.text);
    this.root.style.setProperty("--ui-scale", String(this.scale));
    this.root.dataset.theme = this.theme;
    this.root.dataset.density = this.density;
  }

  snapshot() {
    return { theme: this.theme, scale: this.scale, density: this.density };
  }

  availableThemes() {
    return Object.entries(THEMES).map(([id, colors]) => ({ id, ...colors }));
  }
}

export function applyThemeVariables(element, theme) {
  if (!element || !theme) return;
  element.style.setProperty("--theme-background", theme.background);
  element.style.setProperty("--theme-panel", theme.panel);
  element.style.setProperty("--theme-accent", theme.accent);
  element.style.setProperty("--theme-text", theme.text);
}

export function contrastRatio(first, second) {
  const a = luminance(first);
  const b = luminance(second);
  const lighter = Math.max(a, b);
  const darker = Math.min(a, b);
  return (lighter + .05) / (darker + .05);
}

function luminance(hex) {
  const value = hex.replace("#", "");
  const channels = [0, 2, 4].map((index) => parseInt(value.slice(index, index + 2), 16) / 255);
  const linear = channels.map((channel) => channel <= .04045 ? channel / 12.92 : ((channel + .055) / 1.055) ** 2.4);
  return .2126 * linear[0] + .7152 * linear[1] + .0722 * linear[2];
}
