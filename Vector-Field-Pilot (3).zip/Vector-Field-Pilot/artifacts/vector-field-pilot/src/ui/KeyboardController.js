/**
 * Keyboard shortcuts and focus-safe interaction helpers.
 */
export class KeyboardController extends EventTarget {
  constructor(target = document) {
    super();
    this.target = target;
    this.enabled = true;
    this.shortcuts = new Map();
    this.handleKeyDown = this.handleKeyDown.bind(this);
    target.addEventListener("keydown", this.handleKeyDown);
  }

  register(key, callback, options = {}) {
    const normalized = normalizeKey(key);
    this.shortcuts.set(normalized, { callback, allowInput: Boolean(options.allowInput), description: options.description ?? "" });
    return () => this.shortcuts.delete(normalized);
  }

  handleKeyDown(event) {
    if (!this.enabled || event.repeat && !event.ctrlKey) return;
    const inputFocused = isTextEntry(event.target);
    const shortcut = this.shortcuts.get(normalizeEvent(event));
    if (!shortcut || (inputFocused && !shortcut.allowInput)) return;
    event.preventDefault();
    shortcut.callback(event);
    this.dispatchEvent(new CustomEvent("shortcut", { detail: { key: normalizeEvent(event), description: shortcut.description } }));
  }

  setEnabled(enabled) { this.enabled = Boolean(enabled); }
  list() {
    return [...this.shortcuts.entries()].map(([key, value]) => ({ key, description: value.description }));
  }
  destroy() { this.target.removeEventListener("keydown", this.handleKeyDown); this.shortcuts.clear(); }
}

function normalizeKey(key) {
  return String(key).toLowerCase().replace(/\s+/g, "");
}
function normalizeEvent(event) {
  const parts = [];
  if (event.ctrlKey || event.metaKey) parts.push("mod");
  if (event.altKey) parts.push("alt");
  if (event.shiftKey) parts.push("shift");
  parts.push(event.key.toLowerCase());
  return parts.join("+");
}
function isTextEntry(element) {
  return element instanceof HTMLElement && (
    element.isContentEditable ||
    ["INPUT", "TEXTAREA", "SELECT"].includes(element.tagName)
  );
}

export function trapFocus(container, event) {
  if (event.key !== "Tab") return;
  const focusable = [...container.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),textarea:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])')]
    .filter((element) => element.offsetParent !== null);
  if (!focusable.length) return;
  const first = focusable[0], last = focusable.at(-1);
  if (event.shiftKey && document.activeElement === first) {
    event.preventDefault(); last.focus();
  } else if (!event.shiftKey && document.activeElement === last) {
    event.preventDefault(); first.focus();
  }
}

export function announce(message, region = document.querySelector("[aria-live]")) {
  if (!region) return;
  region.textContent = "";
  requestAnimationFrame(() => { region.textContent = String(message); });
}
