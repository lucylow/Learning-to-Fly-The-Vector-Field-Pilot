import { VectorField, worldToCanvas } from "../math/VectorField.js";

export class FlightCanvas {
  constructor(canvas, options = {}) {
    this.canvas = canvas;
    this.context = canvas.getContext("2d");
    this.bounds = options.bounds ?? { xMin: -2, xMax: 10, yMin: -5, yMax: 5 };
    this.fieldMode = "direction";
    this.system = (state) => ({ x: 1, y: 0 });
    this.history = [];
    this.state = { x: 0, y: 0 };
    this.target = { x: 8, y: 0 };
    this.wind = (state) => ({ x: .1 * Math.sin(state.y), y: .08 * Math.cos(state.x) });
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(canvas);
    this.resize();
  }

  resize() {
    const rect = this.canvas.getBoundingClientRect();
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.max(1, Math.floor(rect.width * ratio));
    this.canvas.height = Math.max(1, Math.floor(rect.height * ratio));
    this.context.setTransform(ratio, 0, 0, ratio, 0, 0);
    this.width = rect.width;
    this.height = rect.height;
    this.render();
  }

  setSystem(system) { this.system = system; this.render(); }
  setFieldMode(mode) { this.fieldMode = mode; this.render(); }
  setState(snapshot) {
    this.state = { ...snapshot.state };
    this.history = snapshot.history.map((point) => ({ ...point }));
    this.render();
  }
  setTarget(target) { this.target = { ...target }; this.render(); }

  toCanvas(point) { return worldToCanvas(point, this.bounds, this.width, this.height); }

  render() {
    if (!this.context || !this.width) return;
    const ctx = this.context;
    ctx.clearRect(0, 0, this.width, this.height);
    this.drawBackground(ctx);
    this.drawGrid(ctx);
    if (this.fieldMode === "wind") this.drawField(ctx, this.wind, true);
    else this.drawField(ctx, this.system, false);
    this.drawRunway(ctx);
    this.drawTrajectory(ctx);
    this.drawAircraft(ctx);
  }

  drawBackground(ctx) {
    const gradient = ctx.createLinearGradient(0, 0, this.width, this.height);
    gradient.addColorStop(0, "#0a1d2a");
    gradient.addColorStop(1, "#071520");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, this.width, this.height);
  }

  drawGrid(ctx) {
    const { xMin, xMax, yMin, yMax } = this.bounds;
    const xSpan = xMax - xMin, ySpan = yMax - yMin;
    ctx.lineWidth = 1;
    for (let x = Math.ceil(xMin); x <= xMax; x += 1) {
      const p = this.toCanvas({ x, y: 0 });
      ctx.strokeStyle = x === 0 ? "rgba(125,170,195,.28)" : "rgba(125,170,195,.09)";
      ctx.beginPath(); ctx.moveTo(p.x, 0); ctx.lineTo(p.x, this.height); ctx.stroke();
    }
    for (let y = Math.ceil(yMin); y <= yMax; y += 1) {
      const p = this.toCanvas({ x: 0, y });
      ctx.strokeStyle = y === 0 ? "rgba(125,170,195,.28)" : "rgba(125,170,195,.09)";
      ctx.beginPath(); ctx.moveTo(0, p.y); ctx.lineTo(this.width, p.y); ctx.stroke();
    }
    ctx.fillStyle = "rgba(140,170,190,.5)";
    ctx.font = "9px 'DM Mono', monospace";
    ctx.fillText("X", this.width - 15, this.height / 2 - 8);
    ctx.fillText("Y", this.width / 2 + 8, 13);
  }

  drawField(ctx, system, isWind) {
    const field = new VectorField(system, this.bounds);
    const vectors = field.sample(19, 13, this.state.t ?? 0);
    for (const vector of vectors) {
      const origin = this.toCanvas(vector);
      const scale = this.fieldMode === "magnitude" && !isWind
        ? Math.min(1.8, Math.max(.15, vector.magnitude * .24))
        : .55;
      const magnitude = Math.max(.0001, vector.magnitude);
      const dx = vector.dx / magnitude * 12 * scale;
      const dy = -vector.dy / magnitude * 12 * scale;
      const alpha = Math.min(.8, .18 + vector.magnitude * .1);
      ctx.strokeStyle = isWind ? `rgba(242,183,102,${alpha})` : `rgba(83,217,232,${alpha})`;
      ctx.fillStyle = ctx.strokeStyle;
      ctx.lineWidth = 1.15;
      ctx.beginPath(); ctx.moveTo(origin.x - dx * .45, origin.y - dy * .45); ctx.lineTo(origin.x + dx, origin.y + dy); ctx.stroke();
      const angle = Math.atan2(dy, dx);
      ctx.beginPath();
      ctx.moveTo(origin.x + dx, origin.y + dy);
      ctx.lineTo(origin.x + dx - 4 * Math.cos(angle - .5), origin.y + dy - 4 * Math.sin(angle - .5));
      ctx.lineTo(origin.x + dx - 4 * Math.cos(angle + .5), origin.y + dy - 4 * Math.sin(angle + .5));
      ctx.closePath(); ctx.fill();
    }
  }

  drawRunway(ctx) {
    const p = this.toCanvas(this.target);
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.fillStyle = "rgba(242,183,102,.10)";
    ctx.strokeStyle = "rgba(242,183,102,.65)";
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(0, 0, 19, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#f2b766";
    ctx.fillRect(-3, -12, 6, 24);
    ctx.fillStyle = "#f2b766";
    ctx.font = "8px 'DM Mono', monospace";
    ctx.fillText("RUNWAY", 13, -15);
    ctx.restore();
  }

  drawTrajectory(ctx) {
    if (this.history.length < 2) return;
    ctx.beginPath();
    this.history.forEach((point, index) => {
      const p = this.toCanvas(point);
      if (index === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
    });
    ctx.strokeStyle = "rgba(83,217,232,.9)";
    ctx.lineWidth = 2;
    ctx.shadowColor = "rgba(83,217,232,.3)";
    ctx.shadowBlur = 8;
    ctx.stroke();
    ctx.shadowBlur = 0;
  }

  drawAircraft(ctx) {
    const p = this.toCanvas(this.state);
    let angle = 0;
    if (this.history.length > 1) {
      const previous = this.history[this.history.length - 2];
      angle = Math.atan2(-(this.state.y - previous.y), this.state.x - previous.x);
    }
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(angle);
    ctx.fillStyle = "#eafcff";
    ctx.shadowColor = "#53d9e8";
    ctx.shadowBlur = 15;
    ctx.beginPath();
    ctx.moveTo(13, 0); ctx.lineTo(-9, -7); ctx.lineTo(-4, 0); ctx.lineTo(-9, 7);
    ctx.closePath(); ctx.fill();
    ctx.restore();
  }

  destroy() { this.resizeObserver.disconnect(); }
}
