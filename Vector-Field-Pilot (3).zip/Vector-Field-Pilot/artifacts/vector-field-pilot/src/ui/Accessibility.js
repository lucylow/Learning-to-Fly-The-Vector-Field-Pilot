/**
 * Accessibility preferences and helper utilities.
 */
const DEFAULT_ACCESSIBILITY = Object.freeze({
  highContrast: false,
  largeText: false,
  reducedMotion: false,
  simplifiedLabels: false,
  announceTelemetry: false
});

export class AccessibilitySettings extends EventTarget {
  constructor(storage = globalThis.localStorage) {
    super();
    this.storage = storage;
    this.settings = this.load();
    this.apply();
  }

  load() {
    try {
      return { ...DEFAULT_ACCESSIBILITY, ...JSON.parse(this.storage?.getItem("vfp-accessibility") ?? "{}") };
    } catch {
      return { ...DEFAULT_ACCESSIBILITY };
    }
  }

  update(key, value) {
    if (!Object.hasOwn(DEFAULT_ACCESSIBILITY, key)) throw new TypeError(`Unknown accessibility setting: ${key}`);
    this.settings[key] = Boolean(value);
    this.persist();
    this.apply();
    this.dispatchEvent(new CustomEvent("change", { detail: this.snapshot() }));
    return this.snapshot();
  }

  apply(root = document.documentElement) {
    root.classList.toggle("high-contrast", this.settings.highContrast);
    root.classList.toggle("large-text", this.settings.largeText);
    root.classList.toggle("reduce-motion", this.settings.reducedMotion);
    root.dataset.labelMode = this.settings.simplifiedLabels ? "simple" : "technical";
  }

  persist() {
    try { this.storage?.setItem("vfp-accessibility", JSON.stringify(this.settings)); }
    catch (error) { this.dispatchEvent(new CustomEvent("error", { detail: error })); }
  }

  snapshot() { return { ...this.settings }; }
  reset() { this.settings = { ...DEFAULT_ACCESSIBILITY }; this.persist(); this.apply(); }

  shouldAnnounceTelemetry() { return this.settings.announceTelemetry; }
}

export function formatForScreenReader(label, value, unit = "") {
  const normalized = String(value);
  return unit ? `${label}: ${normalized} ${unit}` : `${label}: ${normalized}`;
}

export function describeVector(vector) {
  const magnitude = Math.hypot(vector.x, vector.y);
  const direction = Math.atan2(vector.y, vector.x) * 180 / Math.PI;
  return `Rate vector points ${direction.toFixed(0)} degrees with magnitude ${magnitude.toFixed(2)}.`;
}

export function prefersReducedMotion() {
  return globalThis.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
}
