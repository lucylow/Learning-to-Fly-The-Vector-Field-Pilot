/**
 * Optional synthesized interface sounds. No audio assets are required.
 * Audio is only created after a user gesture to respect browser autoplay rules.
 */
export class AudioEngine {
  constructor() {
    this.context = null;
    this.enabled = true;
    this.masterVolume = .12;
    this.activeNodes = new Set();
  }

  async unlock() {
    const AudioContextClass = globalThis.AudioContext || globalThis.webkitAudioContext;
    if (!AudioContextClass) return false;
    this.context ??= new AudioContextClass();
    if (this.context.state === "suspended") await this.context.resume();
    return true;
  }

  setEnabled(enabled) { this.enabled = Boolean(enabled); }
  setVolume(value) { this.masterVolume = Math.max(0, Math.min(1, Number(value) || 0)); }

  tone({ frequency = 440, duration = .12, waveform = "sine", volume = 1, endFrequency = null } = {}) {
    if (!this.enabled || !this.context) return false;
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();
    const now = this.context.currentTime;
    oscillator.type = waveform;
    oscillator.frequency.setValueAtTime(frequency, now);
    if (endFrequency) oscillator.frequency.exponentialRampToValueAtTime(Math.max(1, endFrequency), now + duration);
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(this.masterVolume * volume, now + .01);
    gain.gain.exponentialRampToValueAtTime(.0001, now + duration);
    oscillator.connect(gain);
    gain.connect(this.context.destination);
    this.activeNodes.add(oscillator);
    oscillator.onended = () => {
      this.activeNodes.delete(oscillator);
      oscillator.disconnect();
      gain.disconnect();
    };
    oscillator.start(now);
    oscillator.stop(now + duration + .02);
    return true;
  }

  play(name) {
    const patterns = {
      click: [{ frequency: 620, duration: .035, volume: .35 }],
      apply: [{ frequency: 480, endFrequency: 760, duration: .11, volume: .45 }],
      takeoff: [{ frequency: 220, endFrequency: 660, duration: .3, waveform: "triangle", volume: .5 }],
      success: [
        { frequency: 523, duration: .12, volume: .5 },
        { frequency: 659, duration: .12, volume: .5 },
        { frequency: 784, duration: .2, volume: .5 }
      ],
      warning: [{ frequency: 260, endFrequency: 180, duration: .2, waveform: "square", volume: .25 }]
    };
    const pattern = patterns[name];
    if (!pattern || !this.enabled) return false;
    pattern.forEach((tone, index) => setTimeout(() => this.tone(tone), index * 110));
    return true;
  }

  stopAll() {
    for (const node of this.activeNodes) {
      try { node.stop(); } catch { /* Node may already have stopped. */ }
    }
    this.activeNodes.clear();
  }

  destroy() {
    this.stopAll();
    this.context?.close();
    this.context = null;
  }
}
