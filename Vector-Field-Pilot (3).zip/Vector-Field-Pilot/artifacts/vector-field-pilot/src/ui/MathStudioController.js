import { ExpressionParser } from "../math/ExpressionParser.js";
import { EquilibriumSolver } from "../math/EquilibriumSolver.js";
import { VectorField3D } from "../math/VectorField3D.js";

const $ = (selector) => document.querySelector(selector);
const COLORS = { primary: "#53d9e8", comparison: "#f2b766" };

export class MathStudioController {
  constructor() {
    this.primarySystem = null;
    this.comparisonSystem = null;
    this.primaryEquations = null;
    this.comparisonEquations = null;
    this.equilibria = [];
    this.zoom = 1;
    this.pan = { x: 0, y: 0, z: 0 };
    this.renderFrame = null;
    this.canvases = [
      { element: $("#math-canvas-primary"), role: "primary" },
      { element: $("#math-canvas-compare"), role: "comparison" }
    ];
    this.comparisonPanel = $(".comparison-canvas-panel");
    this.resizeObserver = new ResizeObserver(() => this.scheduleRender());
    this.canvases.forEach(({ element }) => this.resizeObserver.observe(element.parentElement));
    this.bindControls();
    this.bindCanvasNavigation();
    this.updateControlLabels();
    this.applyModels({ report: false });
  }

  bindControls() {
    $("#math-apply").addEventListener("click", () => this.applyModels());
    $("#math-analyze").addEventListener("click", () => this.analyze());
    $("#math-use-comparison").addEventListener("change", () => {
      this.comparisonPanel.hidden = !$("#math-use-comparison").checked;
      this.applyModels();
    });
    $("#math-reset-view").addEventListener("click", () => this.resetView());

    ["math-dimension", "math-field-mode", "math-resolution", "math-range",
      "math-time", "math-analysis-time", "math-seeds", "math-azimuth", "math-elevation"]
      .forEach((id) => $(`#${id}`).addEventListener("input", () => {
        this.updateControlLabels();
        this.scheduleRender();
      }));
    $("#math-dimension").addEventListener("change", () => this.scheduleRender());
    $("#math-field-mode").addEventListener("change", () => this.scheduleRender());
    $("#math-resolution").addEventListener("change", () => this.scheduleRender());
  }

  bindCanvasNavigation() {
    for (const { element } of this.canvases) {
      element.addEventListener("pointerdown", (event) => {
        if (event.button !== 0) return;
        element.setPointerCapture(event.pointerId);
        element.dataset.dragging = "true";
        element.dataset.dragX = String(event.clientX);
        element.dataset.dragY = String(event.clientY);
        element.dataset.dragMode = event.shiftKey ? "pan" : "rotate";
      });
      element.addEventListener("pointermove", (event) => {
        if (element.dataset.dragging !== "true") return;
        const previousX = Number(element.dataset.dragX);
        const previousY = Number(element.dataset.dragY);
        const dx = event.clientX - previousX;
        const dy = event.clientY - previousY;
        element.dataset.dragX = String(event.clientX);
        element.dataset.dragY = String(event.clientY);
        if ($("#math-dimension").value === "3" && element.dataset.dragMode !== "pan") {
          $("#math-azimuth").value = String(clamp(Number($("#math-azimuth").value) + dx * .7, -180, 180));
          $("#math-elevation").value = String(clamp(Number($("#math-elevation").value) - dy * .55, -80, 80));
        } else {
          const range = this.visibleRadius();
          const rect = element.getBoundingClientRect();
          const scale = Math.min(rect.width, rect.height) / (2 * range);
          this.pan.x -= dx / Math.max(1, scale);
          this.pan.y += dy / Math.max(1, scale);
        }
        this.updateControlLabels();
        this.scheduleRender();
      });
      const endDrag = () => { element.dataset.dragging = "false"; };
      element.addEventListener("pointerup", endDrag);
      element.addEventListener("pointercancel", endDrag);
      element.addEventListener("wheel", (event) => {
        event.preventDefault();
        this.zoom = clamp(this.zoom * Math.exp(-event.deltaY * .001), .45, 4);
        this.scheduleRender();
      }, { passive: false });
      element.addEventListener("keydown", (event) => {
        const offset = this.visibleRadius() * .08;
        if (event.key === "ArrowLeft") this.pan.x -= offset;
        else if (event.key === "ArrowRight") this.pan.x += offset;
        else if (event.key === "ArrowUp") this.pan.y += offset;
        else if (event.key === "ArrowDown") this.pan.y -= offset;
        else if (event.key === "+" || event.key === "=") this.zoom = clamp(this.zoom * 1.15, .45, 4);
        else if (event.key === "-") this.zoom = clamp(this.zoom / 1.15, .45, 4);
        else return;
        event.preventDefault();
        this.scheduleRender();
      });
    }
  }

  updateControlLabels() {
    const range = $("#math-range");
    const azimuth = $("#math-azimuth");
    const elevation = $("#math-elevation");
    $("#math-range-value").textContent = `${range.value} units`;
    $("#math-azimuth-value").textContent = `${azimuth.value}°`;
    $("#math-elevation-value").textContent = `${elevation.value}°`;
    const dimension = $("#math-dimension").value;
    document.querySelectorAll(".math-axis-badge").forEach((badge, index) => {
      badge.textContent = index === 0
        ? (dimension === "2" ? "X / Y" : "X / Y / Z")
        : (dimension === "2" ? "REFERENCE / X-Y" : "REFERENCE / X-Y-Z");
    });
    document.querySelectorAll(".math-axis-caption").forEach((caption) => {
      caption.lastElementChild.hidden = dimension === "2";
    });
    this.canvases.forEach(({ element }) => {
      element.setAttribute("aria-label", `${element.id.includes("compare") ? "Comparison" : "Primary"} ${dimension}D vector field visualization. Drag to navigate; use arrow keys to pan and plus or minus to zoom.`);
    });
  }

  compileSystem(prefix) {
    const equations = {
      x: $(`#${prefix}-x`).value.trim(),
      y: $(`#${prefix}-y`).value.trim(),
      z: $(`#${prefix}-z`).value.trim()
    };
    const compiled = Object.fromEntries(
      Object.entries(equations).map(([axis, source]) => [axis, ExpressionParser.compile(source)])
    );
    const system = (state) => ({
      x: compiled.x.evaluate(state),
      y: compiled.y.evaluate(state),
      z: compiled.z.evaluate(state)
    });
    const sample = system({ x: .37, y: -.21, z: .13, t: .4 });
    if (!Object.values(sample).every(Number.isFinite)) {
      throw new RangeError("This model is undefined at a test state.");
    }
    return { equations, system };
  }

  applyModels({ report = true } = {}) {
    try {
      const primary = this.compileSystem("math-model");
      const comparison = $("#math-use-comparison").checked
        ? this.compileSystem("math-compare")
        : null;
      this.primarySystem = primary.system;
      this.primaryEquations = primary.equations;
      this.comparisonSystem = comparison?.system ?? null;
      this.comparisonEquations = comparison?.equations ?? null;
      this.equilibria = [];
      this.clearAnalysis("Apply a model, then analyze its local x-y dynamics at z = 0.");
      this.scheduleRender();
      if (report) this.setFeedback("success", "Model validated. The vector field and comparison view are updated.");
      return true;
    } catch (error) {
      this.primarySystem = null;
      this.comparisonSystem = null;
      this.primaryEquations = null;
      this.comparisonEquations = null;
      this.equilibria = [];
      this.clearCanvases();
      this.clearAnalysis("No stability result is shown because the model did not validate.");
      this.setFeedback("error", `Model not applied: ${error.message}`);
      return false;
    }
  }

  analyze() {
    if (!this.primarySystem) {
      this.setFeedback("error", "Apply a valid primary model before running stability analysis.");
      return;
    }
    const time = Number($("#math-analysis-time").value);
    const radius = Number($("#math-range").value);
    if (![time, radius].every(Number.isFinite)) {
      this.setFeedback("error", "Snapshot time and domain must be finite numbers.");
      return;
    }
    try {
      const xySystem = (state) => {
        const rates = this.primarySystem({ ...state, z: 0, t: time });
        return { x: rates.x, y: rates.y };
      };
      const solver = new EquilibriumSolver(xySystem);
      const scanOptions = {
        columns: 13,
        rows: 13,
        tolerance: 1e-7,
        maxIterations: 55,
        maxStep: radius,
        mergeDistance: Math.max(.08, radius * .025),
        boundTolerance: Math.max(.02, radius * .01),
        time,
        z: 0
      };
      this.equilibria = solver.scan({
        xMin: this.pan.x - radius,
        xMax: this.pan.x + radius,
        yMin: this.pan.y - radius,
        yMax: this.pan.y + radius
      }, scanOptions).map(({ point }) => solver.analyze(point, scanOptions));
      this.renderAnalysis(time, radius);
      this.scheduleRender();
      const noun = this.equilibria.length === 1 ? "equilibrium" : "equilibria";
      this.setFeedback("success", `Analysis finished: ${this.equilibria.length} ${noun} found in the current x-y bounds.`);
    } catch (error) {
      this.equilibria = [];
      this.clearAnalysis("Analysis failed. No stability classification is shown.");
      this.setFeedback("error", `Stability analysis failed: ${error.message}`);
    }
  }

  renderAnalysis(time, radius) {
    const roots = $("#math-equilibrium-results");
    roots.replaceChildren(outputHeader("EQUILIBRIUM POINTS", this.equilibria.length ? `${this.equilibria.length} FOUND` : "NONE FOUND"));
    if (!this.equilibria.length) {
      roots.append(outputParagraph("No root met the numerical tolerance in this search area. Expand the domain or inspect whether the equations are smooth near a likely fixed point."));
      this.renderJacobian(null);
      this.renderExplanation(
        "No converged fixed point",
        "The grid search uses damped Newton iterations from multiple starting points. A missed equilibrium is possible, especially near singularities, flat regions, or roots outside the current domain."
      );
      return;
    }
    for (const [index, item] of this.equilibria.entries()) {
      const line = document.createElement("p");
      line.className = "math-result-line";
      line.textContent = `${index + 1}. (${format(item.point.x)}, ${format(item.point.y)}) · ${item.classification?.type ?? "inconclusive"} · residual ${format(item.residual, 6)}`;
      roots.append(line);
    }
    const item = this.equilibria[0];
    this.renderJacobian(item);
    this.renderExplanation(
      `${item.classification?.type ?? "Inconclusive"} at the first fixed point`,
      `${describe(item.classification?.type)} Local linearization uses a finite-difference Jacobian at (${format(item.point.x)}, ${format(item.point.y)}). ${linearizationText(item)} Search radius ±${format(radius, 1)}; snapshot t=${format(time, 2)}.`
    );
  }

  renderJacobian(item) {
    const panel = $("#math-jacobian");
    panel.replaceChildren(outputHeader("2D JACOBIAN AND EIGENPAIRS", item ? "LOCAL LINEAR MODEL" : "AWAITING ROOT"));
    if (!item?.jacobian || !item?.eigen) {
      panel.append(outputParagraph("A converged equilibrium is required before the Jacobian and eigenpairs can be displayed."));
      return;
    }
    const matrix = document.createElement("pre");
    matrix.className = "math-matrix";
    matrix.textContent = `J = [ ${format(item.jacobian.a, 4)}  ${format(item.jacobian.b, 4)} ]\n    [ ${format(item.jacobian.c, 4)}  ${format(item.jacobian.d, 4)} ]`;
    panel.append(matrix);
    for (const [index, value] of item.eigen.values.entries()) {
      const vector = item.eigen.eigenvectors[index];
      const paragraph = document.createElement("p");
      paragraph.className = "math-result-line";
      paragraph.textContent = `λ${index + 1} = ${formatComplex(value)}   v${index + 1} = [${formatComplex({ real: vector.real[0], imag: vector.imag[0] })}, ${formatComplex({ real: vector.real[1], imag: vector.imag[1] })}]`;
      panel.append(paragraph);
    }
    const stability = document.createElement("p");
    stability.className = "math-stability-label";
    stability.textContent = `Classification: ${item.classification.stability}`;
    panel.append(stability);
  }

  renderExplanation(title, text) {
    const panel = $("#math-explanation");
    panel.replaceChildren();
    const mark = document.createElement("span");
    mark.className = "explanation-mark";
    mark.setAttribute("aria-hidden", "true");
    mark.textContent = "∴";
    const content = document.createElement("div");
    const heading = document.createElement("strong");
    heading.textContent = title;
    const paragraph = document.createElement("p");
    paragraph.textContent = `${text} This is local 2D analysis of the x-y subsystem with z fixed at 0. Eigenvalues and eigenvectors are numerical; classification describes the linearized model near the point, not the full nonlinear or 3D system. If equations depend on t, the calculation is only a snapshot and is not an equilibrium test for the time-varying system.`;
    content.append(heading, paragraph);
    panel.append(mark, content);
  }

  clearAnalysis(message) {
    const roots = $("#math-equilibrium-results");
    roots.replaceChildren(outputHeader("EQUILIBRIUM POINTS", "AWAITING ANALYSIS"), outputParagraph(message));
    this.renderJacobian(null);
    this.renderExplanation("Reading the result", "Analyze the active model to estimate fixed points and their local behavior.");
  }

  getRenderOptions() {
    const range = Number($("#math-range").value);
    const resolution = Number($("#math-resolution").value);
    const duration = Number($("#math-time").value);
    const seedCount = Number($("#math-seeds").value);
    const time = Number($("#math-analysis-time").value);
    const dimension = $("#math-dimension").value;
    const mode = $("#math-field-mode").value;
    if (!(range >= 2 && range <= 12) || ![10, 16, 24].includes(resolution) ||
        !(duration >= 1 && duration <= 60) || !Number.isInteger(seedCount) || seedCount < 1 || seedCount > 24 ||
        !Number.isFinite(time) || !["2", "3"].includes(dimension) ||
        !["direction", "magnitude", "trajectories"].includes(mode)) {
      throw new RangeError("Check the view settings, duration, and trajectory count.");
    }
    return {
      range,
      resolution,
      duration,
      seedCount,
      time,
      dimension: Number(dimension),
      mode,
      azimuth: Number($("#math-azimuth").value) * Math.PI / 180,
      elevation: Number($("#math-elevation").value) * Math.PI / 180
    };
  }

  render() {
    if (!this.primarySystem) return;
    let options;
    try {
      options = this.getRenderOptions();
    } catch (error) {
      this.clearCanvases();
      this.setFeedback("error", `Visualization not updated: ${error.message}`);
      return;
    }
    let primaryReport;
    let comparisonReport = null;
    for (const { element, role } of this.canvases) {
      const system = role === "primary" ? this.primarySystem : this.comparisonSystem;
      const color = COLORS[role];
      const panel = element.closest(".math-canvas-panel");
      panel.hidden = role === "comparison" && !this.comparisonSystem;
      if (!system || panel.hidden) {
        this.clearCanvas(element);
        continue;
      }
      const report = this.drawField(element, system, color, options);
      if (role === "primary") primaryReport = report;
      else comparisonReport = report;
    }
    if (primaryReport?.empty) {
      this.setFeedback("error", "No finite samples could be drawn. The model may be undefined across the visible domain; change its equations or adjust the view.");
      return;
    }
    const warnings = [];
    if (primaryReport?.invalidSamples) warnings.push(`${primaryReport.invalidSamples} undefined field samples were omitted`);
    if (primaryReport?.partialTrajectories) warnings.push(`${primaryReport.partialTrajectories} trajectories stopped early`);
    if (comparisonReport?.invalidSamples) warnings.push(`${comparisonReport.invalidSamples} comparison samples were omitted`);
    if (comparisonReport?.partialTrajectories) warnings.push(`${comparisonReport.partialTrajectories} comparison trajectories stopped early`);
    if (comparisonReport?.empty) warnings.push("the comparison model has no finite samples in this view");
    if (warnings.length) {
      this.setFeedback("warning", `${warnings.join("; ")}. The plot shows only finite samples and marks partial paths.`);
    } else {
      const fieldDescription = options.mode === "trajectories"
        ? `${options.seedCount} initial-condition trajectories`
        : `${options.dimension}D vector field samples`;
      this.setFeedback("success", `${fieldDescription} rendered. Drag to navigate${options.dimension === 3 ? ", or hold Shift and drag to pan" : " to pan"}; scroll to zoom.`);
    }
  }

  drawField(canvas, system, color, options) {
    const rect = canvas.getBoundingClientRect();
    if (rect.width < 2 || rect.height < 2) return { empty: true, invalidSamples: 0, partialTrajectories: 0 };
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.max(1, Math.floor(rect.width * ratio));
    canvas.height = Math.max(1, Math.floor(rect.height * ratio));
    const context = canvas.getContext("2d");
    context.setTransform(ratio, 0, 0, ratio, 0, 0);
    const width = rect.width, height = rect.height;
    context.clearRect(0, 0, width, height);
    context.fillStyle = "#091a27";
    context.fillRect(0, 0, width, height);
    const radius = this.visibleRadius(options.range);
    const projector = makeProjector({
      width, height, radius, pan: this.pan, dimension: options.dimension,
      azimuth: options.azimuth, elevation: options.elevation
    });
    this.drawGrid(context, projector, radius, options.dimension);

    const plottedSystem = options.dimension === 2
      ? (state) => {
        const rates = system({ ...state, z: 0 });
        return { x: rates.x, y: rates.y, z: 0 };
      }
      : system;
    const field = new VectorField3D(plottedSystem, {
      xMin: this.pan.x - radius, xMax: this.pan.x + radius,
      yMin: this.pan.y - radius, yMax: this.pan.y + radius,
      zMin: this.pan.z - radius, zMax: this.pan.z + radius
    });
    const sampled = options.dimension === 2
      ? field.samplePlane(options.resolution, options.resolution, { z: 0, time: options.time })
      : field.sampleVolume(options.resolution, Math.max(3, Math.round(options.resolution / 4)), { time: options.time });
    let partialTrajectories = 0;
    let invalidSamples = sampled.invalidCount;
    if (options.mode !== "trajectories") {
      const maxMagnitude = Math.max(1e-9, ...sampled.vectors.map((vector) => vector.magnitude));
      const step = 2 * radius / Math.max(2, options.resolution - 1);
      for (const vector of sampled.vectors) {
        if (vector.magnitude < 1e-10) continue;
        const origin = projector({ x: vector.x, y: vector.y, z: vector.z });
        const size = options.mode === "magnitude"
          ? step * (.07 + .35 * Math.sqrt(vector.magnitude / maxMagnitude))
          : step * .36;
        const speed = vector.magnitude || 1;
        const endpoint = projector({
          x: vector.x + vector.dx / speed * size,
          y: vector.y + vector.dy / speed * size,
          z: options.dimension === 3 ? vector.z + vector.dz / speed * size : vector.z
        });
        drawArrow(context, origin, endpoint, color, options.mode === "magnitude" ? .66 : .55);
      }
    }

    if (options.mode === "trajectories") {
      const seeds = makeSeeds(options.seedCount, this.pan, radius, options.dimension, options.time);
      const traces = field.trace(seeds, {
        duration: options.duration,
        stepSize: .04,
        maxSteps: 1800,
        escapeRadius: Math.max(24, radius * 5)
      });
      for (const trace of traces) {
        if (!trace.completed) partialTrajectories += 1;
        drawTrajectory(context, trace.points, projector, color, options.dimension);
      }
    }
    if (options.dimension === 2 && options.mode !== "trajectories") {
      for (const point of this.equilibria) {
        drawEquilibrium(context, projector({ x: point.point.x, y: point.point.y, z: 0 }), color);
      }
    }
    const readout = canvas.closest(".math-canvas-panel").querySelector(".canvas-readout");
    if (readout) readout.textContent = `${options.dimension}D · ${options.mode.toUpperCase()}`;
    const empty = options.mode !== "trajectories" && sampled.vectors.length === 0;
    canvas.parentElement.querySelector(".math-canvas-empty")?.classList.toggle("hidden", !empty);
    return {
      empty,
      invalidSamples,
      partialTrajectories
    };
  }

  drawGrid(context, project, radius, dimension) {
    context.save();
    context.lineWidth = 1;
    context.strokeStyle = "rgba(130,180,205,.12)";
    if (dimension === 2) {
      const divisions = Math.min(24, Math.ceil(radius * 2));
      for (let index = 0; index <= divisions; index += 1) {
        const value = -radius + 2 * radius * index / divisions + this.pan.x;
        const verticalA = project({ x: value, y: this.pan.y - radius, z: 0 });
        const verticalB = project({ x: value, y: this.pan.y + radius, z: 0 });
        context.beginPath(); context.moveTo(verticalA.x, verticalA.y); context.lineTo(verticalB.x, verticalB.y); context.stroke();
        const y = this.pan.y - radius + 2 * radius * index / divisions;
        const horizontalA = project({ x: this.pan.x - radius, y, z: 0 });
        const horizontalB = project({ x: this.pan.x + radius, y, z: 0 });
        context.beginPath(); context.moveTo(horizontalA.x, horizontalA.y); context.lineTo(horizontalB.x, horizontalB.y); context.stroke();
      }
      const origin = project({ x: 0, y: 0, z: 0 });
      context.strokeStyle = "rgba(157,190,210,.38)";
      context.beginPath(); context.moveTo(0, origin.y); context.lineTo(project({ x: this.pan.x + radius, y: 0, z: 0 }).x, origin.y); context.stroke();
      context.beginPath(); context.moveTo(origin.x, 0); context.lineTo(origin.x, project({ x: 0, y: this.pan.y - radius, z: 0 }).y); context.stroke();
    } else {
      const corners = [];
      for (const x of [-radius, radius]) for (const y of [-radius, radius]) for (const z of [-radius, radius]) {
        corners.push({ x: this.pan.x + x, y: this.pan.y + y, z: this.pan.z + z });
      }
      const edgePairs = [[0, 1], [0, 2], [0, 4], [1, 3], [1, 5], [2, 3], [2, 6], [3, 7], [4, 5], [4, 6], [5, 7], [6, 7]];
      for (const [a, b] of edgePairs) {
        const first = project(corners[a]), second = project(corners[b]);
        context.beginPath(); context.moveTo(first.x, first.y); context.lineTo(second.x, second.y); context.stroke();
      }
      const origin = project({ x: 0, y: 0, z: 0 });
      context.fillStyle = "rgba(242,183,102,.72)";
      context.beginPath(); context.arc(origin.x, origin.y, 2, 0, Math.PI * 2); context.fill();
    }
    context.restore();
  }

  scheduleRender() {
    if (this.renderFrame !== null) return;
    this.renderFrame = requestAnimationFrame(() => {
      this.renderFrame = null;
      this.render();
    });
  }

  visibleRadius(range = Number($("#math-range").value)) {
    return range / this.zoom;
  }

  resetView() {
    this.zoom = 1;
    this.pan = { x: 0, y: 0, z: 0 };
    $("#math-azimuth").value = "35";
    $("#math-elevation").value = "24";
    this.updateControlLabels();
    this.scheduleRender();
  }

  clearCanvas(canvas) {
    if (!canvas) return;
    const context = canvas.getContext("2d");
    if (context) context.clearRect(0, 0, canvas.width, canvas.height);
    canvas.parentElement.querySelector(".math-canvas-empty")?.classList.remove("hidden");
  }

  clearCanvases() {
    this.canvases.forEach(({ element }) => this.clearCanvas(element));
  }

  setFeedback(state, message) {
    const panel = $("#math-feedback");
    panel.classList.remove("success", "warning", "error");
    panel.classList.add(state);
    panel.querySelector(".feedback-indicator").dataset.state = state;
    panel.querySelector("p").textContent = message;
  }

  destroy() {
    if (this.renderFrame !== null) cancelAnimationFrame(this.renderFrame);
    this.resizeObserver.disconnect();
  }
}

function makeProjector({ width, height, radius, pan, dimension, azimuth, elevation }) {
  const scale = Math.min(width, height) / (2 * radius);
  const cosAz = Math.cos(azimuth), sinAz = Math.sin(azimuth);
  const cosEl = Math.cos(elevation), sinEl = Math.sin(elevation);
  return (point) => {
    const x = point.x - pan.x, y = point.y - pan.y, z = point.z - pan.z;
    if (dimension === 2) return { x: width / 2 + x * scale, y: height / 2 - y * scale };
    const rotatedX = x * cosAz - y * sinAz;
    const rotatedY = x * sinAz + y * cosAz;
    const projectedY = rotatedY * cosEl - z * sinEl;
    const depth = rotatedY * sinEl + z * cosEl;
    const perspective = (radius * 4) / Math.max(radius, radius * 4 + depth);
    return {
      x: width / 2 + rotatedX * scale * perspective,
      y: height / 2 - projectedY * scale * perspective
    };
  };
}

function makeSeeds(count, center, radius, dimension, time) {
  const seeds = [];
  const goldenAngle = Math.PI * (3 - Math.sqrt(5));
  for (let index = 0; index < count; index += 1) {
    const fraction = Math.sqrt((index + .5) / count);
    const angle = index * goldenAngle;
    seeds.push({
      x: center.x + Math.cos(angle) * radius * .72 * fraction,
      y: center.y + Math.sin(angle) * radius * .72 * fraction,
      z: dimension === 3 ? center.z + Math.sin(index * 1.7) * radius * .52 * fraction : 0,
      t: time
    });
  }
  return seeds;
}

function drawArrow(context, start, end, color, alpha) {
  const dx = end.x - start.x, dy = end.y - start.y;
  const length = Math.hypot(dx, dy);
  if (length < 1.2) return;
  const angle = Math.atan2(dy, dx);
  context.save();
  context.strokeStyle = color;
  context.fillStyle = color;
  context.globalAlpha = alpha;
  context.lineWidth = 1.15;
  context.beginPath();
  context.moveTo(start.x, start.y);
  context.lineTo(end.x, end.y);
  context.stroke();
  context.beginPath();
  context.moveTo(end.x, end.y);
  context.lineTo(end.x - 4 * Math.cos(angle - .48), end.y - 4 * Math.sin(angle - .48));
  context.lineTo(end.x - 4 * Math.cos(angle + .48), end.y - 4 * Math.sin(angle + .48));
  context.closePath();
  context.fill();
  context.restore();
}

function drawTrajectory(context, points, project, color, dimension) {
  if (!points.length) return;
  context.save();
  context.strokeStyle = color;
  context.globalAlpha = .88;
  context.lineWidth = 1.7;
  context.beginPath();
  points.forEach((point, index) => {
    const screen = project({ ...point, z: dimension === 2 ? 0 : point.z });
    if (index === 0) context.moveTo(screen.x, screen.y);
    else context.lineTo(screen.x, screen.y);
  });
  context.stroke();
  const start = project({ ...points[0], z: dimension === 2 ? 0 : points[0].z });
  context.fillStyle = color;
  context.globalAlpha = 1;
  context.beginPath();
  context.arc(start.x, start.y, 2.7, 0, Math.PI * 2);
  context.fill();
  context.restore();
}

function drawEquilibrium(context, point, color) {
  context.save();
  context.strokeStyle = "#f2b766";
  context.fillStyle = "#091a27";
  context.lineWidth = 1.5;
  context.beginPath();
  context.arc(point.x, point.y, 5, 0, Math.PI * 2);
  context.fill();
  context.stroke();
  context.beginPath();
  context.moveTo(point.x - 8, point.y); context.lineTo(point.x + 8, point.y);
  context.moveTo(point.x, point.y - 8); context.lineTo(point.x, point.y + 8);
  context.strokeStyle = color;
  context.stroke();
  context.restore();
}

function outputHeader(label, state) {
  const header = document.createElement("div");
  header.className = "stability-output-head";
  const title = document.createElement("span");
  title.textContent = label;
  const status = document.createElement("span");
  status.className = "output-state";
  status.textContent = state;
  header.append(title, status);
  return header;
}

function outputParagraph(text) {
  const paragraph = document.createElement("p");
  paragraph.textContent = text;
  return paragraph;
}

function format(value, digits = 3) {
  return Number.isFinite(value) ? Number(value).toFixed(digits) : "—";
}

function formatComplex(value) {
  const real = format(value.real, 4);
  const imag = format(Math.abs(value.imag), 4);
  if (Math.abs(value.imag) < 1e-8) return real;
  return `${real} ${value.imag < 0 ? "−" : "+"} ${imag}i`;
}

function describe(type) {
  const descriptions = {
    "Stable node": "Nearby trajectories approach without rotating in the linearized picture.",
    "Unstable node": "Nearby trajectories move away from the point in the linearized picture.",
    "Saddle": "One local direction attracts while another repels.",
    "Stable spiral": "Nearby trajectories rotate while approaching in the linearized picture.",
    "Unstable spiral": "Nearby trajectories rotate while moving away in the linearized picture.",
    "Center (linear)": "The linear model has closed orbits; nonlinear effects can change this behavior."
  };
  return descriptions[type] ?? "The local linear classification is degenerate or inconclusive.";
}

function linearizationText(item) {
  if (!item.linearization) return "";
  return `With u = x − x* and v = y − y*, ${item.linearization.x}; ${item.linearization.y}.`;
}

function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, value));
}
