/**
 * Curated scenario cards for the sandbox. Scenarios focus on one variable at a time.
 */
export const SCENARIOS = Object.freeze([
  {
    id: "coefficient-sign",
    title: "The sign experiment",
    prompt: "Change the sign of a linear coefficient and observe the direction of motion.",
    starting: { x: "x", y: "0" },
    variants: [{ label: "Positive", x: "x", y: "0" }, { label: "Negative", x: "-x", y: "0" }],
    learning: "The sign of a coefficient changes whether the state grows or decays near the origin."
  },
  {
    id: "damping-sweep",
    title: "Damping sweep",
    prompt: "Change only the damping coefficient in a second-order model.",
    starting: { x: "y", y: "-4*x-0.2*y" },
    variants: [{ label: "Light", x: "y", y: "-4*x-0.1*y" }, { label: "Medium", x: "y", y: "-4*x-0.7*y" }, { label: "Strong", x: "y", y: "-4*x-2*y" }],
    learning: "Damping changes how quickly oscillations decrease and can change the response regime."
  },
  {
    id: "coupling-sweep",
    title: "Coupling sweep",
    prompt: "Modify the strength of the cross-variable term.",
    starting: { x: "0.5*y", y: "-x" },
    variants: [{ label: "Weak", x: "0.2*y", y: "-x" }, { label: "Balanced", x: "y", y: "-x" }, { label: "Strong", x: "2*y", y: "-x" }],
    learning: "Coupling changes how one state variable influences the rate of another."
  },
  {
    id: "periodic-amplitude",
    title: "Periodic amplitude",
    prompt: "Change the amplitude of a sinusoidal disturbance.",
    starting: { x: "1", y: "0.2*sin(t)" },
    variants: [{ label: "Small", x: "1", y: "0.1*sin(t)" }, { label: "Medium", x: "1", y: "0.4*sin(t)" }, { label: "Large", x: "1", y: "0.8*sin(t)" }],
    learning: "The amplitude controls the maximum magnitude of the periodic input."
  },
  {
    id: "nonlinear-equilibria",
    title: "Nonlinear equilibria",
    prompt: "Inspect where a nonlinear scalar rate changes sign.",
    starting: { x: "x*(1-x)", y: "0" },
    variants: [{ label: "Logistic", x: "x*(1-x)", y: "0" }, { label: "Scaled", x: "2*x*(1-x)", y: "0" }, { label: "Reversed", x: "-x*(1-x)", y: "0" }],
    learning: "The roots of the rate equation identify equilibrium states; the sign between roots indicates local direction."
  }
]);

export function scenarioById(id) {
  return SCENARIOS.find((scenario) => scenario.id === id) ?? null;
}

export function scenarioChecklist(scenario) {
  return (scenario?.variants ?? []).map((variant, index) => ({
    id: `${scenario.id}-${index}`,
    label: variant.label,
    equations: { x: variant.x, y: variant.y },
    complete: false
  }));
}

export function compareScenarioVariants(scenario, runner) {
  if (!scenario || typeof runner !== "function") throw new TypeError("A scenario and runner function are required.");
  return scenario.variants.map((variant) => ({
    label: variant.label,
    equations: { x: variant.x, y: variant.y },
    result: runner({ x: variant.x, y: variant.y })
  }));
}
