/**
 * Achievement rules are declarative and evaluated against a player profile.
 */
export const ACHIEVEMENTS = Object.freeze([
  { id: "first-flight", name: "First Flight", description: "Complete your first mission.", icon: "✈", test: (p) => p.completed >= 1 },
  { id: "five-landings", name: "Flight Regular", description: "Complete five missions.", icon: "◎", test: (p) => p.completed >= 5 },
  { id: "full-campaign", name: "Senior Research Pilot", description: "Complete all fifteen missions.", icon: "★", test: (p) => p.completed >= 15 },
  { id: "perfect-score", name: "Precision Approach", description: "Earn a score of 100.", icon: "⊙", test: (p) => p.bestScore >= 100 },
  { id: "ten-experiments", name: "Curious Mind", description: "Record ten flight experiments.", icon: "⌁", test: (p) => p.experiments >= 10 },
  { id: "note-taker", name: "Research Notes", description: "Save three research observations.", icon: "▤", test: (p) => p.notes >= 3 },
  { id: "equation-explorer", name: "Equation Explorer", description: "Try at least five distinct equation pairs.", icon: "ƒ", test: (p) => p.uniqueModels >= 5 }
]);

export class AchievementSystem extends EventTarget {
  constructor(storage = globalThis.localStorage) {
    super();
    this.storage = storage;
    this.unlocked = this.load();
  }

  load() {
    try { return JSON.parse(this.storage?.getItem("vfp-achievements") ?? "[]"); }
    catch { return []; }
  }

  save() {
    try { this.storage?.setItem("vfp-achievements", JSON.stringify(this.unlocked)); }
    catch (error) { this.dispatchEvent(new CustomEvent("error", { detail: error })); }
  }

  evaluate(profile) {
    const newlyUnlocked = [];
    for (const achievement of ACHIEVEMENTS) {
      if (!this.unlocked.includes(achievement.id) && achievement.test(profile)) {
        this.unlocked.push(achievement.id);
        newlyUnlocked.push({ id: achievement.id, name: achievement.name, description: achievement.description, icon: achievement.icon });
      }
    }
    if (newlyUnlocked.length) {
      this.save();
      this.dispatchEvent(new CustomEvent("unlocked", { detail: newlyUnlocked }));
    }
    return newlyUnlocked;
  }

  list() {
    return ACHIEVEMENTS.map((item) => ({
      id: item.id,
      name: item.name,
      description: item.description,
      icon: item.icon,
      unlocked: this.unlocked.includes(item.id)
    }));
  }

  reset() {
    this.unlocked = [];
    this.save();
    this.dispatchEvent(new Event("reset"));
  }
}

export function buildAchievementProfile(progress) {
  const experiments = progress.experiments ?? [];
  const models = new Set(experiments.map((item) => `${item.equations?.x}|${item.equations?.y}`));
  return {
    completed: progress.completedMissions?.length ?? 0,
    bestScore: Math.max(0, ...(progress.completedMissions ?? []).map((item) => item.bestScore ?? 0)),
    experiments: experiments.length,
    notes: progress.notes?.length ?? 0,
    uniqueModels: models.size
  };
}
