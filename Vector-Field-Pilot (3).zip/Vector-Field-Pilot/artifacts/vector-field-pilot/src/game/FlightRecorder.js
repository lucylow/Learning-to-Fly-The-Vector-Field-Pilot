/**
 * Flight recorder captures a deterministic audit trail for a simulation session.
 */
export class FlightRecorder {
  constructor({ maxEvents = 5000 } = {}) {
    this.maxEvents = maxEvents;
    this.session = null;
    this.events = [];
    this.sequence = 0;
  }

  start(metadata = {}) {
    this.session = {
      id: createSessionId(),
      startedAt: new Date().toISOString(),
      metadata: clone(metadata)
    };
    this.events = [];
    this.sequence = 0;
    this.append("session-start", this.session.metadata);
    return clone(this.session);
  }

  append(type, payload = {}) {
    if (!this.session) throw new Error("Start a recording session first.");
    if (this.events.length >= this.maxEvents) return false;
    const event = {
      sequence: ++this.sequence,
      type: String(type),
      recordedAt: new Date().toISOString(),
      payload: clone(payload)
    };
    this.events.push(event);
    return clone(event);
  }

  recordState(snapshot) {
    return this.append("state", {
      time: snapshot.elapsed,
      state: snapshot.state,
      rates: snapshot.rates,
      distance: snapshot.distance
    });
  }

  recordEquationChange(equations) {
    return this.append("equation-change", equations);
  }

  recordControl(action, value = null) {
    return this.append("control", { action, value });
  }

  finish(summary = {}) {
    if (!this.session) return null;
    this.append("session-end", summary);
    const result = this.export();
    this.session = null;
    return result;
  }

  export() {
    return {
      format: "vfp-flight-recorder",
      version: 1,
      session: clone(this.session),
      events: clone(this.events)
    };
  }

  import(data) {
    if (data?.format !== "vfp-flight-recorder" || data.version !== 1 || !Array.isArray(data.events)) {
      throw new TypeError("Unsupported flight recording.");
    }
    this.session = clone(data.session);
    this.events = clone(data.events);
    this.sequence = this.events.reduce((max, item) => Math.max(max, item.sequence), 0);
    return this;
  }

  eventsOfType(type) {
    return this.events.filter((event) => event.type === type).map(clone);
  }

  timeline() {
    return this.events.map((event) => ({
      sequence: event.sequence,
      type: event.type,
      time: event.payload.time ?? null,
      recordedAt: event.recordedAt
    }));
  }

  clear() {
    this.session = null;
    this.events = [];
    this.sequence = 0;
  }
}

function clone(value) {
  return value == null ? value : JSON.parse(JSON.stringify(value));
}
function createSessionId() {
  return `flight-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}
