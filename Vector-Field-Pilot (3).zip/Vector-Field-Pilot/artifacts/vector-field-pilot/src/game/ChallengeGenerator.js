/**
 * Deterministic challenge generation for optional free-flight practice.
 * Generated challenges are bounded and include an explanation prompt.
 */
export class ChallengeGenerator {
  constructor(seed = 2026) {
    this.seed = seed >>> 0;
  }

  random() {
    this.seed = (1664525 * this.seed + 1013904223) >>> 0;
    return this.seed / 4294967296;
  }

  integer(minimum, maximum) {
    return Math.floor(this.random() * (maximum - minimum + 1)) + minimum;
  }

  choose(items) { return items[this.integer(0, items.length - 1)]; }

  generate(level = 1) {
    const difficulty = Math.max(1, Math.min(5, Number(level) || 1));
    const templates = [
      () => this.constantChallenge(),
      () => this.stabilityChallenge(),
      () => this.couplingChallenge(),
      () => this.dampingChallenge(),
      () => this.forcingChallenge()
    ];
    const challenge = templates[difficulty - 1]();
    return {
      id: `generated-${this.seed.toString(36)}`,
      difficulty,
      createdAt: new Date().toISOString(),
      ...challenge
    };
  }

  constantChallenge() {
    const horizontal = this.integer(1, 3);
    const vertical = this.integer(-2, 2) / 10;
    return {
      title: "Calibrate the drift",
      topic: "Constant rates",
      equations: { x: String(horizontal), y: String(vertical) },
      initial: { x: 0, y: -1 },
      target: { x: 8, y: 0 },
      objective: "Predict the slope and compensate for vertical drift.",
      hint: "A constant derivative produces a constant rate of change."
    };
  }

  stabilityChallenge() {
    const coefficient = this.integer(1, 4) / 2;
    return {
      title: "Stability check",
      topic: "Equilibrium stability",
      equations: { x: `-${coefficient}*x`, y: `-${coefficient}*y` },
      initial: { x: 3, y: -2 },
      target: { x: 0, y: 0 },
      objective: "Create a trajectory that approaches the equilibrium.",
      hint: "Negative linear feedback points back toward zero."
    };
  }

  couplingChallenge() {
    const coefficient = this.integer(1, 3) / 2;
    return {
      title: "Coupled navigation",
      topic: "Coupled systems",
      equations: { x: "y", y: `-${coefficient}*x` },
      initial: { x: 2, y: 0 },
      target: { x: 0, y: 0 },
      objective: "Inspect the relationship between the two state variables.",
      hint: "The variables influence one another, so changing one equation changes the complete path."
    };
  }

  dampingChallenge() {
    const damping = this.integer(1, 12) / 10;
    return {
      title: "Damping experiment",
      topic: "Second-order systems",
      equations: { x: "y", y: `-3*x-${damping}*y` },
      initial: { x: 2, y: 0 },
      target: { x: 0, y: 0 },
      objective: "Observe how damping changes the oscillation.",
      hint: "Increase the coefficient multiplying velocity to strengthen damping."
    };
  }

  forcingChallenge() {
    const amplitude = this.integer(1, 5) / 10;
    const frequency = this.integer(1, 4);
    return {
      title: "Periodic disturbance",
      topic: "Time-dependent systems",
      equations: { x: "y", y: `-2*x-0.3*y+${amplitude}*sin(${frequency}*t)` },
      initial: { x: 0, y: 0 },
      target: { x: 0, y: 0 },
      objective: "Study how a repeating input changes the system response.",
      hint: "The sine term is an external time-dependent input."
    };
  }

  snapshot() { return { seed: this.seed }; }
  restore(snapshot) { this.seed = Number(snapshot.seed) >>> 0; }
}
