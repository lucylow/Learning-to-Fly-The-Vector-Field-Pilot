import { rk4Step, trajectoryMetrics } from "../math/ODESolver.js";

export class FlightSimulator extends EventTarget {
  constructor({ system, initial = { x: 0, y: 0 }, target = { x: 8, y: 0 }, duration = 20, stepSize = .025 }) {
    super();
    this.system = system;
    this.initial = { ...initial, t: 0 };
    this.target = { ...target };
    this.duration = duration;
    this.stepSize = stepSize;
    this.state = { ...this.initial };
    this.history = [{ ...this.state }];
    this.elapsed = 0;
    this.running = false;
    this.completed = false;
    this.speedScale = 1;
    this.accumulator = 0;
    this.maxSubsteps = 12;
    this.lastError = null;
  }

  setSystem(system) {
    if (this.running) throw new Error("Pause the simulation before replacing the model.");
    this.system = system;
  }

  setSpeed(value) {
    this.speedScale = Math.max(.25, Math.min(2.5, Number(value) || 1));
  }

  start() {
    if (this.completed) this.reset();
    this.running = true;
    this.dispatchEvent(new CustomEvent("status", { detail: "running" }));
  }

  pause() {
    this.running = false;
    this.dispatchEvent(new CustomEvent("status", { detail: "paused" }));
  }

  reset() {
    this.running = false;
    this.completed = false;
    this.state = { ...this.initial };
    this.history = [{ ...this.state }];
    this.elapsed = 0;
    this.accumulator = 0;
    this.lastError = null;
    this.dispatchEvent(new CustomEvent("reset", { detail: this.snapshot() }));
  }

  tick(realDeltaSeconds) {
    if (!this.running) return this.snapshot();
    this.accumulator += Math.min(realDeltaSeconds, .1) * this.speedScale;
    let steps = 0;
    try {
      while (this.accumulator >= this.stepSize && steps < this.maxSubsteps) {
        const next = rk4Step(this.system, this.state, this.stepSize);
        if (![next.x, next.y, next.t].every(Number.isFinite)) throw new RangeError("Non-finite state.");
        if (Math.abs(next.x) > 100 || Math.abs(next.y) > 100) throw new RangeError("The trajectory left the supported simulation area.");
        this.state = next;
        this.elapsed += this.stepSize;
        this.accumulator -= this.stepSize;
        this.history.push({ ...this.state });
        if (this.history.length > 5000) this.history.shift();
        steps += 1;
        if (this.checkLanding()) {
          this.complete("landed");
          break;
        }
        if (this.elapsed >= this.duration) {
          this.complete("time-limit");
          break;
        }
      }
    } catch (error) {
      this.lastError = error.message;
      this.pause();
      this.dispatchEvent(new CustomEvent("error", { detail: error }));
    }
    this.dispatchEvent(new CustomEvent("frame", { detail: this.snapshot() }));
    return this.snapshot();
  }

  checkLanding() {
    const distance = Math.hypot(this.state.x - this.target.x, this.state.y - this.target.y);
    const rate = this.system(this.state);
    const speed = Math.hypot(rate.x, rate.y);
    return distance <= .35 && speed <= 1.5;
  }

  complete(reason) {
    this.running = false;
    this.completed = true;
    const metrics = trajectoryMetrics(this.history, this.target);
    const detail = {
      reason,
      success: reason === "landed",
      metrics,
      finalState: { ...this.state },
      elapsed: this.elapsed,
      points: this.history.map((point) => ({ ...point }))
    };
    this.dispatchEvent(new CustomEvent("complete", { detail }));
  }

  snapshot() {
    let rates = { x: 0, y: 0 };
    try { rates = this.system(this.state); } catch { /* Keep safe fallback rates. */ }
    return {
      state: { ...this.state },
      rates,
      elapsed: this.elapsed,
      running: this.running,
      completed: this.completed,
      history: this.history,
      target: this.target,
      speed: Math.hypot(rates.x, rates.y),
      distance: Math.hypot(this.state.x - this.target.x, this.state.y - this.target.y)
    };
  }

  runToEnd(maxFrames = 10000) {
    this.start();
    let frames = 0;
    while (this.running && frames < maxFrames) {
      this.tick(1 / 60);
      frames += 1;
    }
    return this.snapshot();
  }
}
