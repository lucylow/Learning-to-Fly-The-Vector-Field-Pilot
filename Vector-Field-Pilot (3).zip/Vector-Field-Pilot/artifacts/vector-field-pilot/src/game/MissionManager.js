import { MISSIONS } from "../data/missions.js";

export class MissionManager extends EventTarget {
  constructor(progressStore) {
    super();
    this.progressStore = progressStore;
    this.missions = MISSIONS.map((mission) => ({ ...mission }));
    this.current = this.missions[0];
    this.refreshUnlocks();
  }

  refreshUnlocks() {
    const completed = this.progressStore.getCompletedMissionIds();
    this.missions.forEach((mission, index) => {
      mission.unlocked = index === 0 || completed.includes(this.missions[index - 1].id);
    });
  }

  getAll() { return this.missions.map((mission) => ({ ...mission })); }
  getCurrent() { return { ...this.current }; }
  getById(id) { return this.missions.find((mission) => mission.id === Number(id)) ?? null; }

  select(id) {
    const mission = this.getById(id);
    if (!mission) throw new Error("Mission not found.");
    this.refreshUnlocks();
    if (!mission.unlocked) throw new Error("Complete the previous mission to unlock this flight.");
    this.current = mission;
    this.dispatchEvent(new CustomEvent("selected", { detail: { ...mission } }));
    return { ...mission };
  }

  recordResult(result) {
    const mission = this.current;
    const score = this.calculateScore(result, mission);
    const record = {
      id: crypto.randomUUID?.() ?? `${Date.now()}-${Math.random()}`,
      missionId: mission.id,
      missionName: mission.name,
      topic: mission.topic,
      equations: result.equations,
      initial: { ...mission.initial },
      final: result.finalState,
      elapsed: result.elapsed,
      distance: result.metrics.distance,
      pathLength: result.metrics.pathLength,
      success: result.success,
      score,
      createdAt: new Date().toISOString()
    };
    this.progressStore.addExperiment(record);
    if (result.success) this.progressStore.completeMission(mission.id, score);
    this.refreshUnlocks();
    this.dispatchEvent(new CustomEvent("result", { detail: record }));
    return record;
  }

  calculateScore(result, mission) {
    if (!result.success) return Math.max(0, Math.round(20 - result.metrics.distance * 2));
    const distanceBonus = Math.max(0, 50 - result.metrics.distance * 25);
    const timeBonus = Math.max(0, 30 - result.elapsed * 2);
    const efficiencyBonus = Math.max(0, 20 - Math.max(0, result.metrics.pathLength - 8));
    return Math.round(Math.min(100, 50 + distanceBonus + timeBonus + efficiencyBonus));
  }

  getProgress() {
    const completed = this.progressStore.getCompletedMissionIds();
    return { completed: completed.length, total: this.missions.length, percent: completed.length / this.missions.length * 100 };
  }
}
