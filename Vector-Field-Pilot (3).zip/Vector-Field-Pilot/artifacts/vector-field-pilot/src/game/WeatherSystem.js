/**
 * Deterministic weather and disturbance models for repeatable classroom experiments.
 * This environment is illustrative and does not model real meteorology.
 */
export class SeededRandom {
  constructor(seed = 123456789) {
    this.seed = (Number(seed) >>> 0) || 1;
  }

  next() {
    this.seed = (1664525 * this.seed + 1013904223) >>> 0;
    return this.seed / 4294967296;
  }

  signed() { return this.next() * 2 - 1; }

  gaussian() {
    const u = Math.max(1e-12, this.next());
    const v = this.next();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  snapshot() { return { seed: this.seed }; }
  restore(snapshot) { this.seed = Number(snapshot.seed) >>> 0; }
}

export class WeatherSystem {
  constructor(options = {}) {
    this.seed = options.seed ?? 42;
    this.random = new SeededRandom(this.seed);
    this.windStrength = options.windStrength ?? .25;
    this.turbulence = options.turbulence ?? 0;
    this.frequency = options.frequency ?? .5;
    this.direction = options.direction ?? 0;
    this.mode = options.mode ?? "calm";
    this.time = 0;
    this.noiseState = { x: 0, y: 0 };
    this.noiseMemory = options.noiseMemory ?? .85;
  }

  configure(options = {}) {
    if (Number.isFinite(options.windStrength)) this.windStrength = Math.max(0, options.windStrength);
    if (Number.isFinite(options.turbulence)) this.turbulence = Math.max(0, options.turbulence);
    if (Number.isFinite(options.frequency)) this.frequency = Math.max(0, options.frequency);
    if (Number.isFinite(options.direction)) this.direction = options.direction;
    if (["calm", "headwind", "tailwind", "crosswind", "periodic", "gusty"].includes(options.mode)) this.mode = options.mode;
    if (Number.isFinite(options.seed)) {
      this.seed = options.seed;
      this.random = new SeededRandom(this.seed);
    }
    return this.snapshot();
  }

  baseWind(position, time) {
    const angle = this.direction;
    const spatial = .12 * Math.sin(position.y * .4) + .08 * Math.cos(position.x * .25);
    const oscillation = this.mode === "periodic" ? Math.sin(time * this.frequency) * .5 : 0;
    let strength = this.windStrength + spatial + oscillation;
    if (this.mode === "headwind") strength *= -1;
    if (this.mode === "tailwind") strength = Math.abs(strength);
    if (this.mode === "crosswind") return { x: -Math.sin(angle) * strength, y: Math.cos(angle) * strength };
    return { x: Math.cos(angle) * strength, y: Math.sin(angle) * strength };
  }

  update(deltaTime) {
    const dt = Math.max(0, Math.min(.25, deltaTime));
    this.time += dt;
    const memory = Math.pow(this.noiseMemory, dt * 60);
    this.noiseState.x = memory * this.noiseState.x + (1 - memory) * this.random.gaussian();
    this.noiseState.y = memory * this.noiseState.y + (1 - memory) * this.random.gaussian();
  }

  sample(position, time = this.time) {
    const base = this.baseWind(position, time);
    const gust = this.mode === "gusty" ? Math.sin(time * 2.3) * this.windStrength * .6 : 0;
    return {
      x: base.x + gust + this.noiseState.x * this.turbulence,
      y: base.y + this.noiseState.y * this.turbulence
    };
  }

  describe() {
    const labels = {
      calm: "Calm air with a small spatial current.",
      headwind: "A steady wind opposes the reference direction.",
      tailwind: "A steady wind follows the reference direction.",
      crosswind: "A lateral current produces sideways drift.",
      periodic: "A sinusoidal wind changes direction over time.",
      gusty: "A repeating gust combines with bounded random turbulence."
    };
    return labels[this.mode] ?? labels.calm;
  }

  snapshot() {
    return {
      seed: this.seed,
      windStrength: this.windStrength,
      turbulence: this.turbulence,
      frequency: this.frequency,
      direction: this.direction,
      mode: this.mode,
      time: this.time,
      random: this.random.snapshot(),
      noiseState: { ...this.noiseState }
    };
  }

  restore(data) {
    this.configure(data);
    this.time = Number(data.time) || 0;
    this.random.restore(data.random ?? { seed: data.seed });
    this.noiseState = { ...(data.noiseState ?? { x: 0, y: 0 }) };
  }

  reset() {
    this.time = 0;
    this.random = new SeededRandom(this.seed);
    this.noiseState = { x: 0, y: 0 };
  }
}

export const WEATHER_PRESETS = Object.freeze({
  calm: { mode: "calm", windStrength: .05, turbulence: 0 },
  headwind: { mode: "headwind", windStrength: .35, turbulence: .02 },
  crosswind: { mode: "crosswind", windStrength: .45, turbulence: .04 },
  periodic: { mode: "periodic", windStrength: .3, frequency: .8, turbulence: 0 },
  gusty: { mode: "gusty", windStrength: .25, turbulence: .12 }
});

export function composeWindWithSystem(system, weather) {
  return (state) => {
    const base = system(state);
    const wind = weather.sample(state, state.t);
    return { x: base.x + wind.x, y: base.y + wind.y };
  };
}
