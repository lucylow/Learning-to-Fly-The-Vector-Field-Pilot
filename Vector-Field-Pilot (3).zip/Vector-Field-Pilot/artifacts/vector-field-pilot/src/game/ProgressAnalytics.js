/**
 * Learning analytics derived entirely from local experiment history.
 */
export function summarizeProgress(state) {
  const experiments = state.experiments ?? [];
  const completed = state.completedMissions ?? [];
  const notes = state.notes ?? [];
  const successful = experiments.filter((item) => item.success);
  const scores = successful.map((item) => item.score ?? 0);
  return {
    missionCount: completed.length,
    experimentCount: experiments.length,
    successfulFlights: successful.length,
    unsuccessfulFlights: experiments.length - successful.length,
    successRate: experiments.length ? successful.length / experiments.length : 0,
    averageScore: scores.length ? scores.reduce((sum, score) => sum + score, 0) / scores.length : 0,
    notesCount: notes.length,
    topics: topicSummary(experiments)
  };
}

export function topicSummary(experiments) {
  const topics = new Map();
  for (const experiment of experiments) {
    const topic = experiment.topic || "Uncategorized";
    const current = topics.get(topic) ?? { topic, attempts: 0, successes: 0, totalScore: 0 };
    current.attempts += 1;
    current.successes += Number(Boolean(experiment.success));
    current.totalScore += Number(experiment.score ?? 0);
    topics.set(topic, current);
  }
  return [...topics.values()].map((item) => ({
    ...item,
    successRate: item.attempts ? item.successes / item.attempts : 0,
    averageScore: item.attempts ? item.totalScore / item.attempts : 0
  })).sort((a, b) => a.topic.localeCompare(b.topic));
}

export function recentActivity(experiments, limit = 10) {
  return [...experiments]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, limit)
    .map((item) => ({
      date: item.createdAt,
      label: item.missionName,
      status: item.success ? "success" : "practice",
      score: item.score ?? 0
    }));
}

export function improvementTrend(experiments, windowSize = 5) {
  const sorted = [...experiments].sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  const windows = [];
  for (let index = 0; index < sorted.length; index += windowSize) {
    const group = sorted.slice(index, index + windowSize);
    const successes = group.filter((item) => item.success).length;
    const scores = group.map((item) => item.score ?? 0);
    windows.push({
      startIndex: index + 1,
      endIndex: index + group.length,
      attempts: group.length,
      successRate: successes / group.length,
      averageScore: scores.reduce((sum, value) => sum + value, 0) / group.length
    });
  }
  return windows;
}

export function suggestReviewTopics(experiments) {
  return topicSummary(experiments)
    .filter((item) => item.attempts >= 2 && item.successRate < .5)
    .sort((a, b) => a.successRate - b.successRate)
    .map((item) => ({
      topic: item.topic,
      reason: `You have completed ${item.attempts} attempts with a ${Math.round(item.successRate * 100)}% success rate.`,
      suggestedAction: "Revisit the lesson and compare two different equation configurations."
    }));
}

export function buildProgressSnapshot(state) {
  const summary = summarizeProgress(state);
  return {
    generatedAt: new Date().toISOString(),
    summary,
    recent: recentActivity(state.experiments ?? []),
    improvement: improvementTrend(state.experiments ?? []),
    reviewSuggestions: suggestReviewTopics(state.experiments ?? [])
  };
}
