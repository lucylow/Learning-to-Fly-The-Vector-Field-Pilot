/**
 * Local-only classroom assignment helpers.
 * No student accounts or remote transmission are implemented.
 */
export class AssignmentBuilder {
  constructor(missions = []) {
    this.missions = missions;
    this.assignment = {
      id: makeId(),
      title: "Differential Equations Flight Lab",
      instructions: "",
      missionIds: [],
      allowHints: true,
      allowAdvancedTerms: false,
      timeLimitMinutes: 30,
      createdAt: new Date().toISOString()
    };
  }

  setTitle(title) { this.assignment.title = String(title).trim().slice(0, 120); }
  setInstructions(value) { this.assignment.instructions = String(value).slice(0, 4000); }
  setMissions(ids) {
    const allowed = new Set(this.missions.map((mission) => mission.id));
    this.assignment.missionIds = [...new Set(ids.map(Number))].filter((id) => allowed.has(id));
  }
  setHints(enabled) { this.assignment.allowHints = Boolean(enabled); }
  setAdvancedTerms(enabled) { this.assignment.allowAdvancedTerms = Boolean(enabled); }
  setTimeLimit(minutes) { this.assignment.timeLimitMinutes = Math.max(5, Math.min(240, Number(minutes) || 30)); }

  validate() {
    const errors = [];
    if (!this.assignment.title) errors.push("Assignment title is required.");
    if (!this.assignment.missionIds.length) errors.push("Select at least one mission.");
    if (this.assignment.timeLimitMinutes < 5) errors.push("Time limit must be at least five minutes.");
    return { valid: errors.length === 0, errors };
  }

  export() {
    const result = this.validate();
    if (!result.valid) throw new Error(result.errors.join(" "));
    return JSON.parse(JSON.stringify(this.assignment));
  }

  import(data) {
    if (!data || !Array.isArray(data.missionIds)) throw new TypeError("Invalid assignment file.");
    this.setTitle(data.title ?? "");
    this.setInstructions(data.instructions ?? "");
    this.setMissions(data.missionIds);
    this.setHints(data.allowHints);
    this.setAdvancedTerms(data.allowAdvancedTerms);
    this.setTimeLimit(data.timeLimitMinutes);
    return this.export();
  }
}

export class StudentReport {
  constructor({ learnerCode = "LOCAL-LEARNER", assignment = null } = {}) {
    this.learnerCode = learnerCode;
    this.assignment = assignment;
    this.flights = [];
    this.reflections = [];
  }

  addFlight(record) {
    if (!record || !record.missionId || !record.equations) throw new TypeError("Flight report is incomplete.");
    this.flights.push({
      missionId: record.missionId,
      missionName: record.missionName,
      topic: record.topic,
      equations: { ...record.equations },
      initial: { ...record.initial },
      final: { ...record.final },
      elapsed: record.elapsed,
      success: Boolean(record.success),
      score: record.score,
      recordedAt: record.createdAt ?? new Date().toISOString()
    });
  }

  addReflection(text, topic = "General") {
    const content = String(text).trim();
    if (!content) return false;
    this.reflections.push({ topic, content, createdAt: new Date().toISOString() });
    return true;
  }

  summary() {
    const successful = this.flights.filter((flight) => flight.success);
    const scores = successful.map((flight) => flight.score);
    return {
      flights: this.flights.length,
      successful: successful.length,
      successRate: this.flights.length ? successful.length / this.flights.length : 0,
      averageScore: scores.length ? scores.reduce((sum, value) => sum + value, 0) / scores.length : 0,
      topics: [...new Set(this.flights.map((flight) => flight.topic))]
    };
  }

  export() {
    return {
      format: "vector-field-pilot-student-report",
      version: 1,
      generatedAt: new Date().toISOString(),
      learnerCode: this.learnerCode,
      assignment: this.assignment,
      summary: this.summary(),
      flights: this.flights,
      reflections: this.reflections
    };
  }
}

export function anonymizeReport(report) {
  const copy = JSON.parse(JSON.stringify(report));
  copy.learnerCode = "ANON";
  delete copy.studentName;
  delete copy.email;
  delete copy.accountId;
  return copy;
}

function makeId() {
  return `assignment-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
