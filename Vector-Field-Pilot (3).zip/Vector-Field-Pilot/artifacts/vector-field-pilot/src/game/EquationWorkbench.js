/**
 * Equation workbench helpers: term composition, safe validation, presets,
 * change history and human-readable summaries for the equation editor.
 */
import { validateExpression, ExpressionParser } from "../math/ExpressionParser.js";

export class EquationWorkbench extends EventTarget {
  constructor(initial = { x: "1", y: "0" }, options = {}) {
    super();
    this.maxHistory = options.maxHistory ?? 100;
    this.current = { x: String(initial.x), y: String(initial.y) };
    this.history = [];
    this.future = [];
    this.pushHistory();
  }

  get equations() { return { ...this.current }; }

  validate(candidate = this.current) {
    const x = validateExpression(candidate.x);
    const y = validateExpression(candidate.y);
    return {
      valid: x.valid && y.valid,
      fields: { x, y },
      errors: [
        ...(x.valid ? [] : [`dx/dt: ${x.message}`]),
        ...(y.valid ? [] : [`dy/dt: ${y.message}`])
      ]
    };
  }

  set(axis, expression) {
    if (!["x", "y"].includes(axis)) throw new TypeError("Equation axis must be x or y.");
    const candidate = { ...this.current, [axis]: String(expression) };
    const validation = this.validate(candidate);
    if (!validation.valid) {
      this.dispatchEvent(new CustomEvent("invalid", { detail: validation }));
      return validation;
    }
    this.current = candidate;
    this.pushHistory();
    this.future = [];
    this.dispatchEvent(new CustomEvent("change", { detail: this.equations }));
    return validation;
  }

  replace(candidate) {
    const validation = this.validate(candidate);
    if (!validation.valid) return validation;
    this.current = { x: candidate.x.trim(), y: candidate.y.trim() };
    this.pushHistory();
    this.future = [];
    this.dispatchEvent(new CustomEvent("change", { detail: this.equations }));
    return validation;
  }

  appendTerm(axis, term, operator = "+") {
    if (!["x", "y"].includes(axis)) throw new TypeError("Equation axis must be x or y.");
    const current = this.current[axis].trim();
    const expression = current ? `${current}${operator}(${term})` : String(term);
    return this.set(axis, expression);
  }

  removeLastTerm(axis) {
    const source = this.current[axis];
    const terms = splitTopLevelTerms(source);
    if (terms.length <= 1) return this.set(axis, "0");
    terms.pop();
    return this.set(axis, terms.join(""));
  }

  undo() {
    if (this.history.length < 2) return false;
    this.future.push(this.history.pop());
    this.current = { ...this.history.at(-1) };
    this.dispatchEvent(new CustomEvent("change", { detail: this.equations }));
    return true;
  }

  redo() {
    if (!this.future.length) return false;
    const next = this.future.pop();
    this.current = { ...next };
    this.history.push({ ...next });
    this.dispatchEvent(new CustomEvent("change", { detail: this.equations }));
    return true;
  }

  pushHistory() {
    const last = this.history.at(-1);
    if (last && last.x === this.current.x && last.y === this.current.y) return;
    this.history.push({ ...this.current });
    if (this.history.length > this.maxHistory) this.history.shift();
  }

  reset(equations = { x: "1", y: "0" }) {
    this.current = { x: String(equations.x), y: String(equations.y) };
    this.history = [];
    this.future = [];
    this.pushHistory();
    this.dispatchEvent(new CustomEvent("change", { detail: this.equations }));
  }

  evaluate(state) {
    const validation = this.validate();
    if (!validation.valid) throw new Error(validation.errors.join(" "));
    const x = ExpressionParser.compile(this.current.x);
    const y = ExpressionParser.compile(this.current.y);
    return { x: x.evaluate(state), y: y.evaluate(state) };
  }

  describeAt(state) {
    const rate = this.evaluate(state);
    return {
      state: { x: state.x, y: state.y, t: state.t ?? 0 },
      rate,
      magnitude: Math.hypot(rate.x, rate.y),
      directionDegrees: Math.atan2(rate.y, rate.x) * 180 / Math.PI
    };
  }

  snapshot() {
    return {
      equations: this.equations,
      history: this.history.map((item) => ({ ...item })),
      future: this.future.map((item) => ({ ...item }))
    };
  }

  restore(snapshot) {
    const validation = this.validate(snapshot.equations);
    if (!validation.valid) throw new TypeError(validation.errors.join(" "));
    this.current = { ...snapshot.equations };
    this.history = (snapshot.history ?? [this.current]).map((item) => ({ ...item }));
    this.future = (snapshot.future ?? []).map((item) => ({ ...item }));
    if (!this.history.length) this.pushHistory();
    this.dispatchEvent(new CustomEvent("change", { detail: this.equations }));
  }
}

export function splitTopLevelTerms(expression) {
  const source = String(expression);
  const terms = [];
  let depth = 0;
  let start = 0;
  for (let index = 0; index < source.length; index += 1) {
    const character = source[index];
    if (character === "(") depth += 1;
    else if (character === ")") depth = Math.max(0, depth - 1);
    else if ((character === "+" || character === "-") && depth === 0 && index > start) {
      const previous = source[index - 1];
      if (previous !== "e" && previous !== "E") {
        terms.push(source.slice(start, index));
        start = index;
      }
    }
  }
  if (source.slice(start).trim()) terms.push(source.slice(start));
  return terms;
}

export function expressionComplexity(expression) {
  const source = String(expression);
  const terms = splitTopLevelTerms(source);
  const nonlinearTerms = (source.match(/\b[xy]\s*\*\s*[xy]\b|\b[xy]\s*\^\s*[2-9]/g) ?? []).length;
  const functionCalls = (source.match(/\b(?:sin|cos|tan|exp|log|sqrt|abs)\s*\(/g) ?? []).length;
  const coupling = (source.match(/\b[xy]\b/g) ?? []).length;
  return {
    characters: source.length,
    topLevelTerms: terms.length,
    nonlinearTerms,
    functionCalls,
    variableOccurrences: coupling,
    score: terms.length + nonlinearTerms * 2 + functionCalls * 2
  };
}

export function compareEquationPairs(first, second) {
  return {
    xChanged: first.x !== second.x,
    yChanged: first.y !== second.y,
    sameModel: first.x === second.x && first.y === second.y,
    before: { ...first },
    after: { ...second }
  };
}

export function equationSummary(equations) {
  const x = expressionComplexity(equations.x);
  const y = expressionComplexity(equations.y);
  const total = x.score + y.score;
  return {
    x,
    y,
    totalComplexity: total,
    label: total <= 4 ? "Introductory" : total <= 9 ? "Developing" : "Advanced",
    hasTimeDependence: /\bt\b/.test(`${equations.x} ${equations.y}`),
    hasTrigonometry: /\b(?:sin|cos|tan)\s*\(/.test(`${equations.x} ${equations.y}`),
    hasCrossCoupling: /\by\b/.test(equations.x) || /\bx\b/.test(equations.y)
  };
}
