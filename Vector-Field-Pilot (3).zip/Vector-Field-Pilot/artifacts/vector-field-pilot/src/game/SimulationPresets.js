/**
 * Reusable model presets for free-flight experiments.
 */
export const SIMULATION_PRESETS = Object.freeze([
  {
    id: "uniform-flow",
    title: "Uniform flow",
    category: "First-order",
    equations: { x: "1", y: "0" },
    initial: { x: -4, y: 0 },
    explanation: "A constant vector field creates a straight horizontal trajectory."
  },
  {
    id: "stable-node",
    title: "Stable node",
    category: "Stability",
    equations: { x: "-x", y: "-2*y" },
    initial: { x: 4, y: 3 },
    explanation: "Both state variables decay toward zero, at different rates."
  },
  {
    id: "unstable-node",
    title: "Unstable node",
    category: "Stability",
    equations: { x: "x", y: "0.7*y" },
    initial: { x: .5, y: .5 },
    explanation: "Small displacements grow away from the origin."
  },
  {
    id: "saddle",
    title: "Saddle",
    category: "Stability",
    equations: { x: "x", y: "-y" },
    initial: { x: .4, y: 2 },
    explanation: "The x direction is unstable while the y direction is stable."
  },
  {
    id: "center",
    title: "Center",
    category: "Coupled",
    equations: { x: "y", y: "-x" },
    initial: { x: 3, y: 0 },
    explanation: "The ideal linear system has circular orbits around the origin."
  },
  {
    id: "stable-spiral",
    title: "Stable spiral",
    category: "Coupled",
    equations: { x: "-0.3*x+y", y: "-x-0.3*y" },
    initial: { x: 3, y: 0 },
    explanation: "Coupling rotates the motion while negative trace causes the spiral to decay."
  },
  {
    id: "damped-oscillator",
    title: "Damped oscillator",
    category: "Second-order",
    equations: { x: "y", y: "-4*x-0.5*y" },
    initial: { x: 2, y: 0 },
    explanation: "The first equation tracks velocity; the second combines restoring force and damping."
  },
  {
    id: "forced-oscillator",
    title: "Forced oscillator",
    category: "Second-order",
    equations: { x: "y", y: "-4*x-0.2*y+0.5*sin(2*t)" },
    initial: { x: 0, y: 0 },
    explanation: "A periodic external input drives a damped oscillator."
  },
  {
    id: "nonlinear-growth",
    title: "Nonlinear growth",
    category: "Nonlinear",
    equations: { x: "x*(1-x)", y: "-0.4*y" },
    initial: { x: .2, y: 2 },
    explanation: "The horizontal rate changes sign at x = 0 and x = 1."
  }
]);

export function presetById(id) {
  return SIMULATION_PRESETS.find((preset) => preset.id === id) ?? null;
}

export function groupPresets() {
  return SIMULATION_PRESETS.reduce((groups, preset) => {
    groups[preset.category] ??= [];
    groups[preset.category].push(preset);
    return groups;
  }, {});
}

export function applyPreset(preset, equationInputs) {
  if (!preset || !equationInputs?.x || !equationInputs?.y) throw new TypeError("Preset and equation inputs are required.");
  equationInputs.x.value = preset.equations.x;
  equationInputs.y.value = preset.equations.y;
  return { ...preset, equations: { ...preset.equations }, initial: { ...preset.initial } };
}
