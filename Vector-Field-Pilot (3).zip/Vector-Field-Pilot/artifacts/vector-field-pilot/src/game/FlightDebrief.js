/**
 * Debrief generator turns a simulation result into specific, evidence-based feedback.
 */
export class FlightDebrief {
  constructor({ distanceThreshold = 1, speedThreshold = 1.5 } = {}) {
    this.distanceThreshold = distanceThreshold;
    this.speedThreshold = speedThreshold;
  }

  analyze({ result, mission, equations = {} }) {
    const points = result.points ?? [];
    const final = result.finalState ?? points.at(-1) ?? { x: 0, y: 0, t: 0 };
    const target = mission.target ?? { x: 0, y: 0 };
    const distance = Math.hypot(final.x - target.x, final.y - target.y);
    const finalRates = result.finalRates ?? null;
    const findings = [];
    if (result.success) findings.push(this.successFinding(distance));
    else findings.push(this.distanceFinding(distance, mission.tolerance ?? this.distanceThreshold));
    if (finalRates) findings.push(this.speedFinding(Math.hypot(finalRates.x, finalRates.y)));
    findings.push(...this.trajectoryFindings(points));
    findings.push(...this.equationFindings(equations));
    return {
      title: result.success ? "Landing complete" : "Flight review",
      outcome: result.success ? "success" : "practice",
      distance,
      finalState: { ...final },
      findings,
      nextExperiment: this.nextExperiment(findings, equations),
      learningTopic: mission.topic ?? "Dynamical systems"
    };
  }

  successFinding(distance) {
    return {
      type: "positive",
      title: "Target reached",
      detail: `The final state finished ${distance.toFixed(2)} units from the target.`
    };
  }

  distanceFinding(distance, tolerance) {
    return {
      type: distance <= tolerance ? "neutral" : "warning",
      title: distance <= tolerance ? "Near the landing zone" : "Target not reached",
      detail: `Final target error was ${distance.toFixed(2)} units; the mission tolerance is ${tolerance.toFixed(2)} units.`
    };
  }

  speedFinding(speed) {
    return {
      type: speed <= this.speedThreshold ? "positive" : "warning",
      title: "Final rate of change",
      detail: `The final derivative magnitude was ${speed.toFixed(2)} units per time unit.`
    };
  }

  trajectoryFindings(points) {
    if (points.length < 3) return [{ type: "neutral", title: "Limited trajectory data", detail: "Run a longer simulation to inspect the shape of the trajectory." }];
    const xRange = range(points.map((point) => point.x));
    const yRange = range(points.map((point) => point.y));
    const findings = [];
    if (xRange > 10 || yRange > 10) findings.push({
      type: "warning",
      title: "Large state excursion",
      detail: "The trajectory covered a wide range of state values. Inspect whether a positive feedback term caused growth."
    });
    if (xRange < .05 && yRange < .05) findings.push({
      type: "neutral",
      title: "Very small movement",
      detail: "The state changed very little. Check whether the equations produce rates close to zero at the initial condition."
    });
    if (!findings.length) findings.push({
      type: "positive",
      title: "Trajectory remained in a bounded region",
      detail: "The sampled state stayed within a moderate range during this flight."
    });
    return findings;
  }

  equationFindings(equations) {
    const findings = [];
    const x = String(equations.x ?? "");
    const y = String(equations.y ?? "");
    if (/-\s*(?:[0-9.]+\s*\*)?[xy]/.test(x + y)) findings.push({
      type: "info",
      title: "Negative feedback term detected",
      detail: "A negative linear term can push a positive state back toward zero, depending on the rest of the system."
    });
    if (/sin|cos/.test(x + y)) findings.push({
      type: "info",
      title: "Periodic term detected",
      detail: "A trigonometric term can introduce time-periodic or state-periodic behaviour."
    });
    if (/[xy]\s*\*/.test(x + y)) findings.push({
      type: "info",
      title: "Nonlinear interaction detected",
      detail: "Products of state variables make the rate depend nonlinearly on the current state."
    });
    return findings;
  }

  nextExperiment(findings, equations) {
    if (findings.some((item) => item.title === "Large state excursion")) return "Try reducing positive growth terms or adding a restoring term, then compare the trajectory.";
    if (/sin|cos/.test(`${equations.x} ${equations.y}`)) return "Change the amplitude or frequency of the periodic term while keeping the other terms fixed.";
    if (/-/.test(`${equations.x} ${equations.y}`)) return "Change one negative coefficient and observe how the rate of approach changes.";
    return "Change one equation term at a time and record how the trajectory changes.";
  }
}

function range(values) {
  return Math.max(...values) - Math.min(...values);
}
