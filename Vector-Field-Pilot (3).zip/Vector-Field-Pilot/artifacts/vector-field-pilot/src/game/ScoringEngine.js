/**
 * Transparent mission scoring. The score is decomposed so learners can see
 * how distance, time, efficiency and stability contributed to the result.
 */
export class ScoringEngine {
  constructor(weights = {}) {
    this.weights = {
      completion: weights.completion ?? 40,
      landing: weights.landing ?? 25,
      time: weights.time ?? 15,
      efficiency: weights.efficiency ?? 10,
      smoothness: weights.smoothness ?? 10
    };
  }

  scoreFlight(result, mission = {}) {
    const metrics = result.metrics ?? {};
    const targetTolerance = Math.max(.01, mission.tolerance ?? 1);
    const distance = Math.max(0, metrics.distance ?? Infinity);
    const time = Math.max(0, result.elapsed ?? mission.duration ?? 0);
    const pathLength = Math.max(0, metrics.pathLength ?? 0);
    const completion = result.success ? this.weights.completion : 0;
    const landing = result.success ? this.weights.landing * clamp01(1 - distance / targetTolerance) : 0;
    const timeLimit = Math.max(1, mission.duration ?? 10);
    const timeScore = this.weights.time * clamp01(1 - time / timeLimit);
    const idealPath = Math.max(1, Math.hypot(
      (mission.target?.x ?? 0) - (mission.initial?.x ?? 0),
      (mission.target?.y ?? 0) - (mission.initial?.y ?? 0)
    ));
    const efficiency = this.weights.efficiency * clamp01(1 - Math.max(0, pathLength - idealPath) / (idealPath * 3));
    const smoothness = this.weights.smoothness * this.smoothnessScore(result.points ?? []);
    const total = Math.round(Math.min(100, completion + landing + timeScore + efficiency + smoothness));
    return {
      total,
      success: Boolean(result.success),
      components: {
        completion: round(completion),
        landing: round(landing),
        time: round(timeScore),
        efficiency: round(efficiency),
        smoothness: round(smoothness)
      },
      explanation: this.explain({ completion, landing, timeScore, efficiency, smoothness, distance, time, pathLength })
    };
  }

  smoothnessScore(points) {
    if (!Array.isArray(points) || points.length < 3) return this.weights.smoothness * .5;
    let variation = 0;
    let previousAngle = null;
    for (let index = 1; index < points.length; index += 1) {
      const dx = points[index].x - points[index - 1].x;
      const dy = points[index].y - points[index - 1].y;
      const angle = Math.atan2(dy, dx);
      if (previousAngle !== null) {
        let delta = Math.abs(angle - previousAngle);
        if (delta > Math.PI) delta = Math.PI * 2 - delta;
        variation += delta;
      }
      previousAngle = angle;
    }
    const average = variation / Math.max(1, points.length - 2);
    return this.weights.smoothness * clamp01(1 - average / Math.PI);
  }

  explain(values) {
    const parts = [];
    parts.push(values.completion > 0 ? "The landing objective was completed." : "The landing objective was not completed.");
    parts.push(`Final target error was ${Number(values.distance).toFixed(2)} units.`);
    parts.push(`The flight used ${Number(values.time).toFixed(2)} seconds and travelled ${Number(values.pathLength).toFixed(2)} units.`);
    parts.push("Efficiency and smoothness are secondary rewards, not requirements for learning.");
    return parts.join(" ");
  }

  stars(score) {
    if (score >= 90) return 3;
    if (score >= 70) return 2;
    if (score >= 40) return 1;
    return 0;
  }

  grade(score) {
    if (score >= 90) return "A — Excellent";
    if (score >= 80) return "B — Strong";
    if (score >= 65) return "C — Developing";
    if (score >= 40) return "D — Practice";
    return "Keep experimenting";
  }
}

function clamp01(value) { return Math.max(0, Math.min(1, value)); }
function round(value) { return Math.round(value * 10) / 10; }
