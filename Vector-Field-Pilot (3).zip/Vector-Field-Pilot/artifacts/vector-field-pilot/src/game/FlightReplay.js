/**
 * Replay archive for deterministic flight experiments.
 * Stores compact snapshots and supports cursor-based inspection.
 */
export class FlightReplay {
  constructor({ maxFrames = 10000 } = {}) {
    this.maxFrames = maxFrames;
    this.frames = [];
    this.metadata = {};
    this.cursor = 0;
    this.playing = false;
    this.playbackRate = 1;
    this.accumulator = 0;
  }

  begin(metadata = {}) {
    this.frames = [];
    this.metadata = structuredCloneSafe(metadata);
    this.cursor = 0;
    this.playing = false;
    this.accumulator = 0;
  }

  record(frame) {
    if (this.frames.length >= this.maxFrames) return false;
    const clean = {
      t: Number(frame.t ?? frame.elapsed ?? 0),
      x: Number(frame.x ?? frame.state?.x),
      y: Number(frame.y ?? frame.state?.y),
      vx: Number(frame.vx ?? frame.rates?.x ?? 0),
      vy: Number(frame.vy ?? frame.rates?.y ?? 0)
    };
    if (!Object.values(clean).every(Number.isFinite)) return false;
    const previous = this.frames.at(-1);
    if (previous && clean.t < previous.t) throw new RangeError("Replay time must be monotonic.");
    this.frames.push(clean);
    return true;
  }

  finish(summary = {}) {
    this.metadata.summary = structuredCloneSafe(summary);
    this.metadata.frameCount = this.frames.length;
    this.metadata.duration = this.frames.at(-1)?.t ?? 0;
    return this.export();
  }

  seek(time) {
    if (!this.frames.length) return null;
    const target = Math.max(this.frames[0].t, Math.min(this.frames.at(-1).t, time));
    let low = 0, high = this.frames.length - 1;
    while (low < high) {
      const mid = Math.floor((low + high) / 2);
      if (this.frames[mid].t < target) low = mid + 1;
      else high = mid;
    }
    this.cursor = low;
    const current = this.frames[low];
    const previous = this.frames[Math.max(0, low - 1)];
    return interpolateFrame(previous, current, target);
  }

  step(direction = 1) {
    if (!this.frames.length) return null;
    this.cursor = Math.max(0, Math.min(this.frames.length - 1, this.cursor + Math.sign(direction)));
    return { ...this.frames[this.cursor] };
  }

  play(rate = 1) {
    this.playbackRate = Math.max(.1, Math.min(4, rate));
    this.playing = true;
  }

  pause() { this.playing = false; }

  update(deltaTime) {
    if (!this.playing || !this.frames.length) return this.current();
    this.accumulator += Math.max(0, deltaTime) * this.playbackRate;
    const current = this.frames[this.cursor];
    const next = this.frames[this.cursor + 1];
    if (!next) { this.pause(); return this.current(); }
    if (this.accumulator >= next.t - current.t) {
      this.accumulator = 0;
      this.cursor += 1;
      if (this.cursor >= this.frames.length - 1) this.pause();
    }
    return this.current();
  }

  current() {
    return this.frames[this.cursor] ? { ...this.frames[this.cursor] } : null;
  }

  compare(other) {
    const duration = Math.min(this.frames.at(-1)?.t ?? 0, other.frames.at(-1)?.t ?? 0);
    const samples = [];
    const count = 50;
    for (let i = 0; i <= count; i += 1) {
      const t = duration * i / count;
      const a = this.seek(t);
      const b = other.seek(t);
      if (a && b) samples.push({ t, deltaX: a.x - b.x, deltaY: a.y - b.y, separation: Math.hypot(a.x - b.x, a.y - b.y) });
    }
    return samples;
  }

  export() {
    return {
      version: 1,
      metadata: structuredCloneSafe(this.metadata),
      frames: this.frames.map((frame) => ({ ...frame }))
    };
  }

  import(data) {
    if (!data || data.version !== 1 || !Array.isArray(data.frames)) throw new TypeError("Unsupported replay format.");
    this.begin(data.metadata ?? {});
    for (const frame of data.frames) {
      if (!this.record(frame)) throw new RangeError("Replay contains invalid or excessive frames.");
    }
    return this;
  }

  static from(data) {
    return new FlightReplay().import(data);
  }
}

function interpolateFrame(a, b, time) {
  const span = b.t - a.t;
  const amount = span <= 0 ? 0 : (time - a.t) / span;
  const result = { t: time };
  for (const key of ["x", "y", "vx", "vy"]) result[key] = a[key] + (b[key] - a[key]) * amount;
  return result;
}

function structuredCloneSafe(value) {
  return value == null ? {} : JSON.parse(JSON.stringify(value));
}
