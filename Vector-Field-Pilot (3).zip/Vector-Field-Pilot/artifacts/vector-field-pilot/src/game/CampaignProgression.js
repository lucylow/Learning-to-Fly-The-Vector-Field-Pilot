/**
 * Campaign progression graph. Supports prerequisites, optional branches,
 * achievement gates and a clearable view of the player's next available work.
 */
export class CampaignProgression extends EventTarget {
  constructor(nodes = []) {
    super();
    this.nodes = nodes.map((node) => normalizeNode(node));
    this.completed = new Set();
    this.achievements = new Set();
    this.validateGraph();
  }

  validateGraph() {
    const ids = new Set(this.nodes.map((node) => node.id));
    const duplicates = this.nodes.filter((node, index) => this.nodes.findIndex((item) => item.id === node.id) !== index);
    if (duplicates.length) throw new TypeError("Campaign node IDs must be unique.");
    for (const node of this.nodes) {
      for (const dependency of node.requires) {
        if (!ids.has(dependency)) throw new TypeError(`Campaign node ${node.id} requires missing node ${dependency}.`);
      }
    }
    this.detectCycles();
    return true;
  }

  detectCycles() {
    const visiting = new Set();
    const visited = new Set();
    const byId = new Map(this.nodes.map((node) => [node.id, node]));
    const visit = (id) => {
      if (visiting.has(id)) throw new TypeError("Campaign dependency graph contains a cycle.");
      if (visited.has(id)) return;
      visiting.add(id);
      for (const dependency of byId.get(id).requires) visit(dependency);
      visiting.delete(id);
      visited.add(id);
    };
    this.nodes.forEach((node) => visit(node.id));
  }

  unlockAchievement(id) {
    this.achievements.add(id);
    this.dispatchEvent(new CustomEvent("achievement", { detail: id }));
  }

  isUnlocked(node) {
    return node.requires.every((id) => this.completed.has(id)) &&
      node.achievementRequirements.every((id) => this.achievements.has(id));
  }

  complete(id, result = {}) {
    const node = this.nodes.find((item) => item.id === id);
    if (!node) throw new Error(`Unknown campaign node: ${id}`);
    if (!this.isUnlocked(node)) throw new Error("This campaign activity is still locked.");
    this.completed.add(id);
    const detail = { id, result: structuredCloneSafe(result), next: this.available() };
    this.dispatchEvent(new CustomEvent("completed", { detail }));
    return detail;
  }

  available() {
    return this.nodes.filter((node) => !this.completed.has(node.id) && this.isUnlocked(node)).map((node) => ({ ...node }));
  }

  locked() {
    return this.nodes.filter((node) => !this.completed.has(node.id) && !this.isUnlocked(node)).map((node) => ({
      ...node,
      missingMissions: node.requires.filter((id) => !this.completed.has(id)),
      missingAchievements: node.achievementRequirements.filter((id) => !this.achievements.has(id))
    }));
  }

  progress() {
    const total = this.nodes.length;
    const completed = this.completed.size;
    return { total, completed, remaining: total - completed, percent: total ? completed / total * 100 : 0 };
  }

  reset() {
    this.completed.clear();
    this.achievements.clear();
    this.dispatchEvent(new Event("reset"));
  }

  export() {
    return {
      version: 1,
      completed: [...this.completed],
      achievements: [...this.achievements]
    };
  }

  import(data) {
    if (data?.version !== 1) throw new TypeError("Unsupported campaign save version.");
    const validIds = new Set(this.nodes.map((node) => node.id));
    this.completed = new Set((data.completed ?? []).filter((id) => validIds.has(id)));
    this.achievements = new Set(data.achievements ?? []);
    return this.progress();
  }
}

function normalizeNode(node) {
  if (!node || typeof node.id !== "string" || !node.id.trim()) throw new TypeError("Campaign node requires a string ID.");
  return {
    id: node.id,
    title: String(node.title ?? node.id),
    description: String(node.description ?? ""),
    requires: [...new Set(node.requires ?? [])],
    achievementRequirements: [...new Set(node.achievementRequirements ?? [])],
    category: node.category ?? "mission"
  };
}

function structuredCloneSafe(value) {
  return value == null ? {} : JSON.parse(JSON.stringify(value));
}
