import { integrate } from "../math/ODESolver.js";
import { ExpressionParser } from "../math/ExpressionParser.js";

const MODELS = Object.freeze([
  {
    id: "damped-oscillator",
    title: "Damped oscillator",
    parameter: "Damping",
    min: 0.1,
    max: 2.5,
    initial: { x: 2, y: 0 },
    equations: { x: "y", y: "-4*x-{p}*y" },
    description: "See how damping changes the return to equilibrium."
  },
  {
    id: "stable-focus",
    title: "Stable focus",
    parameter: "Decay rate",
    min: 0.1,
    max: 1.5,
    initial: { x: 3, y: 0 },
    equations: { x: "-{p}*x+y", y: "-x-{p}*y" },
    description: "Compare how quickly a coupled system spirals inward."
  },
  {
    id: "rotating-flow",
    title: "Rotating flow",
    parameter: "Rotation rate",
    min: 0.2,
    max: 2.8,
    initial: { x: 3, y: 0 },
    equations: { x: "-{p}*y", y: "{p}*x" },
    description: "Change angular speed while tracking the same initial state."
  }
]);

const MAX_TRAJECTORIES = 9;
const MAX_DURATION = 30;
const STEP_SIZE = 0.025;
const CHART_POINT_LIMIT = 180;
const DEMO_SWEEPS = Object.freeze([
  {
    id: "demo-damping",
    modelId: "damped-oscillator",
    modelTitle: "Damped oscillator",
    parameter: "Damping",
    min: 0.1,
    max: 1.8,
    samples: 5,
    duration: 10,
    insight: "Higher damping shortens the visible oscillations."
  },
  {
    id: "demo-focus",
    modelId: "stable-focus",
    modelTitle: "Stable focus",
    parameter: "Decay rate",
    min: 0.15,
    max: 1.2,
    samples: 5,
    duration: 12,
    insight: "Faster decay tightens the spiral toward equilibrium."
  },
  {
    id: "demo-rotation",
    modelId: "rotating-flow",
    modelTitle: "Rotating flow",
    parameter: "Rotation rate",
    min: 0.5,
    max: 1.8,
    samples: 5,
    duration: 8,
    insight: "Rotation speed changes while orbit radius stays nearly constant."
  }
]);

export function getDemoSweepExamples() {
  return DEMO_SWEEPS.map((example) => ({ ...example }));
}

export function getExperimentModels() {
  return MODELS.map((model) => ({
    ...model,
    initial: { ...model.initial },
    equations: { ...model.equations }
  }));
}

export function getExperimentModel(id) {
  const model = MODELS.find((item) => item.id === id);
  return model ? {
    ...model,
    initial: { ...model.initial },
    equations: { ...model.equations }
  } : null;
}

export function runParameterSweep({
  modelId,
  min,
  max,
  samples = 5,
  initial,
  duration = 12
}) {
  const model = MODELS.find((item) => item.id === modelId);
  if (!model) throw new TypeError("Choose a supported experiment model.");

  const start = Number(min);
  const stop = Number(max);
  const count = Number(samples);
  const totalTime = Number(duration);
  const initialState = { x: Number(initial?.x), y: Number(initial?.y) };

  if (!Number.isFinite(start) || !Number.isFinite(stop) || start < 0 || stop < 0 || start >= stop) {
    throw new RangeError("Enter a valid parameter range with the minimum lower than the maximum.");
  }
  if (!Number.isInteger(count) || count < 3 || count > MAX_TRAJECTORIES) {
    throw new RangeError(`Choose between 3 and ${MAX_TRAJECTORIES} trajectories.`);
  }
  if (!Number.isFinite(totalTime) || totalTime < 1 || totalTime > MAX_DURATION) {
    throw new RangeError(`Experiment duration must be between 1 and ${MAX_DURATION} seconds.`);
  }
  if (![initialState.x, initialState.y].every((value) => Number.isFinite(value) && Math.abs(value) <= 10)) {
    throw new RangeError("Starting coordinates must be between −10 and 10.");
  }

  const series = Array.from({ length: count }, (_, index) => {
    const parameterValue = count === 1
      ? start
      : start + (stop - start) * index / (count - 1);
    const parameterLiteral = String(Number(parameterValue.toPrecision(8)));
    const xExpression = model.equations.x.replaceAll("{p}", parameterLiteral);
    const yExpression = model.equations.y.replaceAll("{p}", parameterLiteral);
    const x = ExpressionParser.compile(xExpression);
    const y = ExpressionParser.compile(yExpression);
    const system = (state) => ({
      x: x.evaluate(state),
      y: y.evaluate(state)
    });
    const trajectory = integrate(system, initialState, {
      duration: totalTime,
      stepSize: STEP_SIZE,
      maxSteps: Math.ceil(MAX_DURATION / STEP_SIZE)
    });

    if (trajectory.length < 2) {
      throw new Error(`The ${model.title.toLowerCase()} could not produce a trajectory.`);
    }

    let pathLength = 0;
    let maxRadius = 0;
    for (let pointIndex = 0; pointIndex < trajectory.length; pointIndex += 1) {
      const point = trajectory[pointIndex];
      maxRadius = Math.max(maxRadius, Math.hypot(point.x, point.y));
      if (pointIndex > 0) {
        const previous = trajectory[pointIndex - 1];
        pathLength += Math.hypot(point.x - previous.x, point.y - previous.y);
      }
    }

    const final = trajectory[trajectory.length - 1];
    const stride = Math.max(1, Math.ceil((trajectory.length - 1) / (CHART_POINT_LIMIT - 1)));
    const chartPoints = trajectory.filter((_, pointIndex) => pointIndex % stride === 0);
    if (chartPoints.at(-1) !== final) chartPoints.push(final);

    return {
      parameterValue,
      equations: { x: xExpression, y: yExpression },
      points: chartPoints.map(({ x: pointX, y: pointY }) => ({ x: pointX, y: pointY })),
      metrics: {
        finalX: final.x,
        finalY: final.y,
        finalRadius: Math.hypot(final.x, final.y),
        maxRadius,
        pathLength
      }
    };
  });

  return {
    modelId: model.id,
    modelTitle: model.title,
    parameter: model.parameter,
    min: start,
    max: stop,
    samples: count,
    duration: totalTime,
    initial: initialState,
    series
  };
}
