/**
 * Runtime validation for mission content before it is shown to players.
 */
const REQUIRED_TEXT = ["name", "division", "topic", "description", "objective", "hint", "lesson"];
const REQUIRED_NUMBERS = ["id", "duration", "tolerance", "speedLimit"];

export function validateMission(mission) {
  const errors = [];
  const warnings = [];
  if (!mission || typeof mission !== "object") return { valid: false, errors: ["Mission must be an object."], warnings };
  for (const key of REQUIRED_TEXT) {
    if (typeof mission[key] !== "string" || !mission[key].trim()) errors.push(`${key} must be a non-empty string.`);
  }
  for (const key of REQUIRED_NUMBERS) {
    if (!Number.isFinite(mission[key]) || mission[key] <= 0) errors.push(`${key} must be a positive number.`);
  }
  if (!Number.isInteger(mission.id)) errors.push("id must be an integer.");
  if (!mission.initial || !Number.isFinite(mission.initial.x) || !Number.isFinite(mission.initial.y)) errors.push("initial must contain finite x and y coordinates.");
  if (!mission.target || !Number.isFinite(mission.target.x) || !Number.isFinite(mission.target.y)) errors.push("target must contain finite x and y coordinates.");
  if (!mission.equations || typeof mission.equations.x !== "string" || typeof mission.equations.y !== "string") errors.push("equations must contain x and y expression strings.");
  if (mission.duration > 120) warnings.push("Mission duration is unusually long for a tutorial flight.");
  if (mission.tolerance > 10) warnings.push("Landing tolerance may be too generous.");
  if (mission.speedLimit > 20) warnings.push("Speed limit may be too high for the intended educational scale.");
  return { valid: errors.length === 0, errors, warnings };
}

export function validateMissionSet(missions) {
  const errors = [];
  const warnings = [];
  if (!Array.isArray(missions) || !missions.length) return { valid: false, errors: ["Mission set must be a non-empty array."], warnings };
  const ids = new Set();
  missions.forEach((mission, index) => {
    const result = validateMission(mission);
    result.errors.forEach((message) => errors.push(`Mission at index ${index}: ${message}`));
    result.warnings.forEach((message) => warnings.push(`Mission ${mission?.id ?? index}: ${message}`));
    if (ids.has(mission?.id)) errors.push(`Duplicate mission id ${mission.id}.`);
    ids.add(mission?.id);
  });
  return { valid: errors.length === 0, errors, warnings };
}

export function normalizeMission(mission) {
  const result = validateMission(mission);
  if (!result.valid) throw new TypeError(result.errors.join(" "));
  return {
    ...mission,
    id: Number(mission.id),
    duration: Number(mission.duration),
    tolerance: Number(mission.tolerance),
    speedLimit: Number(mission.speedLimit),
    initial: { x: Number(mission.initial.x), y: Number(mission.initial.y) },
    target: { x: Number(mission.target.x), y: Number(mission.target.y) },
    equations: { x: mission.equations.x.trim(), y: mission.equations.y.trim() },
    unlocked: Boolean(mission.unlocked)
  };
}

export function sortMissions(missions) {
  return [...missions].sort((a, b) => a.id - b.id);
}

export function groupMissionsByDivision(missions) {
  return missions.reduce((groups, mission) => {
    const key = mission.division || "Unassigned";
    groups[key] ??= [];
    groups[key].push(mission);
    return groups;
  }, {});
}

export function getMissionDependencies(missions) {
  const ordered = sortMissions(missions);
  return ordered.map((mission, index) => ({
    id: mission.id,
    requires: index === 0 ? [] : [ordered[index - 1].id]
  }));
}

export function verifyProgression(missions) {
  const dependencies = getMissionDependencies(missions);
  const issues = [];
  dependencies.forEach((item, index) => {
    if (item.requires.some((required) => !dependencies.some((candidate) => candidate.id === required))) {
      issues.push(`Mission ${item.id} references a missing prerequisite.`);
    }
    if (index === 0 && item.requires.length) issues.push("The first mission should not require a prerequisite.");
  });
  return { valid: issues.length === 0, issues, dependencies };
}
