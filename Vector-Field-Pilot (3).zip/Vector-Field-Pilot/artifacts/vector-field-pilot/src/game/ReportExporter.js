/**
 * Report formatting and download helpers for the research notebook.
 */
export function buildFlightReport(record, mission = {}) {
  return {
    title: `Flight report — ${record.missionName ?? mission.name ?? "Untitled mission"}`,
    generatedAt: new Date().toISOString(),
    mission: {
      id: record.missionId ?? mission.id ?? null,
      name: record.missionName ?? mission.name ?? "Untitled",
      topic: record.topic ?? mission.topic ?? "Unspecified",
      objective: mission.objective ?? ""
    },
    model: {
      equations: record.equations ?? {},
      initial: record.initial ?? mission.initial ?? {},
      final: record.final ?? {},
      solver: "RK4",
      nominalStepSize: .025
    },
    outcome: {
      success: Boolean(record.success),
      score: record.score ?? 0,
      elapsed: record.elapsed ?? 0,
      finalDistance: record.distance ?? null,
      pathLength: record.pathLength ?? null
    },
    learning: {
      lesson: mission.lesson ?? "",
      reflectionPrompt: "Which term had the greatest influence on the trajectory, and what evidence supports your conclusion?"
    }
  };
}

export function reportToMarkdown(report) {
  const lines = [
    `# ${report.title}`,
    "",
    `Generated: ${report.generatedAt}`,
    "",
    "## Mission",
    `- Name: ${report.mission.name}`,
    `- Topic: ${report.mission.topic}`,
    `- Objective: ${report.mission.objective || "Not specified"}`,
    "",
    "## Mathematical model",
    `- dx/dt = ${report.model.equations.x ?? "—"}`,
    `- dy/dt = ${report.model.equations.y ?? "—"}`,
    `- Initial state: (${report.model.initial.x ?? "—"}, ${report.model.initial.y ?? "—"})`,
    `- Final state: (${report.model.final.x ?? "—"}, ${report.model.final.y ?? "—"})`,
    `- Solver: ${report.model.solver}`,
    "",
    "## Outcome",
    `- Result: ${report.outcome.success ? "Successful landing" : "Not landed"}`,
    `- Score: ${report.outcome.score}/100`,
    `- Elapsed: ${Number(report.outcome.elapsed).toFixed(2)} seconds`,
    `- Final distance: ${report.outcome.finalDistance ?? "—"}`,
    `- Path length: ${report.outcome.pathLength ?? "—"}`,
    "",
    "## Learning connection",
    report.learning.lesson,
    "",
    `**Reflection:** ${report.learning.reflectionPrompt}`,
    ""
  ];
  return lines.join("\n");
}

export function downloadBlob(filename, content, mimeType = "text/plain") {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.rel = "noopener";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function exportJSON(filename, value) {
  downloadBlob(filename, JSON.stringify(value, null, 2), "application/json");
}

export function exportMarkdown(filename, value) {
  downloadBlob(filename, reportToMarkdown(value), "text/markdown");
}

export function sanitizeFilename(value) {
  return String(value).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 80) || "flight-report";
}
