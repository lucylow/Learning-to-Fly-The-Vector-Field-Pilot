/**
 * Searchable glossary for the differential-equations flight curriculum.
 */
export const GLOSSARY = Object.freeze([
  ["Acceleration", "The rate of change of velocity with respect to time."],
  ["Autonomous system", "A differential-equation system whose right-hand side does not explicitly depend on time."],
  ["Damping", "An effect that opposes motion and can reduce the amplitude of oscillation."],
  ["Derivative", "The instantaneous rate of change of a quantity."],
  ["Equilibrium", "A state where every derivative in the system is zero."],
  ["Eigenvalue", "A scalar associated with a linear transformation that helps describe its modes of behaviour."],
  ["First-order ODE", "An ordinary differential equation involving a first derivative as its highest derivative."],
  ["Jacobian", "A matrix of first partial derivatives describing the local linearization of a vector field."],
  ["Linear system", "A system whose state variables appear linearly in the equations."],
  ["Nonlinear system", "A system whose equations include nonlinear dependence on state variables."],
  ["Ordinary differential equation", "An equation relating an unknown function to one or more of its derivatives with respect to a single independent variable."],
  ["Phase plane", "A coordinate plane whose axes represent two state variables."],
  ["Runge–Kutta method", "A family of numerical methods that estimate solutions by evaluating derivatives at multiple points within each step."],
  ["Saddle point", "An equilibrium that attracts trajectories along some directions and repels them along others."],
  ["Stable equilibrium", "An equilibrium that nearby states tend to approach, for an asymptotically stable example."],
  ["State variable", "A quantity used to describe the current condition of a dynamical system."],
  ["Trajectory", "The path traced by a system's state as time evolves."],
  ["Unstable equilibrium", "An equilibrium from which nearby states can move away."],
  ["Vector field", "A function assigning a vector, such as a rate of change, to each point in a region."],
  ["Velocity", "The rate of change of position with respect to time."]
]);

export function lookupTerm(term) {
  const normalized = String(term).trim().toLowerCase();
  const match = GLOSSARY.find(([name]) => name.toLowerCase() === normalized);
  return match ? { term: match[0], definition: match[1] } : null;
}

export function searchGlossary(query) {
  const normalized = String(query).trim().toLowerCase();
  if (!normalized) return GLOSSARY.map(([term, definition]) => ({ term, definition }));
  return GLOSSARY
    .filter(([term, definition]) => `${term} ${definition}`.toLowerCase().includes(normalized))
    .map(([term, definition]) => ({ term, definition }));
}

export function glossaryLetterIndex() {
  return GLOSSARY.reduce((index, [term]) => {
    const letter = term[0].toUpperCase();
    index[letter] ??= [];
    index[letter].push(term);
    return index;
  }, {});
}

export function glossaryQuiz(term) {
  const answer = lookupTerm(term);
  if (!answer) return null;
  const distractors = GLOSSARY.filter(([name]) => name !== answer.term).slice(0, 3).map(([name]) => name);
  return {
    prompt: `Which definition best describes ${answer.term}?`,
    answer: answer.definition,
    distractors
  };
}
