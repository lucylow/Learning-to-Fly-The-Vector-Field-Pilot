/**
 * Short lesson cards for the in-game learning library.
 * Lessons connect visible flight behaviour to mathematical notation.
 */
export const LESSONS = Object.freeze([
  {
    id: "rate-of-change",
    title: "A derivative is a rate",
    level: "beginner",
    notation: "x′ = 1",
    plain: "The horizontal position increases by one unit during each unit of time.",
    detail: "A differential equation specifies how a state variable changes. The value of the derivative is the instantaneous rate at the current state.",
    experiment: "Start with x = 0 and compare x′ = 1 with x′ = 2. Observe the difference in slope.",
    questions: ["What does x′ measure?", "What happens if the constant doubles?"]
  },
  {
    id: "constant-vector",
    title: "Constant vector fields",
    level: "beginner",
    notation: "x′ = a, y′ = b",
    plain: "The same motion vector is applied at every point.",
    detail: "When both rates are constant, the trajectory is a straight line in the state plane.",
    experiment: "Try x′ = 1 and y′ = 0. Then change y′ to 0.3.",
    questions: ["Which term changes the slope?", "Why is the trajectory straight?"]
  },
  {
    id: "stable-equilibrium",
    title: "Stable equilibrium",
    level: "beginner",
    notation: "x′ = −x",
    plain: "The state moves toward zero from either side.",
    detail: "At x = 0 the derivative is zero. For nearby nonzero states, the derivative points back toward the equilibrium.",
    experiment: "Start at x = 4, then start at x = −4. Compare both trajectories.",
    questions: ["Where is the equilibrium?", "How does the sign of x′ change?"]
  },
  {
    id: "unstable-equilibrium",
    title: "Unstable equilibrium",
    level: "intermediate",
    notation: "x′ = x",
    plain: "A small displacement grows rather than shrinks.",
    detail: "The origin is still an equilibrium, but nearby trajectories move away from it for nonzero initial conditions.",
    experiment: "Change x′ from −x to x and compare the direction of motion.",
    questions: ["What changes when the coefficient changes sign?", "Why is the origin unstable?"]
  },
  {
    id: "coupled-systems",
    title: "Coupled systems",
    level: "intermediate",
    notation: "x′ = y, y′ = −x",
    plain: "Each variable helps determine the rate of the other.",
    detail: "A system of first-order equations evolves together. The two equations cannot be interpreted independently.",
    experiment: "Change the coefficient of y in the first equation and inspect the orbit.",
    questions: ["Which variable controls x′?", "What shape does the ideal system produce?"]
  },
  {
    id: "second-order",
    title: "Second-order equations",
    level: "intermediate",
    notation: "q′ = v, v′ = −kq − cv",
    plain: "Track displacement and velocity as two state variables.",
    detail: "A second-order equation can be converted into a pair of first-order equations by defining a new state variable for the first derivative.",
    experiment: "Use x′ = y and y′ = −2x − 0.7y.",
    questions: ["What does y represent in this model?", "Which term provides damping?"]
  },
  {
    id: "damping",
    title: "Damping",
    level: "intermediate",
    notation: "v′ = −kq − cv",
    plain: "Damping reduces the size of repeated oscillations.",
    detail: "The velocity-proportional term opposes motion. In this simplified model, positive damping removes energy from the oscillator.",
    experiment: "Compare c = 0.1, c = 0.7 and c = 2.",
    questions: ["How does damping change amplitude?", "What happens when damping is very large?"]
  },
  {
    id: "time-dependent",
    title: "Time-dependent forcing",
    level: "advanced",
    notation: "y′ = f(x,y,t)",
    plain: "The rate can change because time itself changes.",
    detail: "A non-autonomous system has explicit time dependence. A periodic term can represent a repeating external disturbance.",
    experiment: "Add 0.5*sin(t) to the vertical rate.",
    questions: ["Why does the field vary with time?", "What is the period of sin(t)?"]
  },
  {
    id: "nonlinear",
    title: "Nonlinear systems",
    level: "advanced",
    notation: "x′ = x(1 − x)",
    plain: "The rate can change nonlinearly with the state.",
    detail: "Nonlinear terms can create multiple equilibria, limit cycles and more complicated trajectories.",
    experiment: "Plot x′ = x(1 − x) for positive and negative starting values.",
    questions: ["Where does the rate equal zero?", "How does the sign of the rate vary?"]
  },
  {
    id: "feedback",
    title: "Feedback control",
    level: "advanced",
    notation: "u = Kp(target − state)",
    plain: "A controller uses the error to create a corrective input.",
    detail: "Closed-loop control measures the current state, compares it with a target and adjusts the input. The gain determines how strongly the controller responds.",
    experiment: "Compare small and large proportional gains in a stable plant.",
    questions: ["What is the error signal?", "Why can a large gain cause overshoot?"]
  }
]);

export function getLesson(id) {
  return LESSONS.find((lesson) => lesson.id === id) ?? null;
}

export function searchLessons(query) {
  const normalized = String(query).trim().toLowerCase();
  if (!normalized) return [...LESSONS];
  return LESSONS.filter((lesson) =>
    [lesson.title, lesson.notation, lesson.plain, lesson.detail, lesson.level]
      .some((value) => value.toLowerCase().includes(normalized))
  );
}

export function lessonsByLevel() {
  return LESSONS.reduce((groups, lesson) => {
    groups[lesson.level] ??= [];
    groups[lesson.level].push(lesson);
    return groups;
  }, {});
}

export function lessonChecklist(progress = {}) {
  return LESSONS.map((lesson) => ({
    id: lesson.id,
    title: lesson.title,
    completed: Boolean(progress[lesson.id]),
    level: lesson.level
  }));
}
