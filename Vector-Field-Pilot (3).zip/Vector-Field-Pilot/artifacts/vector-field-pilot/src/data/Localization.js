/**
 * Small localization dictionary. English is the source language.
 * Missing keys fall back to English so incomplete translations remain usable.
 */
export const MESSAGES = Object.freeze({
  en: {
    "nav.flight": "Flight deck",
    "nav.missions": "Missions",
    "nav.notebook": "Research log",
    "nav.hangar": "Hangar",
    "flight.title": "Flight deck",
    "flight.subtitle": "Shape the equations. Read the field. Bring it home.",
    "equation.title": "Equation control",
    "equation.apply": "Apply model",
    "simulation.start": "Start flight",
    "simulation.pause": "Pause",
    "simulation.restart": "Restart",
    "mission.locked": "Complete previous flight",
    "mission.launch": "Launch mission",
    "mission.completed": "Completed",
    "result.success": "Landing complete",
    "result.practice": "Flight review",
    "common.close": "Close",
    "common.cancel": "Cancel",
    "common.save": "Save",
    "common.export": "Export"
  },
  fr: {
    "nav.flight": "Poste de pilotage",
    "nav.missions": "Missions",
    "nav.notebook": "Journal de recherche",
    "nav.hangar": "Hangar",
    "flight.title": "Poste de pilotage",
    "flight.subtitle": "Modifiez les équations. Lisez le champ. Revenez à la base.",
    "equation.title": "Contrôle des équations",
    "equation.apply": "Appliquer le modèle",
    "simulation.start": "Démarrer le vol",
    "simulation.pause": "Pause",
    "simulation.restart": "Redémarrer",
    "mission.locked": "Terminez le vol précédent",
    "mission.launch": "Lancer la mission",
    "mission.completed": "Terminée",
    "result.success": "Atterrissage réussi",
    "result.practice": "Analyse du vol",
    "common.close": "Fermer",
    "common.cancel": "Annuler",
    "common.save": "Enregistrer",
    "common.export": "Exporter"
  }
});

export class Translator extends EventTarget {
  constructor(language = "en", dictionaries = MESSAGES) {
    super();
    this.dictionaries = dictionaries;
    this.language = dictionaries[language] ? language : "en";
  }

  setLanguage(language) {
    if (!this.dictionaries[language]) throw new TypeError(`Unsupported language: ${language}`);
    this.language = language;
    this.dispatchEvent(new CustomEvent("change", { detail: language }));
  }

  t(key, variables = {}) {
    const dictionary = this.dictionaries[this.language] ?? {};
    const fallback = this.dictionaries.en ?? {};
    let value = dictionary[key] ?? fallback[key] ?? key;
    for (const [name, replacement] of Object.entries(variables)) {
      value = value.replaceAll(`{${name}}`, String(replacement));
    }
    return value;
  }

  languageList() {
    return Object.keys(this.dictionaries).map((code) => ({
      code,
      label: code === "en" ? "English" : code === "fr" ? "Français" : code
    }));
  }

  translateElement(element) {
    if (!element) return;
    const key = element.dataset.i18n;
    if (key) element.textContent = this.t(key);
    const placeholder = element.dataset.i18nPlaceholder;
    if (placeholder) element.setAttribute("placeholder", this.t(placeholder));
    const title = element.dataset.i18nTitle;
    if (title) element.setAttribute("title", this.t(title));
  }

  translateTree(root = document) {
    root.querySelectorAll("[data-i18n],[data-i18n-placeholder],[data-i18n-title]").forEach((element) => this.translateElement(element));
  }
}

export function formatLocalizedNumber(value, language = "en", options = {}) {
  return new Intl.NumberFormat(language, options).format(value);
}

export function formatLocalizedDate(value, language = "en", options = {}) {
  return new Intl.DateTimeFormat(language, options).format(new Date(value));
}
