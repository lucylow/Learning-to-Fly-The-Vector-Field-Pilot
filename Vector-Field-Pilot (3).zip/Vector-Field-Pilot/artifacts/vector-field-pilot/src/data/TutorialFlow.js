/**
 * Guided tutorial state machine. Each step can specify a condition that the UI
 * checks before allowing the learner to proceed.
 */
export const TUTORIAL_STEPS = Object.freeze([
  { id: "welcome", title: "Welcome to flight school", body: "You will control a mathematical aircraft by changing the equations that describe its motion.", action: "Continue", requirement: null },
  { id: "inspect", title: "Inspect the field", body: "The arrows show the instantaneous direction of change at each point in the map.", action: "I see the field", requirement: "field-inspected" },
  { id: "equation-x", title: "Read the horizontal equation", body: "dx/dt describes how the horizontal state changes over time.", action: "Next", requirement: null },
  { id: "equation-y", title: "Read the vertical equation", body: "dy/dt describes how the vertical state changes over time.", action: "Next", requirement: null },
  { id: "apply", title: "Apply the model", body: "Apply the two equations to validate them and redraw the field.", action: "Model applied", requirement: "model-applied" },
  { id: "predict", title: "Make a prediction", body: "Before flying, predict whether the aircraft will move horizontally, vertically, or diagonally.", action: "Prediction made", requirement: "prediction-made" },
  { id: "fly", title: "Run the simulation", body: "Start the simulation and observe how the trajectory follows the vector field.", action: "Flight observed", requirement: "flight-started" },
  { id: "review", title: "Review the result", body: "Compare the final state with the target and explain how the equations shaped the path.", action: "Finish tutorial", requirement: "flight-reviewed" }
]);

export class TutorialFlow extends EventTarget {
  constructor(steps = TUTORIAL_STEPS) {
    super();
    this.steps = steps.map((step) => ({ ...step }));
    this.index = 0;
    this.completed = false;
    this.signals = new Set();
    this.skipped = false;
  }

  current() {
    return this.completed ? null : { ...this.steps[this.index], index: this.index, total: this.steps.length };
  }

  signal(name) {
    this.signals.add(name);
    this.dispatchEvent(new CustomEvent("signal", { detail: name }));
  }

  canAdvance() {
    const requirement = this.steps[this.index]?.requirement;
    return !requirement || this.signals.has(requirement);
  }

  next() {
    if (this.completed) return null;
    if (!this.canAdvance()) {
      this.dispatchEvent(new CustomEvent("blocked", { detail: this.steps[this.index].requirement }));
      return this.current();
    }
    if (this.index >= this.steps.length - 1) {
      this.completed = true;
      this.dispatchEvent(new Event("complete"));
      return null;
    }
    this.index += 1;
    const step = this.current();
    this.dispatchEvent(new CustomEvent("step", { detail: step }));
    return step;
  }

  previous() {
    if (this.completed) this.completed = false;
    this.index = Math.max(0, this.index - 1);
    const step = this.current();
    this.dispatchEvent(new CustomEvent("step", { detail: step }));
    return step;
  }

  skip() {
    this.skipped = true;
    this.completed = true;
    this.dispatchEvent(new CustomEvent("skip"));
  }

  reset() {
    this.index = 0;
    this.completed = false;
    this.skipped = false;
    this.signals.clear();
    this.dispatchEvent(new CustomEvent("step", { detail: this.current() }));
  }

  progress() {
    return this.completed ? 100 : Math.round(this.index / Math.max(1, this.steps.length - 1) * 100);
  }

  snapshot() {
    return {
      index: this.index,
      completed: this.completed,
      skipped: this.skipped,
      signals: [...this.signals]
    };
  }

  restore(snapshot) {
    this.index = Math.max(0, Math.min(this.steps.length - 1, Number(snapshot.index) || 0));
    this.completed = Boolean(snapshot.completed);
    this.skipped = Boolean(snapshot.skipped);
    this.signals = new Set(snapshot.signals ?? []);
    return this.current();
  }
}
