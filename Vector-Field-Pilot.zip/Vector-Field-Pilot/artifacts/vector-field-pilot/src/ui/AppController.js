import { ExpressionParser, validateExpression } from "../math/ExpressionParser.js";
import { VectorField } from "../math/VectorField.js";
import { numericalJacobian, classifyLinearSystem } from "../math/ODESolver.js";
import { FlightSimulator } from "../game/FlightSimulator.js";
import { MissionManager } from "../game/MissionManager.js";
import { ProgressStore } from "../game/ProgressStore.js";
import { getDemoSweepExamples, getExperimentModel, getExperimentModels, runParameterSweep } from "../game/ExperimentLab.js";
import { FlightCanvas } from "./FlightCanvas.js";

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const format = (value, digits = 2) => Number.isFinite(value) ? value.toFixed(digits) : "—";
const safeText = (value) => String(value ?? "");

export class AppController {
  constructor() {
    this.store = new ProgressStore();
    this.missions = new MissionManager(this.store);
    this.canvas = new FlightCanvas($("#flight-canvas"));
    this.simulator = null;
    this.compiled = null;
    this.lastFrame = 0;
    this.animationId = null;
    this.toastTimer = null;
    this.bindNavigation();
    this.bindControls();
    this.bindStore();
    this.renderMission(this.missions.getCurrent());
    this.renderMissions();
    this.renderNotebook();
    this.initializeExperimentLab();
    this.restorePreferences();
    this.applyEquations(false);
    this.setupLivery();
    this.loop = this.loop.bind(this);
    this.animationId = requestAnimationFrame(this.loop);
  }

  bindNavigation() {
    $$(".nav-link").forEach((button) => button.addEventListener("click", () => this.showView(button.dataset.view)));
    $("#open-missions").addEventListener("click", () => this.showView("missions"));
    $("#help-button").addEventListener("click", () => $("#help-dialog").showModal());
    $("#close-help").addEventListener("click", () => $("#help-dialog").close());
    $("#got-it").addEventListener("click", () => $("#help-dialog").close());
  }

  showView(name) {
    $$(".view").forEach((view) => view.classList.toggle("active", view.id === `${name}-view`));
    $$(".nav-link").forEach((button) => button.classList.toggle("active", button.dataset.view === name));
    if (name === "missions") this.renderMissions();
    if (name === "notebook") this.renderNotebook();
    if (name === "experiments") this.renderSavedSweeps();
    if (name === "flight") this.canvas.render();
  }

  bindControls() {
    $("#apply-equations").addEventListener("click", () => this.applyEquations(true));
    $("#reset-equations").addEventListener("click", () => {
      const mission = this.missions.getCurrent();
      $("#equation-x").value = mission.equations.x;
      $("#equation-y").value = mission.equations.y;
      this.applyEquations(true);
    });
    $("#start-button").addEventListener("click", () => this.startFlight());
    $("#pause-button").addEventListener("click", () => this.pauseFlight());
    $("#restart-button").addEventListener("click", () => this.restartFlight());
    $("#speed-control").addEventListener("input", (event) => {
      const value = Number(event.target.value);
      $("#time-scale-label").textContent = `${value.toFixed(2)}×`;
      this.simulator?.setSpeed(value);
      this.store.setPreference("timeScale", value);
    });
    $$("[data-field-mode]").forEach((button) => button.addEventListener("click", () => {
      $$("[data-field-mode]").forEach((item) => item.classList.toggle("active", item === button));
      this.canvas.setFieldMode(button.dataset.fieldMode);
      this.store.setPreference("fieldMode", button.dataset.fieldMode);
    }));
    $$("[data-term]").forEach((button) => button.addEventListener("click", () => {
      const input = document.activeElement?.id === "equation-y" ? $("#equation-y") : $("#equation-x");
      const current = input.value.trim();
      input.value = current ? `${current}+(${button.dataset.term})` : button.dataset.term;
      input.focus();
    }));
    $("#hint-button").addEventListener("click", () => $("#hint-text").classList.toggle("hidden"));
    $("#save-note").addEventListener("click", () => {
      const saved = this.store.addNote($("#research-note").value);
      if (saved) {
        $("#research-note").value = "";
        this.renderNotebook();
        this.toast("Observation saved to your research log.");
      }
    });
    $("#export-notebook").addEventListener("click", () => this.exportNotebook());
    $("#livery-list")?.addEventListener("click", (event) => this.handleLiveryClick(event));
    $$(".livery-option").forEach((button) => button.addEventListener("click", () => this.selectLivery(button.dataset.livery)));
    $("#experiment-model")?.addEventListener("change", () => this.updateExperimentModel());
    $("#run-parameter-sweep")?.addEventListener("click", () => this.runExperimentSweep());
  }

  initializeExperimentLab() {
    const select = $("#experiment-model");
    if (!select) return;
    const models = getExperimentModels();
    select.innerHTML = models.map((model) =>
      `<option value="${this.escapeHTML(model.id)}">${this.escapeHTML(model.title)}</option>`
    ).join("");
    this.updateExperimentModel();
    if (!this.store.getSweeps().length) {
      this.renderDemoSweepPreview();
    } else {
      $("#sweep-mode-tag").textContent = "READY TO PLOT / X–Y";
      $("#sweep-summary").textContent = "Your saved run summaries are below. Run a sweep to plot a new trajectory comparison.";
    }
    this.renderSavedSweeps();
  }

  renderDemoSweepPreview() {
    const example = getDemoSweepExamples()[0];
    const result = runParameterSweep({
      modelId: example.modelId,
      min: example.min,
      max: example.max,
      samples: example.samples,
      duration: example.duration,
      initial: { x: 2, y: 0 }
    });
    this.renderExperimentSweep(result, { demo: true });
    $("#sweep-summary").textContent =
      `DEMO PREVIEW · ${example.insight} Adjust the controls and run a sweep to create your own saved result.`;
    const feedback = $("#sweep-feedback");
    feedback.textContent = "Showing sample data only. Demo runs are not added to your saved progress.";
  }

  updateExperimentModel() {
    const select = $("#experiment-model");
    if (!select) return;
    const model = getExperimentModel(select.value) ?? getExperimentModels()[0];
    if (!model) return;
    select.value = model.id;
    $("#experiment-min").value = String(model.min);
    $("#experiment-max").value = String(model.max);
    $("#experiment-initial-x").value = String(model.initial.x);
    $("#experiment-initial-y").value = String(model.initial.y);
    $("#experiment-model-description").textContent = model.description;
    const parameterName = model.parameter.toUpperCase();
    const minLabel = $("#experiment-parameter-label-min");
    const maxLabel = $("#experiment-parameter-label-max");
    if (minLabel) minLabel.textContent = parameterName;
    if (maxLabel) maxLabel.textContent = parameterName;
  }

  runExperimentSweep() {
    const feedback = $("#sweep-feedback");
    if (!feedback) return;
    feedback.className = "sweep-feedback";
    try {
      const result = runParameterSweep({
        modelId: $("#experiment-model").value,
        min: $("#experiment-min").value,
        max: $("#experiment-max").value,
        samples: $("#experiment-samples").value,
        duration: $("#experiment-duration").value,
        initial: {
          x: $("#experiment-initial-x").value,
          y: $("#experiment-initial-y").value
        }
      });
      const saved = this.store.addSweep({
        modelTitle: result.modelTitle,
        parameter: result.parameter,
        min: result.min,
        max: result.max,
        samples: result.samples,
        duration: result.duration,
        initial: result.initial,
        results: result.series.map(({ parameterValue, metrics }) => ({ parameterValue, metrics }))
      });
      this.renderExperimentSweep(result);
      this.renderSavedSweeps();
      const closest = [...result.series].sort((a, b) => a.metrics.finalRadius - b.metrics.finalRadius)[0];
      $("#sweep-summary").textContent =
        `${result.series.length} trajectories ran for ${format(result.duration, 1)} seconds each. ` +
        `The ${result.parameter.toLowerCase()} ${format(closest.parameterValue, 2)} case ended ` +
        `${format(closest.metrics.finalRadius, 2)} units from equilibrium.`;
      feedback.className = "sweep-feedback success";
      feedback.textContent = saved
        ? "Sweep complete. Your result is saved in this browser."
        : "Sweep complete. Browser storage is full, so this run was not saved.";
    } catch (error) {
      feedback.className = "sweep-feedback error";
      feedback.textContent = `Sweep not run: ${error.message}`;
    }
  }

  renderExperimentSweep(result, { demo = false } = {}) {
    const chart = $("#sweep-chart");
    const legend = $("#sweep-legend");
    if (!chart) return;

    const allPoints = result.series.flatMap((series) => series.points);
    const minX = Math.min(...allPoints.map((point) => point.x));
    const maxX = Math.max(...allPoints.map((point) => point.x));
    const minY = Math.min(...allPoints.map((point) => point.y));
    const maxY = Math.max(...allPoints.map((point) => point.y));
    const spanX = Math.max(maxX - minX, 1e-6);
    const spanY = Math.max(maxY - minY, 1e-6);
    const padX = spanX * .12;
    const padY = spanY * .12;
    const bounds = {
      left: minX - padX,
      right: maxX + padX,
      bottom: minY - padY,
      top: maxY + padY
    };
    const width = 720;
    const height = 370;
    const margin = { left: 58, right: 20, top: 20, bottom: 48 };
    const plotWidth = width - margin.left - margin.right;
    const plotHeight = height - margin.top - margin.bottom;
    const scaleX = (value) => margin.left + (value - bounds.left) / (bounds.right - bounds.left) * plotWidth;
    const scaleY = (value) => margin.top + (bounds.top - value) / (bounds.top - bounds.bottom) * plotHeight;
    const colors = ["#53d9e8", "#f2b766", "#b39aff", "#6cdbad", "#f17e82", "#74a9ff", "#f28bd5", "#c1db71", "#f2a66a"];
    const grid = Array.from({ length: 5 }, (_, index) => {
      const ratio = index / 4;
      const y = margin.top + ratio * plotHeight;
      const xValue = bounds.left + ratio * (bounds.right - bounds.left);
      const yValue = bounds.top - ratio * (bounds.top - bounds.bottom);
      return `
        <line x1="${margin.left}" y1="${y}" x2="${width - margin.right}" y2="${y}" class="sweep-gridline"/>
        <text x="${margin.left - 9}" y="${y + 3}" text-anchor="end" class="sweep-axis-label">${format(yValue, 1)}</text>
        <text x="${margin.left + ratio * plotWidth}" y="${height - 22}" text-anchor="middle" class="sweep-axis-label">${format(xValue, 1)}</text>`;
    }).join("");
    const paths = result.series.map((series, index) => {
      const points = series.points.map((point) => `${scaleX(point.x).toFixed(2)},${scaleY(point.y).toFixed(2)}`).join(" ");
      const color = colors[index % colors.length];
      return `<polyline points="${points}" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>`;
    }).join("");
    chart.setAttribute("viewBox", `0 0 ${width} ${height}`);
    chart.setAttribute("aria-label", `Overlaid trajectories for ${result.series.length} ${this.escapeHTML(result.modelTitle)} parameter values`);
    const modeTag = $("#sweep-mode-tag");
    if (modeTag) modeTag.textContent = demo ? "DEMO PREVIEW / X–Y" : "LIVE SWEEP / X–Y";
    chart.innerHTML = `
        <title>Parameter sweep: ${this.escapeHTML(result.modelTitle)}</title>
        <desc>Horizontal position is shown on the x-axis and vertical position on the y-axis. Each line is one parameter value.</desc>
        ${grid}
        <line x1="${margin.left}" y1="${margin.top}" x2="${margin.left}" y2="${height - margin.bottom}" class="sweep-axis"/>
        <line x1="${margin.left}" y1="${height - margin.bottom}" x2="${width - margin.right}" y2="${height - margin.bottom}" class="sweep-axis"/>
        ${paths}
        <text x="${width / 2}" y="${height - 4}" text-anchor="middle" class="sweep-axis-title">POSITION X</text>
        <text x="15" y="${height / 2}" text-anchor="middle" class="sweep-axis-title" transform="rotate(-90 15 ${height / 2})">POSITION Y</text>
      `;
    chart.parentElement.querySelector(".chart-empty")?.classList.add("hidden");
    if (legend) {
      legend.innerHTML = result.series.map((series, index) => `
        <span class="sweep-legend-item">
          <i style="--series-color:${colors[index % colors.length]}"></i>
          ${this.escapeHTML(result.parameter)} ${format(series.parameterValue, 2)}
        </span>`).join("");
    }
  }

  renderSavedSweeps() {
    const list = $("#saved-sweeps");
    if (!list) return;
    const sweeps = this.store.getSweeps();
    const savedRuns = sweeps.map((sweep) => `
      <article class="saved-sweep-item">
        <div>
          <h3>${this.escapeHTML(sweep.modelTitle)}</h3>
          <p>${this.escapeHTML(sweep.parameter)} ${format(sweep.min, 2)}–${format(sweep.max, 2)} · ${Number(sweep.samples) || 0} trajectories · ${format(sweep.duration, 1)}s</p>
        </div>
        <time>${this.escapeHTML(new Date(sweep.createdAt).toLocaleString())}</time>
      </article>`).join("");
    const demoRuns = getDemoSweepExamples().map((example) => `
      <article class="saved-sweep-item demo-sweep-item">
        <div>
          <h3>${this.escapeHTML(example.modelTitle)}</h3>
          <p>${this.escapeHTML(example.parameter)} ${format(example.min, 2)}–${format(example.max, 2)} · ${example.samples} example trajectories · ${example.duration}s</p>
          <small>${this.escapeHTML(example.insight)}</small>
        </div>
        <span class="demo-badge">DEMO</span>
      </article>`).join("");
    list.innerHTML = `
      ${savedRuns || '<div class="saved-sweeps-empty"><div><strong>No personal sweeps yet</strong><p>Run an experiment to add your own results. The examples below are not saved.</p></div></div>'}
      <div class="demo-section-heading"><span>GUIDED EXAMPLES</span><span>NOT SAVED</span></div>
      ${demoRuns}`;
  }

  bindStore() {
    this.store.addEventListener("change", () => {
      this.updateProgress();
      this.renderNotebook();
    });
    this.missions.addEventListener("selected", (event) => {
      this.renderMission(event.detail);
      this.showView("flight");
    });
    this.missions.addEventListener("result", (event) => {
      this.renderMissions();
      this.renderNotebook();
      this.toast(event.detail.success ? `Landing recorded · ${event.detail.score} points` : "Flight recorded. Review the trajectory and try again.");
    });
  }

  restorePreferences() {
    const preferences = this.store.getState().preferences;
    $("#speed-control").value = preferences.timeScale;
    $("#time-scale-label").textContent = `${Number(preferences.timeScale).toFixed(2)}×`;
    this.canvas.setFieldMode(preferences.fieldMode);
    $$("[data-field-mode]").forEach((button) => button.classList.toggle("active", button.dataset.fieldMode === preferences.fieldMode));
  }

  compileSystem(xExpression, yExpression) {
    const x = ExpressionParser.compile(xExpression);
    const y = ExpressionParser.compile(yExpression);
    return (state) => ({
      x: x.evaluate(state),
      y: y.evaluate(state)
    });
  }

  applyEquations(showFeedback = true) {
    const xText = $("#equation-x").value.trim();
    const yText = $("#equation-y").value.trim();
    const xCheck = validateExpression(xText);
    const yCheck = validateExpression(yText);
    const feedback = $("#equation-feedback");
    if (!xCheck.valid || !yCheck.valid) {
      feedback.className = "equation-feedback error";
      feedback.textContent = `Model not applied: ${!xCheck.valid ? `dx/dt: ${xCheck.message}` : `dy/dt: ${yCheck.message}`}`;
      return false;
    }
    try {
      const system = this.compileSystem(xText, yText);
      const sample = system({ x: .4, y: -.2, t: 0 });
      if (![sample.x, sample.y].every(Number.isFinite)) throw new Error("The model returned an invalid rate.");
      this.compiled = { x: xText, y: yText, system };
      if (this.simulator) this.simulator.pause();
      this.createSimulator(system);
      this.canvas.setSystem(system);
      this.canvas.setTarget(this.missions.getCurrent().target);
      this.canvas.setState(this.simulator.snapshot());
      feedback.className = "equation-feedback success";
      feedback.textContent = showFeedback ? "Model validated. Vector field and simulator updated." : "Model ready. Apply equations to update the field.";
      this.updateDiagnostics();
      return true;
    } catch (error) {
      feedback.className = "equation-feedback error";
      feedback.textContent = `Model not applied: ${error.message}`;
      return false;
    }
  }

  createSimulator(system) {
    const mission = this.missions.getCurrent();
    this.simulator = new FlightSimulator({
      system,
      initial: mission.initial,
      target: mission.target,
      duration: mission.duration,
      stepSize: .025
    });
    this.simulator.setSpeed(Number($("#speed-control").value));
    this.simulator.addEventListener("status", (event) => {
      const running = event.detail === "running";
      $("#start-button").disabled = running;
      $("#pause-button").disabled = !running;
      $("#map-state").textContent = running ? "FLIGHT IN PROGRESS" : "SIMULATION PAUSED";
    });
    this.simulator.addEventListener("frame", (event) => this.updateFrame(event.detail));
    this.simulator.addEventListener("reset", (event) => this.updateFrame(event.detail));
    this.simulator.addEventListener("error", (event) => this.toast(event.detail.message));
    this.simulator.addEventListener("complete", (event) => this.handleCompletion(event.detail));
  }

  startFlight() {
    if (!this.compiled && !this.applyEquations(false)) return;
    this.simulator.start();
    $("#map-state").textContent = "FLIGHT IN PROGRESS";
  }

  pauseFlight() { this.simulator?.pause(); }
  restartFlight() {
    this.simulator?.reset();
    $("#start-button").disabled = false;
    $("#pause-button").disabled = true;
    $("#map-state").textContent = "READY FOR FLIGHT";
    this.updateDiagnostics();
  }

  loop(timestamp) {
    if (this.lastFrame) {
      const delta = Math.min(.1, (timestamp - this.lastFrame) / 1000);
      if (this.simulator?.running) this.simulator.tick(delta);
    }
    this.lastFrame = timestamp;
    this.animationId = requestAnimationFrame(this.loop);
  }

  updateFrame(snapshot) {
    this.canvas.setState(snapshot);
    $("#state-x").textContent = format(snapshot.state.x);
    $("#state-y").textContent = format(snapshot.state.y);
    $("#rate-x").textContent = format(snapshot.rates.x);
    $("#rate-y").textContent = format(snapshot.rates.y);
    $("#map-coordinates").textContent = `X ${format(snapshot.state.x)} / Y ${format(snapshot.state.y)}`;
    $("#altitude-value").innerHTML = `${Math.round(1200 + snapshot.state.y * 85).toLocaleString()} <small>m</small>`;
    $("#speed-value").innerHTML = `${format(snapshot.speed)} <small>u/s</small>`;
    $("#time-value").textContent = this.formatTime(snapshot.elapsed);
    $("#error-value").innerHTML = `${format(snapshot.distance)} <small>u</small>`;
    this.updateDiagnostics(snapshot);
  }

  updateDiagnostics(snapshot = this.simulator?.snapshot()) {
    if (!snapshot || !this.compiled) return;
    const state = snapshot.state;
    const rates = snapshot.rates;
    let note = "The system is ready for inspection.";
    const magnitude = Math.hypot(rates.x, rates.y);
    if (magnitude < .05) note = "The current state is close to an equilibrium: both rates of change are small.";
    else if (rates.x * state.x + rates.y * state.y > 0) note = "The local flow has an outward component relative to the origin. Watch for growth or instability.";
    else note = "The local flow has an inward component relative to the origin. The system may be moving toward an equilibrium.";
    try {
      const jacobian = numericalJacobian(this.compiled.system, state);
      const classification = classifyLinearSystem(jacobian);
      note += ` Local linearization: ${classification.type.toLowerCase()}.`;
    } catch { /* Non-smooth or invalid local model; basic observation remains. */ }
    $("#diagnostic-note").textContent = note;
  }

  handleCompletion(result) {
    const mission = this.missions.getCurrent();
    const record = this.missions.recordResult({ ...result, equations: { ...this.compiled } });
    $("#start-button").disabled = false;
    $("#pause-button").disabled = true;
    $("#map-state").textContent = result.success ? "LANDING COMPLETE" : "FLIGHT ENDED";
    if (result.success) {
      $("#diagnostic-note").textContent = `Successful landing. You demonstrated ${mission.topic.toLowerCase()}. Final score: ${record.score}/100.`;
    } else {
      $("#diagnostic-note").textContent = `Flight ended ${result.reason === "time-limit" ? "at the time limit" : "outside the landing envelope"}. Final distance: ${format(result.metrics.distance)} units. Inspect the trajectory and adjust your model.`;
    }
  }

  renderMission(mission) {
    $("#active-mission-name").textContent = mission.name;
    $("#brief-title").textContent = mission.name;
    $("#brief-description").textContent = mission.description;
    $("#objective-text").textContent = mission.objective;
    $("#hint-text").textContent = mission.hint;
    $("#hint-text").classList.add("hidden");
    $("#equation-x").value = mission.equations.x;
    $("#equation-y").value = mission.equations.y;
    $("#map-state").textContent = "READY FOR FLIGHT";
    this.applyEquations(false);
  }

  renderMissions() {
    const grid = $("#mission-grid");
    const missions = this.missions.getAll();
    const completed = this.store.getCompletedMissionIds();
    grid.innerHTML = missions.map((mission) => {
      const done = completed.includes(mission.id);
      const locked = !mission.unlocked;
      return `<article class="mission-card ${done ? "completed" : ""} ${locked ? "locked" : ""}">
        <div class="mission-card-top"><span class="mission-number">FLIGHT ${String(mission.id).padStart(2,"0")}</span><span class="mission-status">${done ? "✓ COMPLETED" : locked ? "LOCKED" : mission.difficulty}</span></div>
        <h3>${this.escapeHTML(mission.name)}</h3><p>${this.escapeHTML(mission.description)}</p>
        <div class="mission-meta"><span>${this.escapeHTML(mission.topic.toUpperCase())}</span><span>${this.escapeHTML(mission.division.toUpperCase())}</span></div>
        <button class="button ${locked ? "button-quiet" : "button-primary"}" data-launch-mission="${mission.id}" ${locked ? "disabled" : ""}>${done ? "Fly again ↗" : locked ? "Complete previous flight" : "Launch mission ↗"}</button>
      </article>`;
    }).join("");
    $$("[data-launch-mission]").forEach((button) => button.addEventListener("click", () => {
      try { this.missions.select(Number(button.dataset.launchMission)); }
      catch (error) { this.toast(error.message); }
    }));
    this.updateProgress();
  }

  updateProgress() {
    const progress = this.missions.getProgress();
    $("#career-progress").textContent = `${progress.completed} / ${progress.total}`;
    $("#career-progress-bar").style.width = `${progress.percent}%`;
  }

  renderNotebook() {
    const experiments = this.store.getExperiments();
    $("#experiment-count").textContent = `${experiments.length} RECORDS`;
    $("#experiment-list").innerHTML = experiments.length ? experiments.map((item) => `
      <article class="experiment-item">
        <div><h3>${this.escapeHTML(item.missionName)}</h3><p>${new Date(item.createdAt).toLocaleString()} · ${this.escapeHTML(item.topic)} · ${item.elapsed.toFixed(2)}s</p><p><code>x′=${this.escapeHTML(item.equations.x)}</code> &nbsp; <code>y′=${this.escapeHTML(item.equations.y)}</code></p></div>
        <span class="experiment-result">${item.success ? `LANDED · ${item.score} PTS` : `MISSED · ${format(item.distance)}u`}</span>
      </article>`).join("") : '<div class="empty-state">No experiments recorded yet. Complete a flight to create your first entry.</div>';
    $("#saved-notes").innerHTML = this.store.getNotes().slice(0, 5).map((note) => `<div class="saved-note">${this.escapeHTML(note.content)}<br><small>${new Date(note.createdAt).toLocaleString()}</small></div>`).join("");
  }

  exportNotebook() {
    const data = {
      title: "Learning to Fly — Research Log",
      exportedAt: new Date().toISOString(),
      progress: this.store.getState(),
      experiments: this.store.getExperiments(),
      notes: this.store.getNotes()
    };
    this.download("vector-field-pilot-research-log.json", JSON.stringify(data, null, 2), "application/json");
  }

  setupLivery() {
    this.selectLivery(this.store.getState().selectedLivery, false);
  }

  selectLivery(livery, persist = true) {
    const colors = { cyan: "#53d9e8", amber: "#f2b766", violet: "#b39aff" };
    const color = colors[livery] ?? colors.cyan;
    $("#hangar-plane .plane-large").style.color = color;
    $$(".livery-option").forEach((button) => button.classList.toggle("selected", button.dataset.livery === livery));
    if (persist) this.store.setLivery(livery);
  }

  handleLiveryClick(event) {
    const button = event.target.closest("[data-livery]");
    if (button) this.selectLivery(button.dataset.livery);
  }

  toast(message) {
    const element = $("#toast");
    element.textContent = safeText(message);
    element.classList.add("visible");
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => element.classList.remove("visible"), 2500);
  }

  formatTime(seconds) {
    const total = Math.floor(seconds);
    return `${String(Math.floor(total / 60)).padStart(2,"0")}:${String(total % 60).padStart(2,"0")}`;
  }

  escapeHTML(value) {
    return safeText(value).replace(/[&<>"']/g, (char) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[char]);
  }

  download(filename, content, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  destroy() {
    cancelAnimationFrame(this.animationId);
    this.canvas.destroy();
    this.simulator?.pause();
  }
}
