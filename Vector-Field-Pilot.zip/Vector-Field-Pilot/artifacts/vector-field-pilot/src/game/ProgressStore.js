const STORAGE_KEY = "vector-field-pilot-v1";

const EMPTY_STATE = Object.freeze({
  completedMissions: [],
  experiments: [],
  sweeps: [],
  notes: [],
  selectedLivery: "cyan",
  preferences: { timeScale: 1, fieldMode: "direction", reducedMotion: false }
});

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

export class ProgressStore extends EventTarget {
  constructor(storage = globalThis.localStorage) {
    super();
    this.storage = storage;
    this.state = this.load();
  }

  load() {
    try {
      const raw = this.storage?.getItem(STORAGE_KEY);
      if (!raw) return clone(EMPTY_STATE);
      const parsed = JSON.parse(raw);
      return {
        ...clone(EMPTY_STATE),
        ...parsed,
        preferences: { ...EMPTY_STATE.preferences, ...(parsed.preferences ?? {}) }
      };
    } catch {
      return clone(EMPTY_STATE);
    }
  }

  save() {
    try {
      this.storage?.setItem(STORAGE_KEY, JSON.stringify(this.state));
      this.dispatchEvent(new Event("change"));
      return true;
    } catch (error) {
      this.dispatchEvent(new CustomEvent("storage-error", { detail: error }));
      return false;
    }
  }

  getState() { return clone(this.state); }
  getCompletedMissionIds() { return [...this.state.completedMissions.map((item) => item.id)]; }
  getExperiments() { return clone(this.state.experiments).reverse(); }
  getNotes() { return clone(this.state.notes).reverse(); }

  completeMission(id, score) {
    const existing = this.state.completedMissions.find((item) => item.id === id);
    if (existing) existing.bestScore = Math.max(existing.bestScore, score);
    else this.state.completedMissions.push({ id, bestScore: score, completedAt: new Date().toISOString() });
    this.save();
  }

  addExperiment(experiment) {
    this.state.experiments.push(clone(experiment));
    if (this.state.experiments.length > 200) this.state.experiments.shift();
    this.save();
  }

  getSweeps() { return Array.isArray(this.state.sweeps) ? clone(this.state.sweeps).reverse() : []; }

  addSweep(sweep) {
    if (!Array.isArray(this.state.sweeps)) this.state.sweeps = [];
    this.state.sweeps.push({
      id: globalThis.crypto?.randomUUID?.() ?? String(Date.now()),
      createdAt: new Date().toISOString(),
      ...clone(sweep)
    });
    if (this.state.sweeps.length > 30) this.state.sweeps.shift();
    return this.save();
  }

  addNote(content) {
    const trimmed = String(content).trim();
    if (!trimmed) return false;
    this.state.notes.push({ id: crypto.randomUUID?.() ?? String(Date.now()), content: trimmed, createdAt: new Date().toISOString() });
    this.save();
    return true;
  }

  setLivery(livery) {
    if (!["cyan", "amber", "violet"].includes(livery)) return;
    this.state.selectedLivery = livery;
    this.save();
  }

  setPreference(key, value) {
    if (!Object.hasOwn(this.state.preferences, key)) return;
    this.state.preferences[key] = value;
    this.save();
  }

  clearAll() {
    this.state = clone(EMPTY_STATE);
    this.save();
  }

  exportJSON() {
    return JSON.stringify(this.state, null, 2);
  }
}
