/**
 * Numerical integration utilities for 2D autonomous and time-dependent systems.
 * The simulation state is { x, y, t }. Each derivative returns { x, y }.
 */
export function derivative(system, state) {
  const result = system(state);
  if (!Number.isFinite(result.x) || !Number.isFinite(result.y)) {
    throw new RangeError("The differential equation produced a non-finite rate.");
  }
  return result;
}

export function eulerStep(system, state, h) {
  const k1 = derivative(system, state);
  return {
    x: state.x + h * k1.x,
    y: state.y + h * k1.y,
    t: state.t + h
  };
}

export function midpointStep(system, state, h) {
  const k1 = derivative(system, state);
  const midpoint = {
    x: state.x + h * k1.x / 2,
    y: state.y + h * k1.y / 2,
    t: state.t + h / 2
  };
  const k2 = derivative(system, midpoint);
  return {
    x: state.x + h * k2.x,
    y: state.y + h * k2.y,
    t: state.t + h
  };
}

export function rk4Step(system, state, h) {
  const k1 = derivative(system, state);
  const k2 = derivative(system, {
    x: state.x + h * k1.x / 2,
    y: state.y + h * k1.y / 2,
    t: state.t + h / 2
  });
  const k3 = derivative(system, {
    x: state.x + h * k2.x / 2,
    y: state.y + h * k2.y / 2,
    t: state.t + h / 2
  });
  const k4 = derivative(system, {
    x: state.x + h * k3.x,
    y: state.y + h * k3.y,
    t: state.t + h
  });
  return {
    x: state.x + h * (k1.x + 2*k2.x + 2*k3.x + k4.x) / 6,
    y: state.y + h * (k1.y + 2*k2.y + 2*k3.y + k4.y) / 6,
    t: state.t + h
  };
}

export function integrate(system, initial, options = {}) {
  const {
    duration = 20,
    stepSize = 0.025,
    method = "rk4",
    maxSteps = 20000,
    stop = null
  } = options;
  if (!(stepSize > 0) || !(duration >= 0)) throw new RangeError("Duration and step size must be non-negative.");
  const step = method === "euler" ? eulerStep : method === "midpoint" ? midpointStep : rk4Step;
  const state = { x: initial.x, y: initial.y, t: initial.t ?? 0 };
  const points = [{ ...state }];
  const count = Math.min(Math.ceil(duration / stepSize), maxSteps);
  for (let index = 0; index < count; index += 1) {
    const next = step(system, state, Math.min(stepSize, duration - state.t));
    if (![next.x, next.y, next.t].every(Number.isFinite)) break;
    if (Math.abs(next.x) > 1e5 || Math.abs(next.y) > 1e5) break;
    Object.assign(state, next);
    points.push({ ...state });
    if (stop?.(state, points[points.length - 2])) break;
  }
  return points;
}

export function estimateAdaptive(system, initial, options = {}) {
  const {
    duration = 20,
    initialStep = 0.05,
    tolerance = 1e-5,
    minStep = 1e-5,
    maxStep = 0.2,
    maxSteps = 50000
  } = options;
  let h = initialStep;
  let state = { ...initial, t: initial.t ?? 0 };
  const points = [{ ...state }];
  let steps = 0;
  while (state.t < duration && steps < maxSteps) {
    h = Math.min(h, duration - state.t);
    const full = rk4Step(system, state, h);
    const half = rk4Step(system, rk4Step(system, state, h / 2), h / 2);
    const error = Math.hypot(full.x - half.x, full.y - half.y) / 15;
    if (!Number.isFinite(error)) throw new RangeError("Adaptive solver encountered a non-finite error estimate.");
    if (error <= tolerance || h <= minStep * 1.001) {
      state = { ...half, t: state.t + h };
      points.push({ ...state });
    }
    const factor = error === 0 ? 2 : Math.min(2, Math.max(.25, .9 * Math.pow(tolerance / error, .2)));
    h = Math.min(maxStep, Math.max(minStep, h * factor));
    steps += 1;
    if (Math.abs(state.x) > 1e5 || Math.abs(state.y) > 1e5) break;
  }
  return points;
}

export function trajectoryMetrics(points, target = { x: 8, y: 0 }) {
  if (!points.length) return { distance: Infinity, pathLength: 0, maxDeviation: 0, final: null };
  let pathLength = 0;
  let maxDeviation = 0;
  for (let i = 1; i < points.length; i += 1) {
    const a = points[i - 1], b = points[i];
    pathLength += Math.hypot(b.x - a.x, b.y - a.y);
    maxDeviation = Math.max(maxDeviation, Math.hypot(b.x - target.x, b.y - target.y));
  }
  const final = points[points.length - 1];
  return {
    distance: Math.hypot(final.x - target.x, final.y - target.y),
    pathLength,
    maxDeviation,
    final: { ...final }
  };
}

export function numericalJacobian(system, point, epsilon = 1e-5) {
  const fx1 = system({ ...point, x: point.x + epsilon });
  const fx0 = system({ ...point, x: point.x - epsilon });
  const fy1 = system({ ...point, y: point.y + epsilon });
  const fy0 = system({ ...point, y: point.y - epsilon });
  return {
    a: (fx1.x - fx0.x) / (2 * epsilon),
    b: (fy1.x - fy0.x) / (2 * epsilon),
    c: (fx1.y - fx0.y) / (2 * epsilon),
    d: (fy1.y - fy0.y) / (2 * epsilon)
  };
}

export function classifyLinearSystem(matrix) {
  const { a, b, c, d } = matrix;
  const trace = a + d;
  const determinant = a * d - b * c;
  const discriminant = trace * trace - 4 * determinant;
  if (determinant < 0) return { type: "Saddle", stable: false, trace, determinant, discriminant };
  if (determinant > 0 && trace < 0 && discriminant >= 0) return { type: "Stable node", stable: true, trace, determinant, discriminant };
  if (determinant > 0 && trace > 0 && discriminant >= 0) return { type: "Unstable node", stable: false, trace, determinant, discriminant };
  if (determinant > 0 && Math.abs(trace) < 1e-8 && discriminant < 0) return { type: "Center (linear)", stable: false, trace, determinant, discriminant };
  if (determinant > 0 && trace < 0 && discriminant < 0) return { type: "Stable spiral", stable: true, trace, determinant, discriminant };
  if (determinant > 0 && trace > 0 && discriminant < 0) return { type: "Unstable spiral", stable: false, trace, determinant, discriminant };
  return { type: "Degenerate / inconclusive", stable: false, trace, determinant, discriminant };
}
