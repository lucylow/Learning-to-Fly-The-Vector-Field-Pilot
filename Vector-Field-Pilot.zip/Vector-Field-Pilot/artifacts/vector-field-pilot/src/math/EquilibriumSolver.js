import { finiteDifference, newton } from "./RootFinding.js";
import { numericalJacobian, classifyLinearSystem } from "./ODESolver.js";

/**
 * Approximate equilibrium finder for a two-dimensional vector field.
 * Uses damped Newton iterations on the pair (f(x,y), g(x,y)).
 */
export class EquilibriumSolver {
  constructor(system) { this.system = system; }

  residual(point) {
    const value = this.system(point);
    return Math.hypot(value.x, value.y);
  }

  solve(seed, options = {}) {
    const tolerance = options.tolerance ?? 1e-8;
    const maxIterations = options.maxIterations ?? 40;
    const damping = options.damping ?? .8;
    let point = { x: seed.x, y: seed.y };
    let converged = false;
    let iteration = 0;
    for (; iteration < maxIterations; iteration += 1) {
      const value = this.system(point);
      const jacobian = numericalJacobian(this.system, point);
      const determinant = jacobian.a * jacobian.d - jacobian.b * jacobian.c;
      if (Math.abs(determinant) < 1e-12) break;
      const dx = (jacobian.d * value.x - jacobian.b * value.y) / determinant;
      const dy = (-jacobian.c * value.x + jacobian.a * value.y) / determinant;
      const candidate = { x: point.x - damping * dx, y: point.y - damping * dy };
      if (!Number.isFinite(candidate.x + candidate.y)) break;
      point = candidate;
      if (this.residual(point) < tolerance) { converged = true; iteration += 1; break; }
    }
    const residual = this.residual(point);
    const matrix = numericalJacobian(this.system, point);
    return {
      point,
      residual,
      iterations: iteration,
      converged: converged || residual < tolerance,
      jacobian: matrix,
      classification: classifyLinearSystem(matrix)
    };
  }

  scan(bounds, options = {}) {
    const seeds = [];
    const rows = options.rows ?? 12;
    const columns = options.columns ?? 12;
    for (let row = 0; row < rows; row += 1) {
      for (let column = 0; column < columns; column += 1) {
        seeds.push({
          x: bounds.xMin + (bounds.xMax - bounds.xMin) * column / Math.max(1, columns - 1),
          y: bounds.yMin + (bounds.yMax - bounds.yMin) * row / Math.max(1, rows - 1)
        });
      }
    }
    const candidates = seeds.map((seed) => this.solve(seed, options)).filter((item) => item.converged);
    return deduplicateEquilibria(candidates, options.mergeDistance ?? .1);
  }

  analyze(point) {
    const result = this.solve(point);
    const trace = result.jacobian.a + result.jacobian.d;
    const determinant = result.jacobian.a * result.jacobian.d - result.jacobian.b * result.jacobian.c;
    return { ...result, trace, determinant, description: describeClassification(result.classification.type) };
  }
}

export function deduplicateEquilibria(items, distance = .1) {
  const output = [];
  for (const item of items) {
    if (!output.some((other) => Math.hypot(item.point.x - other.point.x, item.point.y - other.point.y) < distance)) output.push(item);
  }
  return output;
}

export function describeClassification(type) {
  const descriptions = {
    "Stable node": "Nearby trajectories approach the equilibrium without rotating in the linearized picture.",
    "Unstable node": "Nearby trajectories move away from the equilibrium in the linearized picture.",
    "Saddle": "The equilibrium attracts along one direction and repels along another.",
    "Stable spiral": "Nearby trajectories rotate while approaching the equilibrium.",
    "Unstable spiral": "Nearby trajectories rotate while moving away from the equilibrium.",
    "Center (linear)": "The linearized system has closed orbits around the equilibrium."
  };
  return descriptions[type] ?? "The local linear classification is inconclusive.";
}

export function scalarEquilibrium(fn, initial, options = {}) {
  const derivative = (x) => finiteDifference(fn, x);
  return newton(fn, derivative, initial, options);
}
