/**
 * Small dense-matrix utilities for two-dimensional and classroom state-space work.
 * Matrices are represented as arrays of rows.
 */
export function shape(matrix) {
  return { rows: matrix.length, columns: matrix[0]?.length ?? 0 };
}

export function validateMatrix(matrix) {
  if (!Array.isArray(matrix) || !matrix.length || !Array.isArray(matrix[0])) return false;
  const columns = matrix[0].length;
  return columns > 0 && matrix.every((row) => Array.isArray(row) && row.length === columns && row.every(Number.isFinite));
}

export function zeros(rows, columns = rows) {
  return Array.from({ length: rows }, () => Array(columns).fill(0));
}

export function identity(size) {
  const result = zeros(size);
  for (let index = 0; index < size; index += 1) result[index][index] = 1;
  return result;
}

export function addMatrices(a, b) {
  assertSameShape(a, b);
  return a.map((row, i) => row.map((value, j) => value + b[i][j]));
}

export function subtractMatrices(a, b) {
  assertSameShape(a, b);
  return a.map((row, i) => row.map((value, j) => value - b[i][j]));
}

export function scaleMatrix(matrix, scalar) {
  return matrix.map((row) => row.map((value) => value * scalar));
}

export function multiplyMatrices(a, b) {
  if (!validateMatrix(a) || !validateMatrix(b) || a[0].length !== b.length) {
    throw new TypeError("Matrix dimensions are not compatible for multiplication.");
  }
  const output = zeros(a.length, b[0].length);
  for (let i = 0; i < a.length; i += 1) {
    for (let k = 0; k < b.length; k += 1) {
      for (let j = 0; j < b[0].length; j += 1) output[i][j] += a[i][k] * b[k][j];
    }
  }
  return output;
}

export function multiplyMatrixVector(matrix, vector) {
  if (!validateMatrix(matrix) || matrix[0].length !== vector.length) throw new TypeError("Matrix and vector dimensions do not match.");
  return matrix.map((row) => row.reduce((sum, value, index) => sum + value * vector[index], 0));
}

export function transpose(matrix) {
  if (!validateMatrix(matrix)) throw new TypeError("Expected a rectangular numeric matrix.");
  return matrix[0].map((_, column) => matrix.map((row) => row[column]));
}

export function trace(matrix) {
  if (!validateMatrix(matrix) || matrix.length !== matrix[0].length) throw new TypeError("Trace requires a square matrix.");
  return matrix.reduce((sum, row, index) => sum + row[index], 0);
}

export function determinant2(matrix) {
  if (shape(matrix).rows !== 2 || shape(matrix).columns !== 2) throw new TypeError("Expected a 2x2 matrix.");
  return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
}

export function inverse2(matrix) {
  const determinant = determinant2(matrix);
  if (Math.abs(determinant) < 1e-12) throw new RangeError("Matrix is singular.");
  return [
    [matrix[1][1] / determinant, -matrix[0][1] / determinant],
    [-matrix[1][0] / determinant, matrix[0][0] / determinant]
  ];
}

export function solve2(matrix, vector) {
  return multiplyMatrixVector(inverse2(matrix), vector);
}

export function matrixNormInfinity(matrix) {
  return Math.max(0, ...matrix.map((row) => row.reduce((sum, value) => sum + Math.abs(value), 0)));
}

export function formatMatrix(matrix, digits = 3) {
  return matrix.map((row) => `[ ${row.map((value) => Number(value).toFixed(digits)).join("  ")} ]`).join("\n");
}

export function assertSameShape(a, b) {
  const first = shape(a), second = shape(b);
  if (first.rows !== second.rows || first.columns !== second.columns) throw new TypeError("Matrix shapes must match.");
}

export function jacobiEigenvaluesSymmetric2(matrix) {
  if (shape(matrix).rows !== 2 || shape(matrix).columns !== 2) throw new TypeError("Expected a 2x2 matrix.");
  const a = matrix[0][0], b = (matrix[0][1] + matrix[1][0]) / 2, d = matrix[1][1];
  const center = (a + d) / 2;
  const radius = Math.sqrt(((a - d) / 2) ** 2 + b ** 2);
  return [center - radius, center + radius];
}

export function matrixEquals(a, b, tolerance = 1e-9) {
  try { assertSameShape(a, b); }
  catch { return false; }
  return a.every((row, i) => row.every((value, j) => Math.abs(value - b[i][j]) <= tolerance));
}
